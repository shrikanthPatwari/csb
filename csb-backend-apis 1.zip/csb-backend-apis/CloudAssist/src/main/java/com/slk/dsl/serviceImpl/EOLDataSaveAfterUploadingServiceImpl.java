package com.slk.dsl.serviceImpl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.slk.dsl.dto.DatabaseEOLDTO;
import com.slk.dsl.model.Application;
import com.slk.dsl.model.CaAppmasterTechstack;
import com.slk.dsl.model.EolProducts;
import com.slk.dsl.model.EolVersion;
import com.slk.dsl.model.LOB;
import com.slk.dsl.repository.EolProductsRepo;
import com.slk.dsl.repository.EolVersionRepo;
import com.slk.dsl.repository.LOBRepo;
import com.slk.dsl.services.ApplicationDataSaveAfterUploadingService;
import com.slk.dsl.services.EOLDataSaveAfterUploadingService;

@Service
public class EOLDataSaveAfterUploadingServiceImpl implements EOLDataSaveAfterUploadingService{

	@Autowired
	EolProductsRepo repoeol;
	
	@Autowired
	EolVersionRepo repoVersion;
	
	@Override
	public boolean saveEOLDataFromUploadFile(MultipartFile file, int orgId) throws IOException {

		boolean isFlag = false;

		isFlag = readDataFromExcel(file, orgId);

		return isFlag;
	}

	private boolean readDataFromExcel(MultipartFile file, int orgId) throws IOException {

		boolean FileUploaded = false;
		String fileNameWithOutExt = FilenameUtils.removeExtension(file.getOriginalFilename());
		//uploading app discovery data
		if (fileNameWithOutExt.equalsIgnoreCase("EOL Discovery Data")) {

			// Delete ca_infra_mapping details,ca_infra_details and ca_app_master details
			List<EolProducts> eolDet = new ArrayList<EolProducts>();
		List<EolVersion> verDet = new ArrayList<EolVersion>();

			Workbook workbook = getWorkbook(file);

			Sheet sheet = workbook.getSheetAt(0);

			System.out.println(sheet.getLastRowNum());
//			CreationHelper createHelper =workbook.getCreationHelper();
//				CellStyle cellStyle = workbook.createCellStyle();
//				cellStyle.setDataFormat(createHelper.createDataFormat().getFormat("yyyy/mm/dd"));
         	Iterator<Row> rows = sheet.iterator();

			rows.next();
			

			while (rows.hasNext()) {

				long size = file.getSize();
				System.out.println("Intial file byte" + size);

				Row row = rows.next();

				if (isCellEmpty(row.getCell(0))) {
					break;
				}
				EolProducts eol = new EolProducts();

				eol.setRecInsdt(new java.util.Date());
				eol.setRecUpddt(new java.util.Date());
				if (row.getCell(0) != null && row.getCell(0).getCellType() == CellType.STRING) {
					eol.setProductName(row.getCell(0).getStringCellValue());

				}
				List<Object[]> product = repoeol.geteolDistinctValues(eol.getProductName());
	
				if (product.isEmpty()) {

					eol.setRecInsdt(new java.util.Date());
					eol.setRecUpddt(new java.util.Date());

					if (row.getCell(0) != null && row.getCell(0).getCellType() == CellType.STRING) {
						eol.setProductName(row.getCell(0).getStringCellValue());
					}

					if (row.getCell(1) != null && row.getCell(1).getCellType() == CellType.STRING) {
						eol.setProductAliasName(row.getCell(1).getStringCellValue());


						eolDet.add(eol);

				} 
				}
				repoeol.saveAll(eolDet);
			}
				
					Sheet sheet1 = workbook.getSheetAt(0);

					System.out.println(sheet1.getLastRowNum());

					Iterator<Row> row2 = sheet.iterator();

					row2.next();

					while (row2.hasNext()) {

						Row row1 = row2.next();

						if (isCellEmpty(row1.getCell(0))) {
							break;
						}
						EolProducts eol = new EolProducts();

						eol.setRecInsdt(new java.util.Date());
						eol.setRecUpddt(new java.util.Date());
						if (row1.getCell(0) != null && row1.getCell(0).getCellType() == CellType.STRING) {
							eol.setProductName(row1.getCell(0).getStringCellValue());

						}
						List<Object[]> product = repoeol.geteolDistinctValues(eol.getProductName());
						product.stream().forEach(obj->{
							
							eol.setProductId((Integer)obj[0]);
							
						});
					EolVersion version = new EolVersion();
					version.setRecInsdt(new java.util.Date());
					version.setRecUpddt(new java.util.Date());

					version.setProductID(eol.getProductId());
					int prodId = eol.getProductId();
					System.out.println(prodId + "product id");
					 repoVersion.deleteAllVersions(prodId);
					
					if (row1.getCell(2) != null && row1.getCell(2).getCellType() == CellType.STRING) {
						version.setVersion(row1.getCell(2).getStringCellValue());
					}
					String version1 = null;
					if (row1.getCell(2) != null && row1.getCell(2).getCellType() == CellType.NUMERIC) {
						double versionId = Double.parseDouble(row1.getCell(2).toString());
						double progId = (double) versionId;
						version1 = String.valueOf(progId);
						version.setVersion(version1);
					}
					if (row1.getCell(3) != null && row1.getCell(3).getCellType() == CellType.NUMERIC) {
						version.setReleasedt(row1.getCell(3).getDateCellValue());
					}
					if (row1.getCell(4) != null && row1.getCell(4).getCellType() == CellType.NUMERIC) {
						version.setSupportdt(row1.getCell(4).getDateCellValue());
					}
					if (row1.getCell(5) != null && row1.getCell(5).getCellType() == CellType.NUMERIC){
						version.setEoldt(row1.getCell(5).getDateCellValue());
						System.out.println(row1.getCell(5).getDateCellValue()+"EOL Date");
					}
					if (row1.getCell(6) != null && row1.getCell(6).getCellType() == CellType.NUMERIC) {
						double active = Double.parseDouble(row1.getCell(6).toString());
						int isActive = (int) active;												
						version.setIsActive(isActive);
						verDet.add(version);
					}
			}
					repoVersion.saveAll(verDet);
			
		}	
				
			
		
				

			FileUploaded = true;
			return FileUploaded;

}
	private Workbook getWorkbook(MultipartFile file) {
		// TODO Auto-generated method stub

		Workbook workbook = null;
	
		try {
			workbook = new XSSFWorkbook(file.getInputStream());

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return workbook;
	}

	public static boolean isCellEmpty(final Cell cell) {
		if (cell == null || cell.getCellType() == CellType.BLANK) {
			return true;
		}
		if (cell.getCellType() == CellType.STRING && cell.getStringCellValue().isEmpty()) {
			return true;
		}
		return false;
	}

	public static boolean isColumnEmpty(Sheet sheet, int columnIndex, int startRow) {
		for (Row row : sheet) {
			if (row.getRowNum() < startRow)
				continue;
			Cell cell = row.getCell(columnIndex);
			if (cell != null) {
				return false;
			}
		}
		return true;
	}


}