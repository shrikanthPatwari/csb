package com.slk.dsl.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.slk.dsl.model.FHNAppVersionData;
import com.slk.dsl.model.InfraDataModel;
import com.slk.dsl.model.ProcessDataModel;

public interface ProcessDataRepo  extends JpaRepository<ProcessDataModel, Integer>{
	
	 String deleteRecordsFromOrgId="Delete from ca_process_data where Org_Id=:orgId";
		@Modifying
	    @Transactional 
		@Query(value = deleteRecordsFromOrgId, nativeQuery = true)
		public void deleteProcess(int orgId);
		
		String process_data = "select * from ca_process_data where Org_Id=:orgId  ";
		@Query(value = process_data, nativeQuery = true)
		public List<ProcessDataModel> getdataprocess(int orgId);
		

		String createproc = "insert into ca_process_data (BusinessOwner,BusinessManager,App_Master_Id,Org_Id)"
				+ " Values (:BusinessOwner,:BusinessManager,:appmasterid,:orgid) ";
		@Modifying
		@Transactional
		@Query(value = createproc, nativeQuery = true)
	public void saveProc(String BusinessOwner,String BusinessManager ,int appmasterid,int orgid);
		
		
		
		String procName=" select App_Master_Id,App_Name from ca_app_master where App_Master_Id not in (\r\n"
				+ "select m.App_Master_Id from ca_process_data m\r\n"
				+ "inner join ca_app_master a on a.App_Master_Id = m.App_Master_Id\r\n"
				+ "where a.Org_Id=:orgId)";
		

		@Query(value = procName, nativeQuery = true)
		public List<Object[]> getProcess(int orgId);
		

}
