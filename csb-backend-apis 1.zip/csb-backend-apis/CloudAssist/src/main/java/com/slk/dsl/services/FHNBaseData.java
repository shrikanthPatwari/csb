package com.slk.dsl.services;

public class FHNBaseData {

}
