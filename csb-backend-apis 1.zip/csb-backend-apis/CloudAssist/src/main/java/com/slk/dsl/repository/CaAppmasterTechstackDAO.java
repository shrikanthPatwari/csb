package com.slk.dsl.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.slk.dsl.model.CaAppmasterTechstack;


public interface CaAppmasterTechstackDAO extends JpaRepository<CaAppmasterTechstack,Integer>{
	
	String findQueryForAppMaster = "select App_Master_Id  from ca_app_master where App_Id=:appId";
	@Query(value = findQueryForAppMaster, nativeQuery = true)
	public List<Object[]> getAppMasterId(String appId);
	
	String deleteRecordsFromOrgId="Delete from ca_appmaster_techstack where Org_Id=:orgId";
	@Modifying
    @Transactional 
	@Query(value = deleteRecordsFromOrgId, nativeQuery = true)
	public void deleteAppMapping(int orgId);
	

}