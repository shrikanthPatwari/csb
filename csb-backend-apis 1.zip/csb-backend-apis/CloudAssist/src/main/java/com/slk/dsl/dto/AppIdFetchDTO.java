
package com.slk.dsl.dto;

public class AppIdFetchDTO {

	private int App_Master_Id;
	private int Lob_Id;
    private int Usr_Id;
    private String Lob_Name;
    
	public int getLob_Id() {
		return Lob_Id;
	}

	public void setLob_Id(int lob_Id) {
		Lob_Id = lob_Id;
	}

	public int getApp_Master_Id() {
		return App_Master_Id;
	}

	public void setApp_Master_Id(int app_Master_Id) {
		App_Master_Id = app_Master_Id;
	}

	public int getUsr_Id() {
		return Usr_Id;
	}

	public void setUsr_Id(int usr_Id) {
		Usr_Id = usr_Id;
	}

	public String getLob_Name() {
		return Lob_Name;
	}

	public void setLob_Name(String lob_Name) {
		Lob_Name = lob_Name;
	}
	
	
}