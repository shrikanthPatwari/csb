package com.slk.dsl.dto;

public class rlanedto {
private String RLane_Strategy_id;
	
	public String getRlane_strategy_Id() {
		return RLane_Strategy_id;
	}
	public void setRlane_strategy_Id(String RLane_Strategy_Id) {
		RLane_Strategy_id = RLane_Strategy_Id;
	}
private String RLane_strategy;
	
	public String getRLane_strategy() {
		return RLane_strategy;
	}
	public void setRLane_strategy(String RLane_Strategy) {
		RLane_strategy = RLane_Strategy;
	}
	private String App_Id;
	public String getApp_Id() {
		return App_Id;
	}
	public void setApp_Id(String app_Id) {
		App_Id = app_Id;
	}
	private String App_Name;
	
	public String getApp_Name() {
		return App_Name;
	}
	public void setApp_Name(String app_Name) {
		App_Name = app_Name;
	}
}
