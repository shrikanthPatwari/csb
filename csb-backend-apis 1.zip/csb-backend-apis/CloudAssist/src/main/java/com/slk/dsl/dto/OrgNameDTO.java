package com.slk.dsl.dto;


public class OrgNameDTO {
	String org_name;
	int Org_Id;
	int user_role_id;
	int Lob_Id;
	String First_Name;
	String Last_Name;
	int user_id;
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public String getFirst_Name() {
		return First_Name;
	}
	public void setFirst_Name(String first_Name) {
		First_Name = first_Name;
	}
	public String getLast_Name() {
		return Last_Name;
	}
	public void setLast_Name(String last_Name) {
		Last_Name = last_Name;
	}
	public int getUser_role_id() {
		return user_role_id;
	}
	public int getLob_Id() {
		return Lob_Id;
	}
	public void setLob_Id(int lob_Id) {
		Lob_Id = lob_Id;
	}
	public void setUser_role_id(int user_role_id) {
		this.user_role_id = user_role_id;
	}
	public String getOrg_name() {
		return org_name;
	}
	public void setOrg_name(String org_name) {
		this.org_name = org_name;
	}
	public int getOrg_Id() {
		return Org_Id;
	}
	public void setOrg_Id(int org_Id) {
		Org_Id = org_Id;
	}


}
