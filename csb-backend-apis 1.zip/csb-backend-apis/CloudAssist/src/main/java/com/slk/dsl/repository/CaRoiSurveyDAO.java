package com.slk.dsl.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.slk.dsl.model.Application;
@Repository

public interface CaRoiSurveyDAO extends JpaRepository<Application, Integer> {
	
	String CaRoiSurvey = "SELECT ROI_Survey_Id,ROI_Survey_Category,ROI_Survey_Question,is_Active from ca_roi_survey";
	@Query(value = CaRoiSurvey, nativeQuery = true)
	public List<Object[]>  getCaRoiSurvey();

	
	String CaRoiSurveyLookup = "select roi_survey_lookup_Id,ROI_Survey_Id,ROI_Surveylookup_values,is_Active from ca_roi_survey_lookup";
	@Query(value = CaRoiSurveyLookup, nativeQuery = true)
	public List<Object[]>  getCaRoiSurveyLookup();
	
	String ROIProgressBar = "select SUM(Cost_OfMigration) as cost_of_Migration,SUM(ROI_Calculated) as ROI_calculated from ca_roi_survey_calculator where Org_Id=:orgId";
	@Query(value = ROIProgressBar, nativeQuery = true)   
	public List<Object[]>  getROIProgressBar(int orgId);
		
}
