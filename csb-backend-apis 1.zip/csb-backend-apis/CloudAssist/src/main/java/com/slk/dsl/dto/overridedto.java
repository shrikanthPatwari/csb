package com.slk.dsl.dto;

public class overridedto {
//	private String App_Id;
//	public String getApp_Id() {
//		return App_Id;
//	}
//	public void setApp_Id(String string) {
//		App_Id = string;
//	}
	
private String RLane_Strategy_id;
	
	public String getRLane_Strategy_Id() {
		return RLane_Strategy_id;
	}
	public void setRLane_Strategy_Id(String RLane_Strategy_Id) {
		RLane_Strategy_id = RLane_Strategy_Id;
	}
	
private String RLane_strategy;
	
	public String getRLane_Strategy() {
		return RLane_strategy;
	}
	public void setRLane_Strategy(String RLane_Strategy) {
		RLane_strategy = RLane_Strategy;
	}

}
