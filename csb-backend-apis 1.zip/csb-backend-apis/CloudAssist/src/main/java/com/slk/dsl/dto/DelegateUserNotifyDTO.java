package com.slk.dsl.dto;

import java.util.List;

public class DelegateUserNotifyDTO {
    
    private String delegatedToEmailId;
	private String password;
	private String delegatedByEmailId;
	private String delegatedBy;
    private List<application> applications;
    
	public String getDelegatedToEmailId() {
		return delegatedToEmailId;
	}
	public void setDelegatedToEmailId(String delegatedToEmailId) {
		this.delegatedToEmailId = delegatedToEmailId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getDelegatedByEmailId() {
		return delegatedByEmailId;
	}
	public void setDelegatedByEmailId(String delegatedByEmailId) {
		this.delegatedByEmailId = delegatedByEmailId;
	}
	
	
	public String getDelegatedBy() {
		return delegatedBy;
	}
	public void setDelegatedBy(String delegatedBy) {
		this.delegatedBy = delegatedBy;
	}
	public List<application> getApplications() {
		return applications;
	}
	public void setApplications(List<application> applications) {
		this.applications = applications;
	}

	

	public static class application {
		 private String appname;
		 private String activestatus;
		public String getAppname() {
			return appname;
		}
		public void setAppname(String appname) {
			this.appname = appname;
		}
		public String getActivestatus() {
			return activestatus;
		}
		public void setActivestatus(String activestatus) {
			this.activestatus = activestatus;
		}
		 
		
		 
	}
	
	
}

