package com.slk.dsl.services;

import java.io.IOException;
import java.math.BigInteger;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpRequest.BodyPublishers;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.slk.dsl.dto.DelegateUserNotifyDTO;
import com.slk.dsl.dto.DelegateUserNotifyDTO.application;
import com.slk.dsl.dto.Email_passwordDTO;
import com.slk.dsl.dto.OrgNameDTO;
import com.slk.dsl.dto.OsNamesDTO;
import com.slk.dsl.dto.UserRole;
import com.slk.dsl.dto.migrationdto;
import com.slk.dsl.model.Role;
import com.slk.dsl.model.UserSetup;
import com.slk.dsl.model.ca_user_app_mapping;
import com.slk.dsl.repository.RoleRepo;
import com.slk.dsl.repository.UserSetupDao;

import freemarker.template.Configuration;
import freemarker.template.Template;

import org.springframework.beans.factory.annotation.Value;
@Service
public class UserService {
	
	@Autowired
    private JavaMailSender mailSender;
	
	@Autowired
	UserSetupDao userRepo;
	@Autowired
	RoleRepo Repo;
	@Autowired
	private PasswordEncoder bcryptEncoder;
	
	@Value("${applicationUrl}")
	private String url;
	
	@Value("${fromAddress}")
	private String fromAddress;

	@Value("${emailUrl}")
	private String emailurl;
	
	@Autowired
	private Configuration config;
	
	public void updateUser(UserSetup userDetails) {

		String firstname =userDetails.getFirstName();
		String lastname =userDetails.getLastName();
		String email = userDetails.getEmailId();
//		int lobid= Integer.valueOf(userDetails.getLobId());
		int roleid = Integer.valueOf(userDetails.getUser_role_id());
		int id = userDetails.getUserId();
		
		 userRepo.updateUser(firstname,lastname,email,roleid,id);
		
		
	}
	
	public UserSetup saveUser(UserSetup userDetails, String OrgId ) {
		
		
		userDetails.setFirstName(userDetails.getFirstName());
		userDetails.setLastName(userDetails.getLastName());
		userDetails.setEmailId(userDetails.getEmailId());
//		userDetails.setLobId(userDetails.getLobId());
		userDetails.setRecInsDt(userDetails.getRecInsDt());
		userDetails.setRecUpdDt(userDetails.getRecUpdDt());
		userDetails.setRecType(userDetails.isRecType());
		userDetails.setUser_role_id(userDetails.getUser_role_id());
		userDetails.setOrgId(Integer.valueOf(OrgId));
//		userDetails.setPassword(bcryptEncoder.encode(userDetails.getPassword()));
		userDetails.setPassword(Base64.getEncoder().encodeToString(userDetails.getPassword().getBytes()));
		
		return userRepo.save(userDetails);
	}
	

	
	 public List<UserSetup> getUsers() {  
	        return userRepo.findAll();  
	    } 
 

	 
	 public List<Role> 	 getrolelist() {  
	        return Repo.findAll();  
	    } 
	 
	 
	 public Optional<UserSetup> getUserByID(int id) {
		 return userRepo.findById(id);
	 }
	 public void delete(int id) {
		 userRepo.deleteById(id);
	 }
	 
	 
 public void sendSimpleEmail(List<Email_passwordDTO> toEmail,
             
             String subject) {
		
		 

for(int i=0;i<toEmail.size();i++) {
//	SimpleMailMessage message = new SimpleMailMessage();
//	message.setTo(toEmail.get(i).getEmailid());
//	message.setFrom(fromAddress);
//	 String body = "Welcome to Cloud Strategy Builder!\r\n"
//			 + "\r\n"
//				+ "Login details:\r\n"
//				+ "You now have access to CSB application to take up the Application Survey, please log in to the "
//				+ "Application at: "+url+"\r\n"
//				+ "\r\n"
//				+ "Use the below credentials (username and password) to access the site.\r\n"
//				+ "\r\n"
//				+ "Username: "+ toEmail.get(i).getEmailid()+"\r\n"
//				+ "Password: "+ toEmail.get(i).getPassword() +"\r\n"
//				+ "\r\n"
//				+ "Thank you,\r\n"
//				 + "\r\n"
//				+ "This message is for informational purposes only. Please do not reply to this email.\r\n";
//	 message.setText(body);
//	 message.setSubject(subject);
//
//	 mailSender.send(message);
	 try {
			Template t = config.getTemplate("notifyUser-template.ftl"); 		         
	         Map<String, Object> model = new HashMap<>();  
	         model.put("url", url);
	         model.put("userName",toEmail.get(i).getEmailid());
	         model.put("password", toEmail.get(i).getPassword());	
	         String html = FreeMarkerTemplateUtils.processTemplateIntoString(t, model);
	         ObjectMapper objectMapper = new ObjectMapper();
	         Map<String, Object> data = new HashMap<>();  
	         data.put("To", toEmail.get(i).getEmailid());
//	         data.put("cc"," ");
	         data.put("body", html);	
	         data.put("Subject", subject);
	         System.out.println(data);
	         String requestBody = objectMapper
	        	      .writerWithDefaultPrettyPrinter()
	        	      .writeValueAsString(data);
			HttpRequest request = HttpRequest.newBuilder()
					.uri(URI.create(emailurl))
					.POST(BodyPublishers.ofString(requestBody))
					 .header("Content-Type", "application/json")
					.build();
			HttpResponse<String> response = null;
			try {
				response = HttpClient.newHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
			} catch (IOException e) {
				e.printStackTrace();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			System.out.println(response.body());
			}catch(Exception e) {
				e.printStackTrace();
			}
}
 }

	 public List<OrgNameDTO> getorgname(String emailId) {  
		 List<Object[]> queryResult = userRepo.getorgname(emailId);
		 
		 List<OrgNameDTO> temp = new ArrayList<OrgNameDTO>();
		 queryResult.stream().forEach(object->{
			 OrgNameDTO obj = new OrgNameDTO();
			 obj.setOrg_name(object[0].toString());
			 obj.setOrg_Id((Integer)object[1]);
			 obj.setUser_role_id((Integer)object[2]);
//			 obj.setLob_Id((Integer)object[3]);
			 obj.setFirst_Name(object[3].toString());
			 obj.setLast_Name(object[4].toString());
			 obj.setUser_id((Integer)object[5]);
			 temp.add(obj);
		 });
		 return temp;
		 }

	 
	 public List<migrationdto> loginvalidation() {  
		 List<Object[]> queryResult = userRepo.getuservalidation();
		 List<migrationdto> result = new ArrayList<migrationdto>();

		 queryResult.stream().forEach(objects->{
		 	migrationdto temp = new migrationdto();
		 	temp.setNum(BigInteger.valueOf((Integer)objects[0]));
		 	temp.setMigration_Strategy(objects[1].toString());
		 	result.add(temp);
		 	});
		 return result;
		 }
	 public List<UserRole> getLOBUserMapping(int orgId){
			List<Object[]> queryResult = userRepo.getLOBUserMapping(orgId);
			List<UserRole> usr = new ArrayList<UserRole>();
			queryResult.stream().forEach(object->{
				UserRole temp = new UserRole();
				temp.setUsr_Id((Integer)object[0]);
//				temp.setLob_Id((Integer)object[1]);
//				temp.setLob_Name(object[2].toString());
				temp.setFirst_Name(object[1].toString());
				temp.setLast_Name(object[2].toString());
				temp.setEmail_Id(object[3].toString());
				temp.setUser_role_type(object[4].toString());
				temp.setPassword(object[5].toString());
				usr.add(temp);
				
			});
			
			return usr;
			
		 }
	 
		
public void notifyDelegateUser(List<DelegateUserNotifyDTO> toEmail,
          
          String subject) {		
	String elem1 = "";
for(int i=0;i<toEmail.size();i++) {
	
	ArrayList<String> userapps = new ArrayList<String>();	
	for(application apps :toEmail.get(i).getApplications()){
	 userapps.add(apps.getAppname());
	}	

 for (String elem: userapps) {
	 if (elem1.equals("")) {
		 elem1="-"+elem; 
	 }
	 else {
		 elem1=elem1+"\n"+"-"+elem;
	 }
	}
//	 String body = "Welcome to Cloud Strategy Builder!\r\n"
//			 + "\r\n"
//				+ "Login details:\r\n"
//				+ "You now have access to CSB application to take up the Application Survey, please log in to the "
//				+ "Application at: "+url+"\r\n"
//				+ "\r\n"
//				+ "Use the below credentials (username and password) to access the site.\r\n"
//				+ "\r\n"
//				+ "Username: "+ toEmail.get(i).getDelegatedToEmailId()+"\r\n"
//				+ "Password: "+ toEmail.get(i).getPassword() +"\r\n"
//				+ "\r\n"
//				+ "Please take the survey assigned by " + toEmail.get(i).getDelegatedBy() +"\r\n"
//				+ "For the following applications " +"\r\n"				
//				+ elem1 +"\r\n"
//				+ "\r\n"
//				+ "Thank you,\r\n"
//				 + "\r\n"
//				+ "This message is for informational purposes only. Please do not reply to this email.\r\n";
//	 SimpleMailMessage message = new SimpleMailMessage();
//	 message.setTo(toEmail.get(i).getDelegatedToEmailId());
//	 message.setCc(toEmail.get(i).getDelegatedByEmailId());
//	 message.setFrom(fromAddress);
//	 message.setText(body);
//	 message.setSubject(subject);
//	 mailSender.send(message);
	 try {
			Template t = config.getTemplate("notifyDelegateUser-template.ftl"); 		         
	         Map<String, Object> model = new HashMap<>();  
	         model.put("url", url);
	         model.put("delegatedTo",toEmail.get(i).getDelegatedToEmailId());
	         model.put("delegatedBy",toEmail.get(i).getDelegatedByEmailId());
	         model.put("password", toEmail.get(i).getPassword());	
	         model.put("apps", elem1);
	         String html = FreeMarkerTemplateUtils.processTemplateIntoString(t, model);
	         ObjectMapper objectMapper = new ObjectMapper();
	         Map<String, Object> data = new HashMap<>();  
	         data.put("To", toEmail.get(i).getDelegatedToEmailId());
	         data.put("cc", toEmail.get(i).getDelegatedByEmailId());
	         data.put("body", html);	
	         data.put("Subject", subject);
	         String requestBody = objectMapper
	        	      .writerWithDefaultPrettyPrinter()
	        	      .writeValueAsString(data);
			HttpRequest request = HttpRequest.newBuilder()
					.uri(URI.create(emailurl))
					.POST(BodyPublishers.ofString(requestBody))
					 .header("Content-Type", "application/json")
					.build();
			HttpResponse<String> response = null;
			try {
				response = HttpClient.newHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
			} catch (IOException e) {
				e.printStackTrace();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			System.out.println(response.body());
			}catch(Exception e) {
				e.printStackTrace();
			}
				 		
}


}
	
	 
}
