package com.slk.dsl.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.slk.dsl.model.Ca_App_Dependency;


public interface CaAppDependencyRepo extends JpaRepository <Ca_App_Dependency,Integer>{
 
	String deletapp = "delete from ca_app_dependency where App_Master_Id= :id";
	@Modifying
	@Transactional
	@Query(value = deletapp, nativeQuery = true)
	public void deleteapp(int id);
	
	String deleteAllapps = "delete from ca_app_dependency where Org_Id= :orgId";
	@Modifying
	@Transactional
	@Query(value = deleteAllapps, nativeQuery = true)
	public void deleteAllapps(int orgId);
}

