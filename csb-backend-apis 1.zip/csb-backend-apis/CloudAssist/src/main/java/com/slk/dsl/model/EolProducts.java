package com.slk.dsl.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ca_eol_products")

	
public class EolProducts {
	@Id @GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="product_ID")
     private int productId;
	
	@Column(name="product_Name")
    private String productName;
	
	@Column(name="product_AliasName")
    private String productAliasName;
	
	@Column(name="Rec_Ins_dt")
    private Date recInsdt;
	
	@Column(name="Rec_Upd_dt")
    private Date recUpddt;

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductAliasName() {
		return productAliasName;
	}

	public void setProductAliasName(String productAliasName) {
		this.productAliasName = productAliasName;
	}

	public Date getRecInsdt() {
		return recInsdt;
	}

	public void setRecInsdt(Date recInsdt) {
		this.recInsdt = recInsdt;
	}

	public Date getRecUpddt() {
		return recUpddt;
	}

	public void setRecUpddt(Date recUpddt) {
		this.recUpddt = recUpddt;
	}
	
}
	
