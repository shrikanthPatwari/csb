package com.slk.dsl.dto;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DetailsDTO {
	
	List<MemberDetails> members;
	String projectId;
	String projectName;
	public List<MemberDetails> getMembers() {
		return members;
	}
	public void setMembers(List<MemberDetails> members) {
		this.members = members;
	}
	public String getProjectId() {
		return projectId;
	}
	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	
	
	
	

	
}
