package com.slk.dsl.services;

import java.util.List;
import java.util.Date;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slk.dsl.model.EolProducts;
import com.slk.dsl.model.EolVersion;
import com.slk.dsl.model.MoveGroup;
import com.slk.dsl.model.UserSetup;
import com.slk.dsl.repository.EolProductsRepo;
import com.slk.dsl.repository.EolVersionRepo;
@Service

public class EolProductsService {
	@Autowired
	EolProductsRepo repo;
	

	public List<EolProducts> getProducts() {  
	    return repo.findAll(); 
	    

//	    EolProducts saveProductList(EolProducts Eolproducts) {
//			EolProducts prod = new EolProducts();
//			
//			prod.setProductName(Eolproducts.getProductName());
//			prod.setProductAliasName(Eolproducts.getProductAliasName());
//			prod.setRecInsdt(Eolproducts.getRecInsdt());
//			prod.setRecUpddt(Eolproducts.getRecUpddt());
//			return repo.save(prod);
//		}
	    
	    
	    
}

	public EolProducts saveProductList(EolProducts eolproducts) {
		// TODO Auto-generated method stub
		EolProducts prod = new EolProducts();
		
		prod.setProductName(eolproducts.getProductName());
		prod.setProductAliasName(eolproducts.getProductAliasName());
		prod.setRecInsdt(eolproducts.getRecInsdt());
		prod.setRecUpddt(eolproducts.getRecUpddt());
		return repo.save(prod);
	}

	public String delete(int id) {
		
		 repo.deleteProducts(id);
		  return "Products deleted";
	}
	public void updateProducts(EolProducts productDetails) {
        String applicationName=productDetails.getProductName();
        String aliasName=productDetails.getProductAliasName();
        Date recUpdDate=productDetails.getRecUpddt();
        int productId=productDetails.getProductId();

		
		 repo.updateProducts(applicationName,aliasName,recUpdDate,productId);
		
		
	}

}
