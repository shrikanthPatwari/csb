package com.slk.dsl.dto;

public class SubLookupDTO {
int sublookupid;
int lookupid;
String values;
public int getSublookupid() {
	return sublookupid;
}
public void setSublookupid(int sublookupid) {
	this.sublookupid = sublookupid;
}
public int getLookupid() {
	return lookupid;
}
public void setLookupid(int lookupid) {
	this.lookupid = lookupid;
}
public String getValues() {
	return values;
}
public void setValues(String values) {
	this.values = values;
}

}
