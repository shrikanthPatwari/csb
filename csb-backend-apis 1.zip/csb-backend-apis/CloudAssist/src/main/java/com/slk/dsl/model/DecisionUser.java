package com.slk.dsl.model;

import java.util.List;

import com.slk.dsl.dto.AppMasterIdAppNameDTO;
import com.slk.dsl.dto.AppNameIdDTO;

public class DecisionUser {

	private String email;
	private String firstName;
	private int orgId;
	private int userId;
	private String orgName;
	private int appCount;
//	private String appName;
	private List<AppNameIdDTO> appDetails;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public int getOrgId() {
		return orgId;
	}

	public void setOrgId(int orgId) {
		this.orgId = orgId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public int getAppCount() {
		return appCount;
	}

	public void setAppCount(int appCount) {
		this.appCount = appCount;
	}


	public List<AppNameIdDTO> getAppDetails() {
		return appDetails;
	}

	public void setAppDetails(List<AppNameIdDTO> appDetails) {
		this.appDetails = appDetails;
	}



//	public String getAppName() {
//		return appName;
//	}
//
//	public void setAppName(String appName) {
//		this.appName = appName;
//	}
	
	

}
