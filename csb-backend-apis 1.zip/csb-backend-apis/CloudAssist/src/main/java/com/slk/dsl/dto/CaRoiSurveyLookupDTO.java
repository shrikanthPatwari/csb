package com.slk.dsl.dto;

public class CaRoiSurveyLookupDTO {
	int roi_survey_lookup_Id;
	int ROI_Survey_Id;
	String ROI_Surveylookup_values;
	String is_Active;
	public int getRoi_survey_lookup_Id() {
		return roi_survey_lookup_Id;
	}
	public void setRoi_survey_lookup_Id(int roi_survey_lookup_Id) {
		this.roi_survey_lookup_Id = roi_survey_lookup_Id;
	}
	public int getROI_Survey_Id() {
		return ROI_Survey_Id;
	}
	public void setROI_Survey_Id(int rOI_Survey_Id) {
		ROI_Survey_Id = rOI_Survey_Id;
	}
	public String getROI_Surveylookup_values() {
		return ROI_Surveylookup_values;
	}
	public void setROI_Surveylookup_values(String rOI_Surveylookup_values) {
		ROI_Surveylookup_values = rOI_Surveylookup_values;
	}
	public String getIs_Active() {
		return is_Active;
	}
	public void setIs_Active(String is_Active) {
		this.is_Active = is_Active;
	}
	

}
