package com.slk.dsl.dto;

import java.math.BigInteger;

public class Lob_List_Dto {
	
	private String App_Id;
	private int App_Master_Id;









	public int getApp_Master_Id() {
		return App_Master_Id;
	}




	public void setApp_Master_Id(int app_Master_Id) {
		App_Master_Id = app_Master_Id;
	}




	public String getApp_Id() {
		return App_Id;
	}
	
	
	
	
	public void setApp_Id(String app_Id) {
		App_Id = app_Id;
	}
//	private String App_Master_id;
//	public String getApp_Master_Id() {
//		return App_Master_id;
//	}
//	public void setApp_Master_Id(String App_Master_Id) {
//		App_Master_id = App_Master_Id;
//	}
	private String App_Name;
	
	private String Comments;
	
	public String getComments() {
		return Comments;
	}
	public void setComments(String comments) {
		Comments = comments;
	}
	public String getApp_Name() {
		return App_Name;
	}
	public void setApp_Name(String app_Name) {
		App_Name = app_Name;
	}

private String App_Suv_status;
 public String getApp_Suv_Status() {
	return App_Suv_status;
}
public void setApp_Suv_Status(String App_Suv_Status) {
	App_Suv_status = App_Suv_Status;
}

private String Migration_status;
public String getMigration_Status() {
	return Migration_status;
}
public void setMigration_Status(String Migration_Status) {
	Migration_status = Migration_Status;

}
private String RLane_Strategy_id;

public String getRLane_Strategy_Id() {
	return RLane_Strategy_id;
}
public void setRLane_Strategy_Id(String RLane_Strategy_Id) {
	RLane_Strategy_id = RLane_Strategy_Id;
}

private String RLane_strategy;

public String getRLane_Strategy() {
	return RLane_strategy;
}
public void setRLane_Strategy(String RLane_Strategy) {
	RLane_strategy = RLane_Strategy;
}

}
