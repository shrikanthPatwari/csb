package com.slk.dsl.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slk.dsl.dto.AutomatedMoveGroup;
import com.slk.dsl.dto.MoveGroupCountDTO;
import com.slk.dsl.dto.MoveGroupTreeChartDTO;
import com.slk.dsl.dto.VendorandDateDTO;
import com.slk.dsl.model.AppLOBLinkingTable;
import com.slk.dsl.model.Application;
import com.slk.dsl.model.BusinessProcess1;
import com.slk.dsl.model.MoveGroup;
import com.slk.dsl.model.UserSetup;
import com.slk.dsl.repository.MoveGroupAppMappingRep;
import com.slk.dsl.repository.MoveGroupRepo;

@Service
public class MoveGroupService {
	
	
	@Autowired
	MoveGroupRepo group;
	@Autowired
	MoveGroupAppMappingRep repo;
	
	/*
	 * public MoveGroup saveMoveGroup(MoveGroup grpDetails, int orgId) { MoveGroup
	 * grp = new MoveGroup();
	 * 
	 * 
	 * grp.setMoveGroupId(grpDetails.getMoveGroupId()); grp.setOrgId(orgId);
	 * grp.setMoveGroupName(grpDetails.getMoveGroupName());
	 * grp.setMigrationStartdt(grpDetails.getMigrationStartdt());
	 * grp.setMigrationEnddt(grpDetails.getMigrationEnddt());
	 * grp.setRecInsDt(grpDetails.getRecInsDt());
	 * grp.setRecUpdDt(grpDetails.getRecUpdDt()); return group.save(grp); }
	 */
	public List<MoveGroup[]> getMoveGRoups(int orgId){
		
		return group.findByOrgId(orgId);
	}
	

public Optional<MoveGroup> getGroupById(int id){
		
		return group.findById(id);
	
}


public void updateGroup(MoveGroup grpDetails) {
	String moveGroupName=grpDetails.getMoveGroupName();
	int id=grpDetails.getMoveGroupId();
	group.updateGroup(moveGroupName,id);
	
}


public List<MoveGroupCountDTO> getMoveGroupAppCount(int orgId) {
	List<Object[]> data= group.getMoveGroupAppcount(orgId);
	List<MoveGroupCountDTO> result= new ArrayList<MoveGroupCountDTO>();
	data.stream().forEach(obj->{
		MoveGroupCountDTO temp = new MoveGroupCountDTO();
		temp.setMoveGroupAppCount(obj[0].toString());	
		temp.setMoveGroupName(obj[1].toString());
		result.add(temp);
	});
	return result;
}
public List<MoveGroupTreeChartDTO> getMoveGroupDetails(int orgId) {
	List<Object[]> data= group.getMoveGroupDetails(orgId);
	List<MoveGroupTreeChartDTO> result= new ArrayList<MoveGroupTreeChartDTO>();
	data.stream().forEach(obj->{
		MoveGroupTreeChartDTO temp = new MoveGroupTreeChartDTO();
		temp.setMove_Group_Id((Integer)obj[0]);	
		temp.setApp_Master_Id((Integer)obj[1]);
		temp.setMovegroup_App_Id((Integer)obj[2]);
		temp.setMove_Group_Name(obj[3].toString());
		temp.setApp_Name(obj[4].toString());
		temp.setLob_Name(obj[5].toString());
		temp.setApp_Id(obj[6].toString());		
		result.add(temp);
	});
	return result;
}


  //automated move group planner RFC-001 public List<AutomatedMoveGroup>
  public List<AutomatedMoveGroup> getAutomatedMoveGroupDetails(int orgId) { List<Object[]> data=
  group.getAutomatedMoveGroupDetails(orgId); List<AutomatedMoveGroup> result=
  new ArrayList<AutomatedMoveGroup>(); data.stream().forEach(obj->{
  AutomatedMoveGroup temp = new AutomatedMoveGroup();
  temp.setAppMasterId((Integer)obj[0]);
  temp.setAppMasterDependentId((Integer)obj[1]);
  temp.setApp_Complexity(obj[2].toString());
  temp.setrLane_Strategy(obj[3].toString());
  temp.setDependent_App_Complexity(obj[4].toString()); result.add(temp); });
  return result; }
 

  public MoveGroup saveMoveGroup(MoveGroup grpDetails, int orgId) {
      String name = group.findMovegroupName(orgId,grpDetails.getMoveGroupName());

     MoveGroup grp = new MoveGroup();
      if(name==null || (!name.equals(grpDetails.getMoveGroupName()))) {
      grp.setMoveGroupId(grpDetails.getMoveGroupId());
      grp.setOrgId(orgId);
      grp.setMoveGroupName(grpDetails.getMoveGroupName());
      grp.setMigrationStartdt(grpDetails.getMigrationStartdt());
      grp.setMigrationEnddt(grpDetails.getMigrationEnddt());
      grp.setRecInsDt(grpDetails.getRecInsDt());
      grp.setRecUpdDt(grpDetails.getRecUpdDt());
      return group.save(grp);
      }
      return grp;
  }
}