package com.slk.dsl.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ca_app_dependency")

	
public class Ca_App_Dependency {
	@Id @GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="App_Dependency_Id")
	private int appDependencyId;
	
	@Column(name="App_Master_Id")
	private int appMasterId;
	
	@Column(name="App_Master_Dependent_Id")
	private int appMasterDependentId;
	
	@Column(name="Org_Id")
	private int orgId; 
	
	@Column(name="Rec_Ins_Dt")
	private Date recInsDt;
	
	@Column(name="Rec_Upd_Dt")
	private Date recUpdDt;

	public int getAppDependencyId() {
		return appDependencyId;
	}

	public void setAppDependencyId(int appDependencyId) {
		this.appDependencyId = appDependencyId;
	}

	public int getAppMasterId() {
		return appMasterId;
	}

	public void setAppMasterId(int appMasterId) {
		this.appMasterId = appMasterId;
	}

	public int getAppMasterDependentId() {
		return appMasterDependentId;
	}

	public void setAppMasterDependentId(int appMasterDependentId) {
		this.appMasterDependentId = appMasterDependentId;
	}

	public int getOrgId() {
		return orgId;
	}

	public void setOrgId(int orgId) {
		this.orgId = orgId;
	}

	public Date getRecInsDt() {
		return recInsDt;
	}

	public void setRecInsDt(Date recInsDt) {
		this.recInsDt = recInsDt;
	}

	public Date getRecUpdDt() {
		return recUpdDt;
	}

	public void setRecUpdDt(Date recUpdDt) {
		this.recUpdDt = recUpdDt;
	}
	
	
}
