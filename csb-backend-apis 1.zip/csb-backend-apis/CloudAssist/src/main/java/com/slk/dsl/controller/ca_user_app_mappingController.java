package com.slk.dsl.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.slk.dsl.dto.AppIdFetchDTO;
import com.slk.dsl.dto.AppMasterIdAppNameDTO;
import com.slk.dsl.dto.DelegateSurveyDTO;
import com.slk.dsl.model.Application;
import com.slk.dsl.model.ca_user_app_mapping;
import com.slk.dsl.services.UserService;
import com.slk.dsl.services.ca_user_app_mappingService;
@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class ca_user_app_mappingController {
	@Autowired
	ca_user_app_mappingService service;
	
	 @RequestMapping(value = "/userMapping/{LobId}", method = RequestMethod.POST)
		public void userMapping(@RequestBody List<ca_user_app_mapping> userMapping,@PathVariable String LobId) {

			

			 service.saveUserMapping(userMapping,LobId);
		}
	 
	  @GetMapping("caUserMapping/{orgId}")  
	    public List<ca_user_app_mapping[]> UserMapping(@PathVariable int orgId) {  
	         return service.caUserMapping(orgId);
	          
	         
	    }
	    
	    @GetMapping("getappidappname/{lobid}")  
	    public List<AppMasterIdAppNameDTO>  getappidappname(@PathVariable int lobid) {  
	         return service.getappidappname(lobid);
	          
	         
	    }

	    @GetMapping("getappid/{userid}")  
	    public List<AppIdFetchDTO>  getappid(@PathVariable int userid) {  
	         return service.getappid(userid);
	          }
	   
	    @DeleteMapping("deleteUserApp/{id}")
		  public String delete(@PathVariable int id)  {
			  
			  service.delete(id);
			  return "App deleted";
		  }

@GetMapping("getDelegateSurveyDetails/{orgId}")
		
		public List<DelegateSurveyDTO> getAppNames1(@PathVariable int orgId){
			return service.getDelegateSurveyDetails(orgId);
	}
	

@PutMapping("/delegateuserMapping/{LobId}")
public void delegateuserMapping(@RequestBody List<ca_user_app_mapping> userMapping,@PathVariable String LobId) {
service.delegateuserMapping(userMapping,LobId);
}

@DeleteMapping("deleteUncheckedApps/{userId}/{apps}")
public String deleteUncheckedApps(@PathVariable int userId,@PathVariable int apps)  {  
	  service.deleteApps(userId,apps);
	  return "App deleted";
}

}
