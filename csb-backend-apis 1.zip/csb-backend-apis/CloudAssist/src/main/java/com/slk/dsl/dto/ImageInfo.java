package com.slk.dsl.dto;

public class ImageInfo {
	
	private String appName;
	private byte[] imageData;
	private String RlaneStrategy;

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public byte[] getImageData() {
		return imageData;
	}

	public void setImageData(byte[] imageData) {
		this.imageData = imageData;
	}

	public String getRlaneStrategy() {
		return RlaneStrategy;
	}

	public void setRlaneStrategy(String rlaneStrategy) {
		RlaneStrategy = rlaneStrategy;
	}
	
}
