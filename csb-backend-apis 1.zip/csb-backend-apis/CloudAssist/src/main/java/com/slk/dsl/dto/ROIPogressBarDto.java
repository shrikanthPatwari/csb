package com.slk.dsl.dto;

public class ROIPogressBarDto {

	
	String ROI_calculated;  
	String cost_of_Migration;
	public String getCost_of_Migration() {
		return cost_of_Migration;
	}
	public void setCost_of_Migration(String cost_of_Migration) {
		this.cost_of_Migration = cost_of_Migration;
	}
	public String getROI_calculated() {
		return ROI_calculated;
	}
	public void setROI_calculated(String rOI_calculated) {
		ROI_calculated = rOI_calculated;
	}
	
}
