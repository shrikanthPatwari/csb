package com.slk.dsl.dto;

public class AppMasterIdAppNameDTO {

	String App_Name;
	int App_Master_Id;
	public String getApp_Name() {
		return App_Name;
	}
	public void setApp_Name(String app_Name) {
		App_Name = app_Name;
	}
	public int getApp_Master_Id() {
		return App_Master_Id;
	}
	public void setApp_Master_Id(int app_Master_Id) {
		App_Master_Id = app_Master_Id;
	}
	
}
