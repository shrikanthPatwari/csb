package com.slk.dsl.dto;

public class VendorandDateDTO {
String vendorcount;
String dateupdated;
public String getVendorcount() {
	return vendorcount;
}
public void setVendorcount(String vendorcount) {
	this.vendorcount = vendorcount;
}
public String getDateupdated() {
	return dateupdated;
}
public void setDateupdated(String dateupdated) {
	this.dateupdated = dateupdated;
}

}
