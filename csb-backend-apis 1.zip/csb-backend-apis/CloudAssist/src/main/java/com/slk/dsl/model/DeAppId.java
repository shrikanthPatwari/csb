package com.slk.dsl.model;

public class DeAppId {
	int app_id;

	public int getApp_id() {
		return app_id;
	}

	public void setApp_id(int app_id) {
		this.app_id = app_id;
	}
	

}
