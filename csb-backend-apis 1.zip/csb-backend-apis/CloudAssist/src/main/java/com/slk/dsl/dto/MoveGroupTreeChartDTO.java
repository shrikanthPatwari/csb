package com.slk.dsl.dto;


public class MoveGroupTreeChartDTO {
	int Move_Group_Id;
	int App_Master_Id; 
	int Movegroup_App_Id;
    String Move_Group_Name;
    String App_Name;
    String Lob_Name;
    String App_Id;
    
	public int getMove_Group_Id() {
		return Move_Group_Id;
	}
	public void setMove_Group_Id(int move_Group_Id) {
		Move_Group_Id = move_Group_Id;
	}
	public int getApp_Master_Id() {
		return App_Master_Id;
	}
	public void setApp_Master_Id(int app_Master_Id) {
		App_Master_Id = app_Master_Id;
	}
	public int getMovegroup_App_Id() {
		return Movegroup_App_Id;
	}
	public void setMovegroup_App_Id(int movegroup_App_Id) {
		Movegroup_App_Id = movegroup_App_Id;
	}
	public String getMove_Group_Name() {
		return Move_Group_Name;
	}
	public void setMove_Group_Name(String move_Group_Name) {
		Move_Group_Name = move_Group_Name;
	}
	public String getApp_Name() {
		return App_Name;
	}
	public void setApp_Name(String app_Name) {
		App_Name = app_Name;
	}
	public String getLob_Name() {
		return Lob_Name;
	}
	public void setLob_Name(String lob_Name) {
		Lob_Name = lob_Name;
	}
	public String getApp_Id() {
		return App_Id;
	}
	public void setApp_Id(String app_Id) {
		App_Id = app_Id;
	}

}
