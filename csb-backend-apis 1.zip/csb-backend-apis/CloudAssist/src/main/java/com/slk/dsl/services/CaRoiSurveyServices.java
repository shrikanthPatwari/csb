package com.slk.dsl.services;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slk.dsl.dto.CaRoiSurveyDTO;
import com.slk.dsl.dto.CaRoiSurveyFinalDTO;
import com.slk.dsl.dto.CaRoiSurveyLookupDTO;
import com.slk.dsl.dto.DatabaseEOLDTO;
import com.slk.dsl.dto.MoveGroupTreeChartDTO;
import com.slk.dsl.dto.OsNamesDTO;
import com.slk.dsl.dto.ROIPogressBarDto;
import com.slk.dsl.repository.CaRoiSurveyDAO;
import com.slk.dsl.repository.EOLDao;
@Service
public class CaRoiSurveyServices {
	@Autowired
	CaRoiSurveyDAO repo;
	public List<CaRoiSurveyFinalDTO> getCaRoiSurvey(){
		List<Object[]> data= repo.getCaRoiSurvey();
		List<Object[]> data1= repo.getCaRoiSurveyLookup();
		List<CaRoiSurveyDTO> result1 = new ArrayList<CaRoiSurveyDTO>();
		List<CaRoiSurveyLookupDTO> result2 = new ArrayList<CaRoiSurveyLookupDTO>();
		List<CaRoiSurveyFinalDTO> FinalList = new ArrayList<CaRoiSurveyFinalDTO>();
		data.stream().forEach(obj->{
			CaRoiSurveyDTO temp =new CaRoiSurveyDTO();
			temp.setROI_Survey_Id((Integer)obj[0]);
			temp.setROI_Survey_Category(obj[1].toString());
			temp.setROI_Survey_Question(obj[2].toString());
			temp.setIs_Active(obj[3].toString());
			result1.add(temp);
		});
		data1.stream().forEach(obj->{
			CaRoiSurveyLookupDTO temp = new CaRoiSurveyLookupDTO();
			temp.setRoi_survey_lookup_Id((Integer)obj[0]);
			temp.setROI_Survey_Id((Integer)obj[1]);
			temp.setROI_Surveylookup_values(obj[2].toString());
			temp.setIs_Active(obj[3].toString());
			result2.add(temp);
		});
	for(int i=0;i<result1.size();i++)
	{
		CaRoiSurveyFinalDTO finalresult = new CaRoiSurveyFinalDTO();
		finalresult.setROI_Survey_Id(result1.get(i).getROI_Survey_Id());
		finalresult.setROI_Survey_Question(result1.get(i).getROI_Survey_Question());
		finalresult.setROI_Survey_Category(result1.get(i).getROI_Survey_Category());
		finalresult.setIs_Active(result1.get(i).getIs_Active());
		List<String> values = new ArrayList<String>();
		for(int j=0;j<result2.size();j++) {
		
		
			
			if(result1.get(i).getROI_Survey_Id()== result2.get(j).getROI_Survey_Id()) {
//				finalresult.setMultiValues(result2.get(j).getROI_Surveylookup_values());
			values.add(result2.get(j).getROI_Surveylookup_values());
				
			}
		}
		finalresult.setMultiValues(values);
		FinalList.add(finalresult);
	}
	
	return FinalList;
			
		}
	
	public List<ROIPogressBarDto> getROIProgressBar(int orgId) {
		List<Object[]> data= repo.getROIProgressBar(orgId);
		List<ROIPogressBarDto> result= new ArrayList<ROIPogressBarDto>();

		data.stream().forEach(obj ->{
			ROIPogressBarDto temp = new ROIPogressBarDto();
			temp.setCost_of_Migration(obj[0].toString());
			temp.setROI_calculated(obj[1].toString());	
			result.add(temp);
		});
		return result;
}
	
}