package com.slk.dsl.dto;

import java.math.BigInteger;

public class migrationdto {
BigInteger num;
String Migration_Strategy;
public BigInteger getNum() {
	return num;
}  //check
public void setNum(BigInteger num) {
	this.num = num;
}
public String getMigration_Strategy() {
	return Migration_Strategy;
}
public void setMigration_Strategy(String migration_Strategy) {
	Migration_Strategy = migration_Strategy;
}

}
