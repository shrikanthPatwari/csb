package com.slk.dsl.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.slk.dsl.dto.MoveGroupRehostApplicationsDTO;
import com.slk.dsl.dto.ProcessDataDTO;
import com.slk.dsl.model.Application;
import com.slk.dsl.model.ProcessDataModel;
import com.slk.dsl.services.ProcessDataService;



@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")

public class ProcessDataController {
	@Autowired
	ProcessDataService service;
	 
	 @GetMapping("data-process/{orgId}")  
	    public List<ProcessDataModel> allBaseApps(@PathVariable int orgId) {  
	         return service.getProcessData(orgId);
	          
	    }


		@PostMapping("/addProcess")
		public ProcessDataModel addProcessData(@RequestBody ProcessDataModel processData) {
			service.saveProcess(processData);
			return processData;
		}

         @GetMapping("getProcessAppNames/{orgId}")
		public List<ProcessDataDTO> getAppNames(@PathVariable int orgId){
			return service.getProcessapp(orgId);
	}
         @DeleteMapping("/deleteprocessrecord/{AppId}")  
		    private void deleteProcess(@PathVariable("AppId") int AppId)   
		    {  
		    	service.delete(AppId);  
		    } 
	 
         
         @PutMapping("updateProcess")
			public void updateProcess(@RequestBody List<ProcessDataModel> processDetails) {
			  service.updateProcess(processDetails);
		  }
}
