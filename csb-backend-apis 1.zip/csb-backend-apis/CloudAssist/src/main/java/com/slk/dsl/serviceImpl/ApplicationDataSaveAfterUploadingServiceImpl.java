package com.slk.dsl.serviceImpl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.slk.dsl.model.Application;
import com.slk.dsl.model.CaAppmasterTechstack;
import com.slk.dsl.model.InfraAppMappingTable;
import com.slk.dsl.model.InfraDataModel;
import com.slk.dsl.model.LOB;
import com.slk.dsl.model.ProcessDataModel;
import com.slk.dsl.repository.ApplicationRepository;
import com.slk.dsl.repository.CAAppMasterDAO;
import com.slk.dsl.repository.CaAppDependencyRepo;
import com.slk.dsl.repository.CaAppmasterTechstackDAO;
import com.slk.dsl.repository.InfraApplicationMappingDAO;
import com.slk.dsl.repository.InfraDataUploadDAO;
import com.slk.dsl.repository.LOBRepo;
import com.slk.dsl.repository.MoveGroupAppMappingRep;
import com.slk.dsl.repository.ProcessDataRepo;
import com.slk.dsl.repository.ca_user_app_mappingDAO;
import com.slk.dsl.services.ApplicationDataSaveAfterUploadingService;

@Service

public class ApplicationDataSaveAfterUploadingServiceImpl implements ApplicationDataSaveAfterUploadingService {

	@Autowired
	ApplicationRepository repo;
	@Autowired
	InfraApplicationMappingDAO mappingRepo;
	@Autowired
	LOBRepo repoLob;
	@Autowired
	InfraDataUploadDAO infraRepo;
	@Autowired
	CAAppMasterDAO repoapp;
	@Autowired
	ProcessDataRepo repoprocess;
	@Autowired
	CaAppmasterTechstackDAO techStackRepo;
	@Autowired
	MoveGroupAppMappingRep MoveGroupAppRepo;
	@Autowired
	ca_user_app_mappingDAO caUserRepo;
	@Autowired
	CaAppDependencyRepo dependentAppRepo;

	@Override
	public boolean saveAppDataFromUploadFile(MultipartFile file, int orgId) throws IOException {

		boolean isFlag = false;

		isFlag = readDataFromExcel(file, orgId);

		return isFlag;
	}

	private boolean readDataFromExcel(MultipartFile file, int orgId) throws IOException {

		boolean FileUploaded = false;
		String fileNameWithOutExt = FilenameUtils.removeExtension(file.getOriginalFilename());
		//uploading app discovery data
		if (fileNameWithOutExt.equalsIgnoreCase("App Discovery Data")) {

			// Delete ca_infra_mapping details,ca_infra_details and ca_app_master details
			List<Application> appDet = new ArrayList<Application>();
			List<CaAppmasterTechstack> mapping = new ArrayList<CaAppmasterTechstack>();

			Workbook workbook = getWorkbook(file);

			Sheet sheet = workbook.getSheetAt(0);

			System.out.println(sheet.getLastRowNum());

			Iterator<Row> rows = sheet.iterator();

			rows.next();

			while (rows.hasNext()) {

				long size = file.getSize();
				System.out.println("Intial file byte" + size);

				Row row = rows.next();

				if (isCellEmpty(row.getCell(0))) {
					break;
				}
				LOB lob = new LOB();

				lob.setRecInsDt(new java.util.Date());
				lob.setRecUpdDt(new java.util.Date());
				lob.setOrgId(orgId);
				if (row.getCell(5) != null && row.getCell(5).getCellType() == CellType.STRING) {
					lob.setLobManager(row.getCell(5).getStringCellValue());

				}

				if (row.getCell(3) != null && row.getCell(3).getCellType() == CellType.STRING) {
					lob.setLobName(row.getCell(3).getStringCellValue());

				}

				List<Object[]> lobVal = repoLob.getlobDistinctValues(lob.getOrgId(), lob.getLobName());

				if (lobVal.isEmpty()) {
					// if lobval is null then save the record into db
					repoLob.save(lob);

					Application files = new Application();

					files.setOrgId(orgId);
					// files.setAppSeq("1");
					files.setRecInsDt(new java.util.Date());
					files.setRecUpdDt(new java.util.Date());

					files.setLobId(lob.getLobId());

					if (row.getCell(0) != null && row.getCell(0).getCellType() == CellType.NUMERIC) {
						double appId = Double.parseDouble(row.getCell(0).toString());
						int applicationId = (int) appId;

						String appsId = String.valueOf(applicationId);
						files.setAppId(appsId);
					}

					if (row.getCell(1) != null && row.getCell(1).getCellType() == CellType.STRING) {
						files.setAppName(row.getCell(1).getStringCellValue());
					}

					if (row.getCell(2) != null && row.getCell(2).getCellType() == CellType.STRING) {
						files.setAppDesc(row.getCell(2).getStringCellValue());
					}

					if (row.getCell(4) != null && row.getCell(4).getCellType() == CellType.STRING) {
						files.setAppManager(row.getCell(4).getStringCellValue());
					}
					if (row.getCell(6) != null && row.getCell(6).getCellType() == CellType.STRING) {
						files.setVendorName(row.getCell(6).getStringCellValue());
					}
					if (row.getCell(7) != null && row.getCell(7).getCellType() == CellType.STRING) {
						files.setDataCatApp(row.getCell(7).getStringCellValue());
					}
					if (row.getCell(8) != null && row.getCell(8).getCellType() == CellType.STRING) {
						files.setApplicationCriticality(row.getCell(8).getStringCellValue());
					}
					if (row.getCell(9) != null && row.getCell(9).getCellType() == CellType.STRING) {
						files.setDatabaseType(row.getCell(9).getStringCellValue());
					}
					if (row.getCell(10) != null && row.getCell(10).getCellType() == CellType.STRING) {
						files.setDatabaseVersion(row.getCell(10).getStringCellValue());
					}
					String version = null;
					if (row.getCell(10) != null && row.getCell(10).getCellType() == CellType.NUMERIC) {
						double versionId = Double.parseDouble(row.getCell(10).toString());
						double databaseId = (double) versionId;
						version = String.valueOf(databaseId);

						files.setDatabaseVersion(version);

					}

					if (row.getCell(11) != null && row.getCell(11).getCellType() == CellType.STRING) {
						
						files.setAppServerType(row.getCell(11).getStringCellValue());
					}

					if (row.getCell(12) != null && row.getCell(12).getCellType() == CellType.NUMERIC) {
						double versionId = Double.parseDouble(row.getCell(12).toString());
						double databaseId = (double) versionId;
						version = String.valueOf(databaseId);
						
						files.setAppServerVersion(version);
					}

					if (row.getCell(13) != null && row.getCell(13).getCellType() == CellType.STRING) {
						files.setWebServerType(row.getCell(13).getStringCellValue());
					}
					if (row.getCell(14) != null && row.getCell(14).getCellType() == CellType.NUMERIC) {
						double versionId = Double.parseDouble(row.getCell(14).toString());
						double databaseId = (double) versionId;
						version = String.valueOf(databaseId);
						files.setWebServerVersion(version);
					}

					appDet.add(files);

				} else {
					// else just take the lobid from that record
					lobVal.stream().forEach(objects -> {

						lob.setLobId((Integer) objects[0]);
					});

					Application files = new Application();

					files.setOrgId(orgId);
					// files.setAppSeq("1");
					files.setRecInsDt(new java.util.Date());
					files.setRecUpdDt(new java.util.Date());

					files.setLobId(lob.getLobId());

					if (row.getCell(0) != null && row.getCell(0).getCellType() == CellType.NUMERIC) {
						double appId = Double.parseDouble(row.getCell(0).toString());
						int applicationId = (int) appId;

						String appsId = String.valueOf(applicationId);
						files.setAppId(appsId);
					}

					if (row.getCell(1) != null && row.getCell(1).getCellType() == CellType.STRING) {
						files.setAppName(row.getCell(1).getStringCellValue());
					}

					if (row.getCell(2) != null && row.getCell(2).getCellType() == CellType.STRING) {
						files.setAppDesc(row.getCell(2).getStringCellValue());
					}

					if (row.getCell(4) != null && row.getCell(4).getCellType() == CellType.STRING) {
						files.setAppManager(row.getCell(4).getStringCellValue());
					}
					if (row.getCell(6) != null && row.getCell(6).getCellType() == CellType.STRING) {
						files.setVendorName(row.getCell(6).getStringCellValue());
					}
					if (row.getCell(7) != null && row.getCell(7).getCellType() == CellType.STRING) {
						files.setDataCatApp(row.getCell(7).getStringCellValue());
					}
					if (row.getCell(8) != null && row.getCell(8).getCellType() == CellType.STRING) {
						files.setApplicationCriticality(row.getCell(8).getStringCellValue());
					}
					if (row.getCell(9) != null && row.getCell(9).getCellType() == CellType.STRING) {
						files.setDatabaseType(row.getCell(9).getStringCellValue());
					}
					if (row.getCell(10) != null && row.getCell(10).getCellType() == CellType.STRING) {
						files.setDatabaseVersion(row.getCell(10).getStringCellValue());
					}
					String version = null;
					if (row.getCell(10) != null && row.getCell(10).getCellType() == CellType.NUMERIC) {
						double versionId = Double.parseDouble(row.getCell(10).toString());
						double databaseId = (double) versionId;
						version = String.valueOf(databaseId);

						files.setDatabaseVersion(version);

					}

					if (row.getCell(11) != null && row.getCell(11).getCellType() == CellType.STRING) {
						files.setAppServerType(row.getCell(11).getStringCellValue());
					}

					if (row.getCell(12) != null && row.getCell(12).getCellType() == CellType.NUMERIC) {
						double versionId = Double.parseDouble(row.getCell(12).toString());
						double databaseId = (double) versionId;
						version = String.valueOf(databaseId);
						
						files.setAppServerVersion(version);
					}
					

					if (row.getCell(13) != null && row.getCell(13).getCellType() == CellType.STRING) {
						files.setWebServerType(row.getCell(13).getStringCellValue());
					}
					if (row.getCell(14) != null && row.getCell(14).getCellType() == CellType.NUMERIC) {
						
						double versionId = Double.parseDouble(row.getCell(14).toString());
						double databaseId = (double) versionId;
						version = String.valueOf(databaseId);
						files.setWebServerVersion(version);
				
					}

					appDet.add(files);

				}

			}
			//delete all the child table data
			techStackRepo.deleteAppMapping(orgId);
			repoprocess.deleteProcess(orgId);
			mappingRepo.deleteInfraMapping(orgId);
			infraRepo.deleteInfraMapping(orgId);
			MoveGroupAppRepo.deleteappMapping(orgId);
			caUserRepo.deleteappMapping(orgId);
			dependentAppRepo.deleteAllapps(orgId);
			repo.deleteApps(orgId);
            
			repo.saveAll(appDet);

			Sheet sheet1 = workbook.getSheetAt(1);

			System.out.println(sheet.getLastRowNum());

			Iterator<Row> row = sheet1.iterator();

			row.next();

			while (row.hasNext()) {

				Row row1 = row.next();

				if (isCellEmpty(row1.getCell(0))) {
					break;
				}

				CaAppmasterTechstack files = new CaAppmasterTechstack();
				files.setRecInsDt(new java.util.Date());
				files.setRecUpdDt(new java.util.Date());
				files.setOrgId(orgId);
				String appsId = null;
				if (row1.getCell(0) != null && row1.getCell(0).getCellType() == CellType.NUMERIC) {
					double appId = Double.parseDouble(row1.getCell(0).toString());
					int applicationId = (int) appId;
					appsId = String.valueOf(applicationId);
				}

				if (row1.getCell(2) != null && row1.getCell(2).getCellType() == CellType.STRING) {
					files.setProgLanguage(row1.getCell(2).getStringCellValue());
				}

				if (row1.getCell(3) != null && row1.getCell(3).getCellType() == CellType.STRING) {
					files.setProgLanguageversion(row1.getCell(3).getStringCellValue());

				}
				String version = null;
				if (row1.getCell(3) != null && row1.getCell(3).getCellType() == CellType.NUMERIC) {
					double versionId = Double.parseDouble(row1.getCell(3).toString());
					double progId = (double) versionId;
					version = String.valueOf(progId);
					files.setProgLanguageversion(version);
				}

				List<Object[]> appMasterId = techStackRepo.getAppMasterId(appsId);
				System.out.println(appMasterId + "App master ID");
				if (!appMasterId.isEmpty()) {
					appMasterId.stream().forEach(objects -> {
						files.setAppMasterId((Integer) objects[0]);
						mapping.add(files);
					});
				}
			}

			techStackRepo.saveAll(mapping);
			FileUploaded = true;
			return FileUploaded;
		}
		
//uploading process discovery data
		else if (fileNameWithOutExt.equalsIgnoreCase("Process Discovery Data")) {
			List<Application> appmodel = repoapp.findAll();

			List<ProcessDataModel> processData = new ArrayList<ProcessDataModel>();
			Workbook workbook = getWorkbook(file);
			byte Bytes[] = file.getBytes();

			Sheet sheet = workbook.getSheetAt(0);
			Iterator<Row> rows = sheet.iterator();
			rows.next();

			while (rows.hasNext()) {

				Row row = rows.next();

				if (isCellEmpty(row.getCell(1))) {
					break;
				}
				ProcessDataModel serverDataprocess = new ProcessDataModel();

				serverDataprocess.setOrgId(orgId);
				if (row.getCell(0) != null && row.getCell(0).getCellType() == CellType.NUMERIC) {
					double appId = Double.parseDouble(row.getCell(0).toString());
					int applicationId = (int) appId;
					for (int i = 0; i < appmodel.size(); i++) {
						if (applicationId == Integer.valueOf(appmodel.get(i).getAppId())) {
							serverDataprocess.setAppMasterId(appmodel.get(i).getAppMasterId());
							break;
						}
					}

				}

				if (serverDataprocess.getAppMasterId() != 0) {
					if (row.getCell(1) != null && row.getCell(1).getCellType() == CellType.STRING) {
						serverDataprocess.setBusinessOwner(row.getCell(1).getStringCellValue());
					}

					if (row.getCell(2) != null && row.getCell(2).getCellType() == CellType.NUMERIC) {
						double BOemployeeId = Double.parseDouble(row.getCell(2).toString());
						int boempId = (int) BOemployeeId;
						String id = String.valueOf(boempId);
						serverDataprocess.setBusinessOwnerEmployeeID(id);

					}

					if (row.getCell(3) != null && row.getCell(3).getCellType() == CellType.STRING) {
						serverDataprocess.setBusinessManager(row.getCell(3).getStringCellValue());

					}
					if (row.getCell(4) != null && row.getCell(4).getCellType() == CellType.NUMERIC) {
						double BusinessManageremployeeId = Double.parseDouble(row.getCell(4).toString());
						int BusinessManagerempId = (int) BusinessManageremployeeId;
						String id = String.valueOf(BusinessManagerempId);
						serverDataprocess.setBusinessManagerEmployeeID(id);

					}

					if (row.getCell(5) != null && row.getCell(5).getCellType() == CellType.STRING) {
						serverDataprocess.seteTDirector(row.getCell(5).getStringCellValue());

					}
					if (row.getCell(6) != null && row.getCell(6).getCellType() == CellType.NUMERIC) {
						double eTDirectoremployeeId = Double.parseDouble(row.getCell(6).toString());
						int eTDirectorempId = (int) eTDirectoremployeeId;
						String id = String.valueOf(eTDirectorempId);
						serverDataprocess.seteTDirectorEmployeeID(id);
					}
					if (row.getCell(7) != null && row.getCell(7).getCellType() == CellType.STRING) {
						serverDataprocess.seteTManager(row.getCell(7).getStringCellValue());

					}

					if (row.getCell(8) != null && row.getCell(8).getCellType() == CellType.NUMERIC) {
						double eTManageremployeeId = Double.parseDouble(row.getCell(8).toString());
						int eTManagerempId = (int) eTManageremployeeId;
						String id = String.valueOf(eTManagerempId);
						serverDataprocess.seteTManagerEmployeeID(id);

					}

					if (row.getCell(9) != null && row.getCell(9).getCellType() == CellType.STRING) {
						serverDataprocess.seteTPrimaryTechnical(row.getCell(9).getStringCellValue());

					}

					if (row.getCell(10) != null && row.getCell(10).getCellType() == CellType.NUMERIC) {
						double eTPrimaryTechnicalemployeeId = Double.parseDouble(row.getCell(10).toString());
						int eTPrimaryTechnicalempId = (int) eTPrimaryTechnicalemployeeId;
						String id = String.valueOf(eTPrimaryTechnicalempId);
						serverDataprocess.seteTPrimaryTechnicalEmployeeID(id);

					}
			
					if (row.getCell(11) != null && row.getCell(11).getCellType() == CellType.STRING) {
						serverDataprocess.seteTSecondaryTechnical(row.getCell(11).getStringCellValue());

					}
		
					if (row.getCell(12) != null && row.getCell(12).getCellType() == CellType.NUMERIC) {
						double eTSecondaryTechnicalemployeeId = Double.parseDouble(row.getCell(12).toString());
						int eTSecondaryTechnicalempId = (int) eTSecondaryTechnicalemployeeId;
						String id = String.valueOf(eTSecondaryTechnicalempId);
						serverDataprocess.seteTSecondaryTechnicalEmployeeID(id);

					}

					if (row.getCell(13) != null && row.getCell(13).getCellType() == CellType.STRING) {
						serverDataprocess.setSCName(row.getCell(13).getStringCellValue());

					}

					if (row.getCell(14) != null && row.getCell(14).getCellType() == CellType.STRING) {
						serverDataprocess.setDomain(row.getCell(14).getStringCellValue());

					}
					if (row.getCell(15) != null && row.getCell(15).getCellType() == CellType.NUMERIC) {
						serverDataprocess.setManagerCertification(row.getCell(15).toString());

					}

					if (row.getCell(16) != null && row.getCell(16).getCellType() == CellType.NUMERIC) {

						serverDataprocess.setQualityScore(row.getCell(16).toString());

					}

					if (row.getCell(17) != null && row.getCell(17).getCellType() == CellType.STRING) {
						serverDataprocess.setDRExerciseResults(row.getCell(17).toString());

					}

					if (row.getCell(18) != null && row.getCell(18).getCellType() == CellType.STRING) {
						serverDataprocess.setApplicationDRPlan(row.getCell(18).toString());

					}

					if (row.getCell(19) != null && row.getCell(19).getCellType() == CellType.NUMERIC) {
						serverDataprocess.setDRExerciseDate(row.getCell(19).toString());

					}

					if (row.getCell(20) != null && row.getCell(20).getCellType() == CellType.STRING) {
						serverDataprocess.setDRTier(row.getCell(20).toString());

					}

					if (row.getCell(21) != null && row.getCell(21).getCellType() == CellType.NUMERIC) {
						serverDataprocess.setDRPlanDate(row.getCell(21).toString());

					}

					processData.add(serverDataprocess);
				}
			}
			repoprocess.deleteProcess(orgId);

			repoprocess.saveAll(processData);
		}
//Upload Infra discovery data
		else if (fileNameWithOutExt.equalsIgnoreCase("Infra Discovery Data")) {

			List<InfraDataModel> infraDet = new ArrayList<InfraDataModel>();
			List<InfraAppMappingTable> mapping = new ArrayList<InfraAppMappingTable>();
			Workbook workbook = getWorkbook(file);
			byte Bytes[] = file.getBytes();

			Sheet sheet = workbook.getSheetAt(0);

			System.out.println(sheet.getLastRowNum());

			Iterator<Row> rows = sheet.iterator();

			rows.next();

			while (rows.hasNext()) {

				Row row = rows.next();

				if (isCellEmpty(row.getCell(1))) {
					break;
				}

				InfraDataModel serverData = new InfraDataModel();

				serverData.setOrgId(orgId);
				serverData.setRecInsDt(new java.util.Date());

				if (row.getCell(0) != null && row.getCell(0).getCellType() == CellType.STRING) {
					serverData.setHostName((row.getCell(0).getStringCellValue()));

				}

				if (row.getCell(1) != null && row.getCell(1).getCellType() == CellType.STRING) {
					serverData.setIpAddress(row.getCell(1).getStringCellValue());
				}
				if (row.getCell(2) != null && row.getCell(2).getCellType() == CellType.STRING) {
					serverData.setHypervisor(row.getCell(2).getStringCellValue());
				}
				if (row.getCell(3) != null && row.getCell(3).getCellType() == CellType.STRING) {
					serverData.setOsType(row.getCell(3).getStringCellValue());
				}

				if (row.getCell(4) != null && row.getCell(4).getCellType() == CellType.STRING) {
					serverData.setOsVersion(row.getCell(4).getStringCellValue());
				}
				if (row.getCell(5) != null && row.getCell(5).getCellType() == CellType.STRING) {
					serverData.setOsBitness(row.getCell(5).getStringCellValue());
				}
				if (row.getCell(6) != null && row.getCell(6).getCellType() == CellType.STRING) {
					serverData.setPhysicalOrVirtual(row.getCell(6).getStringCellValue());
				}
				if (row.getCell(7) != null && row.getCell(7).getCellType() == CellType.STRING) {
					serverData.setServerType(row.getCell(7).getStringCellValue());
				}
				if (row.getCell(8) != null && row.getCell(8).getCellType() == CellType.STRING) {
					serverData.setEnvironment(row.getCell(8).getStringCellValue());
				}

				if (row.getCell(9) != null && row.getCell(9).getCellType() == CellType.STRING) {
					serverData.setDataCenter(row.getCell(9).getStringCellValue());
				}
				if (row.getCell(10) != null && row.getCell(10).getCellType() == CellType.STRING) {
					serverData.setBusinessUnit(row.getCell(10).getStringCellValue());
				}
				if (row.getCell(11) != null && row.getCell(11).getCellType() == CellType.STRING) {
					serverData.setServerOwner(row.getCell(11).getStringCellValue());
				}
				if (row.getCell(12) != null && row.getCell(12).getCellType() == CellType.STRING) {
					serverData.setInScope(row.getCell(12).getStringCellValue());
				}
				if (row.getCell(13) != null && row.getCell(13).getCellType() == CellType.STRING) {
					serverData.setCpuType(row.getCell(13).getStringCellValue());
				}
				if (row.getCell(14) != null && row.getCell(14).getCellType() == CellType.NUMERIC) {
					double CPU = Double.parseDouble(row.getCell(14).toString());
				

					String appsId = String.valueOf(CPU);
					serverData.setCpu(appsId);
				}
				if (row.getCell(15) != null && row.getCell(15).getCellType() == CellType.NUMERIC) {
					double TotalCores = Double.parseDouble(row.getCell(15).toString());
					

					String TotalCoresfinal = String.valueOf(TotalCores);
					serverData.setTotalCores(TotalCoresfinal);
				}
				if (row.getCell(16) != null && row.getCell(16).getCellType() == CellType.NUMERIC) {
					double Memory =  Double.parseDouble(row.getCell(16).toString());
					

					String Memoryfinal = String.valueOf(Memory);
					serverData.setMemory(Memoryfinal);
				}
				if (row.getCell(17) != null && row.getCell(17).getCellType() == CellType.NUMERIC) {
					double DiskSize =  Double.parseDouble(row.getCell(17).toString());
					

					String DiskSizefinal = String.valueOf(DiskSize);
				
					serverData.setDiskSize(DiskSizefinal);
				}
				if (row.getCell(18) != null && row.getCell(18).getCellType() == CellType.NUMERIC) {
					double DiskFreeSpace =  Double.parseDouble(row.getCell(18).toString());
					

					String DiskFreeSpacefinal = String.valueOf(DiskFreeSpace);
					
					serverData.setDiskFreeSpace(DiskFreeSpacefinal);
				}
				if (row.getCell(19) != null && row.getCell(19).getCellType() == CellType.NUMERIC) {
	double AvgCpuUsage =  Double.parseDouble(row.getCell(19).toString());
					

					String AvgCpuUsagefinal = String.valueOf(AvgCpuUsage);
					
					serverData.setAvgCpuUsage(AvgCpuUsagefinal);
				}
				if (row.getCell(20) != null && row.getCell(20).getCellType() == CellType.NUMERIC) {
	double AvgMemoryUsage =  Double.parseDouble(row.getCell(20).toString());
				

					String AvgMemoryUsagefinal = String.valueOf(AvgMemoryUsage);
					serverData.setAvgMemoryUsage(AvgMemoryUsagefinal);
				}
				if (row.getCell(21) != null && row.getCell(21).getCellType() == CellType.NUMERIC) {
	double PeakCpuUsage =  Double.parseDouble(row.getCell(21).toString());
					

					String PeakCpuUsagefinal = String.valueOf(PeakCpuUsage);
					serverData.setPeakCpuUsage(PeakCpuUsagefinal);
				}
				if (row.getCell(22) != null && row.getCell(22).getCellType() == CellType.NUMERIC) {
double PeakMemoryUsag =  Double.parseDouble(row.getCell(22).toString());
					

					String PeakMemoryUsagfinal = String.valueOf(PeakMemoryUsag);
					serverData.setPeakMemoryUsage(PeakMemoryUsagfinal);
				}
				if (row.getCell(23) != null && row.getCell(23).getCellType() == CellType.NUMERIC) {
double AvarageStorageIOPS =  Double.parseDouble(row.getCell(23).toString());
					

					String AvarageStorageIOPSfinal = String.valueOf(AvarageStorageIOPS);
					serverData.setAvarageStorageIOPS(AvarageStorageIOPSfinal);
				}
				if (row.getCell(24) != null && row.getCell(24).getCellType() == CellType.NUMERIC) {
double PeakStorageIOPS =  Double.parseDouble(row.getCell(24).toString());
					

					String PeakStorageIOPSfinal = String.valueOf(PeakStorageIOPS);
					serverData.setPeakStorageIOPS(PeakStorageIOPSfinal);
				}
				if (row.getCell(25) != null && row.getCell(25).getCellType() == CellType.NUMERIC) {
double AvgStorageReadIOPS =  Double.parseDouble(row.getCell(25).toString());
					

					String AvgStorageReadIOPSfinal = String.valueOf(AvgStorageReadIOPS);
					serverData.setAvgStorageReadIOPS(AvgStorageReadIOPSfinal);
				}
				if (row.getCell(26) != null && row.getCell(26).getCellType() == CellType.NUMERIC) {
double AvgStorageWriteIOPS =  Double.parseDouble(row.getCell(26).toString());
					

					String AvgStorageWriteIOPSfinal = String.valueOf(AvgStorageWriteIOPS);
					serverData.setAvgStorageWriteIOPS(AvgStorageWriteIOPSfinal);
				}
				if (row.getCell(27) != null && row.getCell(27).getCellType() == CellType.NUMERIC) {
double PeakNetworkUsage =  Double.parseDouble(row.getCell(27).toString());
					

					String PeakNetworkUsageSfinal = String.valueOf(PeakNetworkUsage);
					serverData.setPeakNetworkUsage(PeakNetworkUsageSfinal);
				}
				if (row.getCell(28) != null && row.getCell(28).getCellType() == CellType.NUMERIC) {
double MaxNetworkUsageRate =  Double.parseDouble(row.getCell(28).toString());
					

					String MaxNetworkUsageRatefinal = String.valueOf(MaxNetworkUsageRate);
					serverData.setMaxNetworkUsageRate(MaxNetworkUsageRatefinal);
				}

				infraDet.add(serverData);

			}
			mappingRepo.deleteInfraMapping(orgId);
			infraRepo.deleteInfraMapping(orgId);

			infraRepo.saveAll(infraDet);

			Sheet sheet1 = workbook.getSheetAt(1);

			System.out.println(sheet.getLastRowNum());

			Iterator<Row> row = sheet1.iterator();

			row.next();

			while (row.hasNext()) {

				Row row1 = row.next();

				if (isCellEmpty(row1.getCell(0))) {
					break;
				}

				InfraAppMappingTable files = new InfraAppMappingTable();
				files.setRecInsDt(new java.util.Date());
				files.setRecUpdDt(new java.util.Date());
				files.setOrgId(orgId);
				String appsId = null;
				String hostName = null;
				String IpAddress = null;
				;
				if (row1.getCell(0) != null && row1.getCell(0).getCellType() == CellType.NUMERIC) {
					double appId = Double.parseDouble(row1.getCell(0).toString());
					int applicationId = (int) appId;
					appsId = String.valueOf(applicationId);
				}
				if (row1.getCell(2) != null && row1.getCell(2).getCellType() == CellType.STRING) {
					hostName = row1.getCell(2).getStringCellValue();
				}
				if (row1.getCell(3) != null && row1.getCell(3).getCellType() == CellType.STRING) {
					IpAddress = row1.getCell(3).getStringCellValue();

				}
				List<Object[]> appMasterId = mappingRepo.getAppMasterId(appsId);
				System.out.println(appMasterId + "App master ID");
				List<Object[]> infraId = mappingRepo.getInfraId(hostName, IpAddress);

				if (!appMasterId.isEmpty() && !infraId.isEmpty()) {
					appMasterId.stream().forEach(objects -> {

						files.setAppMasterId((Integer) objects[0]);

					});

					infraId.stream().forEach(objects -> {

						files.setInfraId((Integer) objects[0]);
						mapping.add(files);
					});

				}

			}

			mappingRepo.saveAll(mapping);

			FileUploaded = true;
			return FileUploaded;

		}

		return FileUploaded;

	}

	private String lobDesc() {
		// TODO Auto-generated method stub
		return null;
	}

	private boolean isRowEmpty(Row row1) {
		boolean isEmpty = true;
		DataFormatter dataFormatter = new DataFormatter();

		if (row1 != null) {
			for (Cell cell : row1) {
				if (dataFormatter.formatCellValue(cell).trim().length() > 0) {
					isEmpty = false;
					break;
				}
			}
		}

		return isEmpty;
	}

	private Workbook getWorkbook(MultipartFile file) {
		// TODO Auto-generated method stub

		Workbook workbook = null;
		try {
			workbook = new XSSFWorkbook(file.getInputStream());

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return workbook;
	}

	public static boolean isCellEmpty(final Cell cell) {
		if (cell == null || cell.getCellType() == CellType.BLANK) {
			return true;
		}
		if (cell.getCellType() == CellType.STRING && cell.getStringCellValue().isEmpty()) {
			return true;
		}
		return false;
	}

	public static boolean isColumnEmpty(Sheet sheet, int columnIndex, int startRow) {
		for (Row row : sheet) {
			if (row.getRowNum() < startRow)
				continue;
			Cell cell = row.getCell(columnIndex);
			if (cell != null) {
				return false;
			}
		}
		return true;
	}

}
