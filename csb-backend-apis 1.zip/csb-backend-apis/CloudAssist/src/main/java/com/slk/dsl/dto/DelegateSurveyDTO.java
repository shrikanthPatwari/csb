package com.slk.dsl.dto;

public class DelegateSurveyDTO {
	int Usr_Id;
	int App_Master_Id;
	int Delegated_Usr_Id;
	String App_Name;
	String Assigned_By;
	String Assigned_To;
	int App_Suv_Status;
	String Assigned_By_MailId;
	String Assigned_To_MailId;
	public String getAssigned_By_MailId() {
		return Assigned_By_MailId;
	}
	public void setAssigned_By_MailId(String assigned_By_MailId) {
		Assigned_By_MailId = assigned_By_MailId;
	}
	public String getAssigned_To_MailId() {
		return Assigned_To_MailId;
	}
	public void setAssigned_To_MailId(String assigned_To_MailId) {
		Assigned_To_MailId = assigned_To_MailId;
	}
	public int getUsr_Id() {
		return Usr_Id;
	}
	public void setUsr_Id(int usr_Id) {
		Usr_Id = usr_Id;
	}
	public int getApp_Master_Id() {
		return App_Master_Id;
	}
	public void setApp_Master_Id(int app_Master_Id) {
		App_Master_Id = app_Master_Id;
	}
	public int getDelegated_Usr_Id() {
		return Delegated_Usr_Id;
	}
	public void setDelegated_Usr_Id(int delegated_Usr_Id) {
		Delegated_Usr_Id = delegated_Usr_Id;
	}
	public String getApp_Name() {
		return App_Name;
	}
	public void setApp_Name(String app_Name) {
		App_Name = app_Name;
	}
	public String getAssigned_By() {
		return Assigned_By;
	}
	public void setAssigned_By(String assigned_By) {
		Assigned_By = assigned_By;
	}
	public String getAssigned_To() {
		return Assigned_To;
	}
	public void setAssigned_To(String assigned_To) {
		Assigned_To = assigned_To;
	}
	public int getApp_Suv_Status() {
		return App_Suv_Status;
	}
	public void setApp_Suv_Status(int app_Suv_Status) {
		App_Suv_Status = app_Suv_Status;
	}


}
