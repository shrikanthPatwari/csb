package com.slk.dsl.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slk.dsl.dto.AppServerEOLDto;
import com.slk.dsl.dto.DatabaseEOLDTO;
import com.slk.dsl.dto.EOLProgressBarDTO;
import com.slk.dsl.dto.OSServerEOLDTO;
import com.slk.dsl.dto.SoftwareEOLDTO;
import com.slk.dsl.dto.VendorandDateDTO;
import com.slk.dsl.dto.WebServerEOLDTO;
import com.slk.dsl.model.Rlane_Strategy_Lkp;
import com.slk.dsl.repository.CAAppMasterDAO;
import com.slk.dsl.repository.EOLDao;
@Service
public class EOLService {
	@Autowired
	EOLDao repo;
	
	public EOLProgressBarDTO EOLProgresslist() {
		EOLProgressBarDTO obj = new EOLProgressBarDTO();
		obj.setDatabaseCount(repo.getDatabaseCount());
		obj.setDatabaseEOLCount(repo.getDatabaseEOLCount());
		obj.setOsCount(repo.getOsCount());
		obj.setOsEOLCount(repo.getOsEOLCount());
		obj.setTechstackCount(repo.getTechstackCount());

		obj.setTechstackEOLCount(repo.getTechstackEOLCount());
	
		return obj;
		
	}
	
	
	


public List<DatabaseEOLDTO> getDatabaseEOL(){
List<Object[]> data= repo.getdatabaseEOL();
List<DatabaseEOLDTO> result = new ArrayList<DatabaseEOLDTO>();
data.stream().forEach(obj->{
	DatabaseEOLDTO temp =new DatabaseEOLDTO();
	temp.setApp_Name(obj[0].toString());
	temp.setLob_Name(obj[1].toString());
	temp.setDatabase_Type(obj[2].toString());
	temp.setDatabase_Version(obj[3].toString());
	temp.setSupport_dt((Date)obj[4]);
	temp.setEol_dt((Date)obj[5]);
	temp.setCritical(obj[6].toString());
	result.add(temp);
});
return result;
}
public List<OSServerEOLDTO> getOSServerEOL(){
	List<Object[]> data= repo.getOSServerEOL();
	List<OSServerEOLDTO> result = new ArrayList<OSServerEOLDTO>();
	data.stream().forEach(obj->{
		OSServerEOLDTO temp = new OSServerEOLDTO();
		temp.setApp_Name(obj[0].toString());
		temp.setHost_Name(obj[1].toString());
		temp.setIP_Address(obj[2].toString());
		temp.setEnvironment(obj[3].toString());
		temp.setOS_Type(obj[4].toString());
		temp.setOS_Version(obj[5].toString());
		temp.setSupport_dt((Date)obj[6]);
		temp.setEol_dt((Date)obj[7]);
		temp.setCritical(obj[8].toString());
		result.add(temp);
	});
	return result;
}

public List<SoftwareEOLDTO> getSoftwareEOL(){
	List<Object[]> data= repo.getSoftwareEOL();
	List<SoftwareEOLDTO> result = new ArrayList<SoftwareEOLDTO>();
	data.stream().forEach(obj->{	
		SoftwareEOLDTO temp = new SoftwareEOLDTO();
		temp.setApp_Name(obj[0].toString());
		temp.setLob_Name(obj[1].toString());
		temp.setProg_Language(obj[2].toString());
		temp.setProg_Language_version(obj[3].toString());
		temp.setSupport_dt((Date)obj[4]);
		temp.setEol_dt((Date)obj[5]);
		temp.setCritical(obj[6].toString());
		result.add(temp);
	});
	return result;
}

public List<AppServerEOLDto> AppServeEOL(){
	List<Object[]> data= repo.getApserverEOL();
	List<AppServerEOLDto> result = new ArrayList<AppServerEOLDto>();
	data.stream().forEach(obj->{	
		AppServerEOLDto temp = new AppServerEOLDto();
		temp.setApp_Name(obj[0].toString());
		temp.setLob_Name(obj[1].toString());
		temp.setAppServer_Type(obj[2].toString());
		temp.setAppServer_Version(obj[3].toString());
		temp.setSupport_dt((Date)obj[4]);
		temp.setEol_dt((Date)obj[5]);
		temp.setCritical(obj[6].toString());
		
		result.add(temp);
	});
	return result;
}
public List<WebServerEOLDTO> WebServerEOL(){
	List<Object[]> data= repo.getWebServerEOL();
	List<WebServerEOLDTO> result = new ArrayList<WebServerEOLDTO>();
	data.stream().forEach(obj->{	
		WebServerEOLDTO temp = new WebServerEOLDTO();
		temp.setApp_Name(obj[0].toString());
		temp.setLob_Name(obj[1].toString());
		temp.setWebServer_Type(obj[2].toString());
		temp.setWebServer_Version(obj[3].toString());
		temp.setSupport_dt((Date)obj[4]);
		temp.setEol_dt((Date)obj[5]);
		temp.setCritical(obj[6].toString());
		
		result.add(temp);
	});
	return result;
}
}
