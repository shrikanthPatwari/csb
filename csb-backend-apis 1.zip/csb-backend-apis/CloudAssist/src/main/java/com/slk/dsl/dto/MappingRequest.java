package com.slk.dsl.dto;

import com.slk.dsl.model.OrgMapping;

public class MappingRequest {
	private OrgMapping orgmap;

	public OrgMapping getOrgmap() {
		return orgmap;
	}

	public void setOrgmap(OrgMapping orgmap) {
		this.orgmap = orgmap;
	}

}
