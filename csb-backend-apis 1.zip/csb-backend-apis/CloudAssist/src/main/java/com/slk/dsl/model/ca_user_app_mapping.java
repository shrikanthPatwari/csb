package com.slk.dsl.model;

import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name="ca_user_app_mapping")
public class ca_user_app_mapping {

	@Id @GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="Usr_App_Id")
	private int usrAppId;
	@Column(name="Usr_Id")
	private int usrId;
	@Column(name="Lob_Id")
	private int LobId;
	
	public int getLobId() {
		return LobId;
	}
	public void setLobId(int lobId) {
		LobId = lobId;
	}
	@Column(name="App_Master_Id")
	private String appMasterId;
	
	public int getUsrAppId() {
		return usrAppId;
	}
	public void setUsrAppId(int usrAppId) {
		this.usrAppId = usrAppId;
	}
	public int getUsrId() {
		return usrId;
	}
	public void setUsrId(int usrId) {
		this.usrId = usrId;
	}
	public String getAppMasterId() {
		return appMasterId;
	}
	public void setAppMasterId(String appMasterId) {
		this.appMasterId = appMasterId;
	}
	public String getOrgId() {
		return orgId;
	}
	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}
	public Date getRecInsDt() {
		return recInsDt;
	}
	public void setRecInsDt(Date recInsDt) {
		this.recInsDt = recInsDt;
	}
	public Date getRecUpdDt() {
		return recUpdDt;
	}
	public void setRecUpdDt(Date recUpdDt) {
		this.recUpdDt = recUpdDt;
	}
	@Column(name="Org_Id")
	private String orgId;
	
	
	@Column(name="Rec_Ins_Dt")
//	@JsonFormat(pattern="yyyy-MM-dd'T'HH:mm:ss.SSS")
	private Date recInsDt;
   
	@Column(name="Rec_Upd_Dt")
	private Date recUpdDt;
	
	@Column(name="Delegated_Usr_Id")
	private int Delegated_Usr_Id;

	public int getDelegated_Usr_Id() {
		return Delegated_Usr_Id;
	}
	public void setDelegated_Usr_Id(int delegated_Usr_Id) {
		Delegated_Usr_Id = delegated_Usr_Id;
	}
	
}
