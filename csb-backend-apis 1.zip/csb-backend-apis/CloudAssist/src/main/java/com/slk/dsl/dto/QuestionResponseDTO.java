package com.slk.dsl.dto;

import java.math.BigInteger;

public class QuestionResponseDTO {

	    private int questionId;
	    private String question;
	    private String response;
	    private BigInteger optionId;
		public int getQuestionId() {
			return questionId;
		}
		public void setQuestionId(int questionId) {
			this.questionId = questionId;
		}
		public String getQuestion() {
			return question;
		}
		public void setQuestion(String question) {
			this.question = question;
		}
		public String getResponse() {
			return response;
		}
		public void setResponse(String response) {
			this.response = response;
		}
		public BigInteger getOptionId() {
			return optionId;
		}
		public void setOptionId(BigInteger optionId) {
			this.optionId = optionId;
		}
	    
	    
}
