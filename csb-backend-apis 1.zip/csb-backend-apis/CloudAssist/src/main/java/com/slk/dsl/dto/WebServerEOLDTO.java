package com.slk.dsl.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class WebServerEOLDTO {
	
	String App_Name ;
	String Lob_Name;
	String WebServer_Type;
	String WebServer_Version;
	@JsonFormat(pattern="yyyy-MM-dd")
	Date support_dt;
	public String getApp_Name() {
		return App_Name;
	}
	public void setApp_Name(String app_Name) {
		App_Name = app_Name;
	}
	public String getLob_Name() {
		return Lob_Name;
	}
	public void setLob_Name(String lob_Name) {
		Lob_Name = lob_Name;
	}
	public String getWebServer_Type() {
		return WebServer_Type;
	}
	public void setWebServer_Type(String webServer_Type) {
		WebServer_Type = webServer_Type;
	}
	public String getWebServer_Version() {
		return WebServer_Version;
	}
	public void setWebServer_Version(String webServer_Version) {
		WebServer_Version = webServer_Version;
	}
	public Date getSupport_dt() {
		return support_dt;
	}
	public void setSupport_dt(Date support_dt) {
		this.support_dt = support_dt;
	}
	public Date getEol_dt() {
		return eol_dt;
	}
	public void setEol_dt(Date eol_dt) {
		this.eol_dt = eol_dt;
	}
	public String getCritical() {
		return Critical;
	}
	public void setCritical(String critical) {
		Critical = critical;
	}
	@JsonFormat(pattern="yyyy-MM-dd")
	Date eol_dt;
	String Critical;

}
