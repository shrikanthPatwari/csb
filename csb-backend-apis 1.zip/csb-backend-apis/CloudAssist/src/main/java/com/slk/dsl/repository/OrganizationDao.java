package com.slk.dsl.repository;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;


import com.slk.dsl.model.Org;
@Repository
public interface OrganizationDao extends JpaRepository<Org, Integer>{

	String orgName = "SELECT Org_Name FROM ca_org_master where Org_Id= :orgId";
	@Query(value = orgName, nativeQuery = true)
	public String getOrgNameforUser(int orgId);
	
	String checkOrgName = "SELECT Org_Id FROM ca_org_master where Org_Name=:orgName";
	@Query(value = checkOrgName, nativeQuery = true)
	public Integer checkOrgName(String orgName);
	
}

