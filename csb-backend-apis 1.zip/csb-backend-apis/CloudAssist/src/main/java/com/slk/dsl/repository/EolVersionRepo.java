package com.slk.dsl.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.slk.dsl.model.EolVersion;

public interface EolVersionRepo extends JpaRepository<EolVersion, Integer>{
	String getVersion= "select cp.product_Name,ca.version,ca.support_dt,ca.eol_dt,ca.is_Active,ca.release_dt,ca.version_ID,ca.product_ID from ca_eol_version_details ca inner join ca_eol_products cp on ca.product_ID=cp.product_ID where ca.product_ID=:prodId";
	@Query(value = getVersion, nativeQuery = true)
	public List<Object[]> getAppVersions(int prodId);

	String deleteProductVersion = "delete from ca_eol_version_details where product_ID=:id";
	@Modifying
	@Transactional
	@Query(value = deleteProductVersion, nativeQuery = true)
	public void deleteAllVersions(int id);
	
	String deleteVersion = "delete from ca_eol_version_details where version_ID=:id";
	@Modifying
	@Transactional
	@Query(value = deleteVersion, nativeQuery = true)
	public void deleteVersion(int id);
}
