package com.slk.dsl.services;

import java.io.IOException;
import java.io.OutputStream;
import java.io.StringWriter;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;
import org.springframework.web.client.RestTemplate;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.itextpdf.html2pdf.HtmlConverter;
import com.itextpdf.io.source.ByteArrayOutputStream;
import com.slk.dsl.dto.AppNameIdDTO;
import com.slk.dsl.dto.AppsublookUpDTO;
import com.slk.dsl.dto.Chat2cloudDTO;
import com.slk.dsl.dto.ChatbotSurveyResponse;
import com.slk.dsl.dto.DetailsDTO;
import com.slk.dsl.dto.Email_passwordDTO;
import com.slk.dsl.dto.MemberDetails;
import com.slk.dsl.dto.MessageAppDTO;
import com.slk.dsl.dto.QuestionResponseDTO;
import com.slk.dsl.dto.SubLookupDTO;
import com.slk.dsl.dto.SurveyPdfDTO;
import com.slk.dsl.dto.UserAndOrgDetailsDTO;
import com.slk.dsl.model.Application;
import com.slk.dsl.model.ApplicationLevelQuestioner;
import com.slk.dsl.model.DecisionUser;
import com.slk.dsl.model.LOB;
import com.slk.dsl.model.ca_user_app_mapping;
import com.slk.dsl.repository.ApplicationQuestionerDAO;
import com.slk.dsl.repository.CAAppMasterDAO;
import com.slk.dsl.repository.LOBDao;
import com.slk.dsl.repository.OrganizationDao;
import com.slk.dsl.repository.UserDao;
import com.slk.dsl.repository.UserSetupDao;
import com.slk.dsl.repository.ca_user_app_mappingDAO;
import freemarker.template.Configuration;
import freemarker.template.Template;

@Service
public class DecisionUserService {

	@Autowired
	UserSetupDao repo;

	@Autowired
	private UserDao userDao;

	@Autowired
	OrganizationDao orgRepo;

	@Autowired
	ApplicationQuestionerDAO appRepo;

	@Autowired
	CAAppMasterDAO caAppRepo;

	@Autowired
	LOBDao lobRepo;

	@Autowired
	private Configuration config;

	@Value("${fromAddress}")
	private String fromAddress;

	@Value("${applicationUrl}")
	private String appurl;

	@Value("${emailUrl}")
	private String emailurl;
	
	@Value("${giraSyncEmailUrl}")
	private String giraSyncEmailUrl;

	@Autowired
	ca_user_app_mappingDAO userMappingdao;

	public DecisionUser checkEmail(DecisionUser userDetails) {
		String url = "https://slk-ip-digitaltoolbox-api.azurewebsites.net/checkEmail";
		RestTemplate restTemplate = new RestTemplate();
		DecisionUser data = restTemplate.postForObject(url, userDetails, DecisionUser.class);
		List<Object[]> appDetails = userDao.getUserAppDetails(data.getUserId());		
		List<AppNameIdDTO> allDetails = new ArrayList<AppNameIdDTO>();	
		appDetails.stream().forEach(obj -> {
			AppNameIdDTO allAppNames = new AppNameIdDTO();
			allAppNames.setAppId(Integer.parseInt(obj[0].toString()));
			allAppNames.setAppName(obj[1].toString());
			allDetails.add(allAppNames);
		});
		data.setAppDetails(allDetails);
		data.setAppCount(allDetails.size());
		return data;
	}

	public int AppPostQuestioner(List<ChatbotSurveyResponse> list, int orgId) throws IOException {
		List<AppsublookUpDTO> lookUpValues = new ArrayList<AppsublookUpDTO>();
		List<SubLookupDTO> sublookupresult = new ArrayList<SubLookupDTO>();
		// List<QuestionerIdDto> questionerIdResult = new ArrayList<QuestionerIdDto>();

		List<Object[]> sublookuptable = appRepo.getsublookupTable();
		// List<Object[]> QuestionerId = appRepo.getQuestionetId();
		List<Object[]> lookUp = appRepo.getLookValuesId();

		sublookuptable.stream().forEach(objects -> {
			SubLookupDTO temp = new SubLookupDTO();
			temp.setSublookupid((Integer) objects[0]);
			temp.setLookupid((Integer) objects[1]);
			temp.setValues(objects[2].toString());
			sublookupresult.add(temp);
		});

		lookUp.stream().forEach(obj -> {
			AppsublookUpDTO temp = new AppsublookUpDTO();
			temp.setQuestioner_lookup_Id((Integer) obj[0]);
			temp.setQuestioner_Values(obj[1].toString());
			temp.setQuestioner_Id((Integer) obj[2]);
			temp.setQuestion_description(obj[3].toString());
			lookUpValues.add(temp);
		});

		for (ChatbotSurveyResponse aa : list) {
			if (aa.getAppName() != null) {
				List<Object[]> appdata = caAppRepo.getAppNameDetails(aa.getAppName(), orgId);
				appdata.stream().forEach(obj -> {
					appRepo.delete(Integer.parseInt(obj[0].toString()));
				});
			} else {
				appRepo.delete(aa.getAppId());
			}
		}
		int app_id = 0;
		int userId = 0;
		String appName=null;
		for (ChatbotSurveyResponse aa : list) {
			userId = aa.getUser_id();
			List<Integer> idList = Arrays.asList(146, 147, 149, 164, 173, 178, 180);
			if (idList.contains(aa.getQuestionId()) == false) {

				ApplicationLevelQuestioner surveyResponse = new ApplicationLevelQuestioner();
				surveyResponse.setResponse_Id(surveyResponse.getResponse_Id());
				surveyResponse.setQuestioner_Id(aa.getQuestionId());

				if (aa.getAppName() == null) {
					surveyResponse.setApp_Id(aa.getAppId());
				} else {
					List<Object[]> data = caAppRepo.getAppNameDetails(aa.getAppName(), orgId);
					if (data.isEmpty()) {
						Integer lobId = lobRepo.getLobDetails(aa.getLobName(), orgId);

						if (lobId == null) {
							LOB lob = new LOB();
							lob.setLobName(aa.getLobName());
							lob.setLobManager(aa.getLobName());
							lob.setOrgId(orgId);
							lob.setRecInsDt(Calendar.getInstance().getTime());
							lob.setRecUpdDt(Calendar.getInstance().getTime());
							lobRepo.save(lob);
							lobId = lob.getLobId();
						} else {

						}
						Application apprecord = new Application();
						String appIdd = Integer.toString((int) (Math.random() * 9000) + 10000);
						apprecord.setAppId(appIdd);
						apprecord.setAppName(aa.getAppName());
						apprecord.setLobId(lobId);
						apprecord.setOrgId(orgId);
						caAppRepo.save(apprecord);
						surveyResponse.setApp_Id(Integer.parseInt(apprecord.getAppId()));
						
						saveAppUser(orgId,apprecord.getAppId(),aa.getUser_id(),lobId);
					} else {
						data.stream().forEach(obj -> {
							surveyResponse.setApp_Id(Integer.parseInt(obj[0].toString()));
							String appId=obj[0].toString();
							saveAppUser(orgId,appId,aa.getUser_id(),573);
						});
						

					}

				}

				if (aa.getResponse() != null) {
					surveyResponse.setComments(aa.getResponse());
				}

				lookUpValues.forEach(b -> {
					if (b.getQuestioner_Id() == aa.getQuestionId()
							&& b.getQuestioner_Values().equals(aa.getResponse())) {
						surveyResponse.setQuestioner_Lkp_Id(BigInteger.valueOf(b.getQuestioner_lookup_Id()));
					} else {
						sublookupresult.stream().forEach(sublookuprecord -> {
							if (sublookuprecord.getValues().equals(aa.getResponse())) {
								surveyResponse
										.setQuestioner_Lkp_Id(BigInteger.valueOf(sublookuprecord.getSublookupid()));
							}
						});
					}
				});

				surveyResponse.setRec_Ins_Dt(Calendar.getInstance().getTime());
				surveyResponse.setRec_Upd_Dt(Calendar.getInstance().getTime());
//				surveyResponse.setUserId(userId);
				appRepo.save(surveyResponse);
				app_id = surveyResponse.getApp_Id();
				appName = aa.getAppName();

			}
		}
		;

		int appMasterId = appRepo.getAppMasterId(app_id, orgId);
		appRepo.activateApplication(appMasterId, orgId);
		
//		Calling Decision engine API
//		DeAppId appId = new DeAppId();
//		appId.setApp_id(app_id);
//		String url = "__deurl__";		
//		String result = restTemplate.postForObject(url, appId, String.class);
		
//		fetching email and password details from tool box DB
		RestTemplate restTemplate = new RestTemplate();
		String userAppName = caAppRepo.getAppName(app_id, orgId);
		String url3 = "https://slk-ip-digitaltoolbox-api.azurewebsites.net/GetEmailAndPassword/" + userId + "";
		Email_passwordDTO userData1 = restTemplate.getForObject(url3, Email_passwordDTO.class);
		String email1 = userData1.getEmailid();
		String password = userData1.getPassword();
		Base64.Decoder decoder = Base64.getDecoder();
		String pasword = new String(decoder.decode(password));

		
//		Generating pdf and Email sending code
		
//		List<Object[]> surveyResponseDetails = appRepo.getSurveyPdfDetails(app_id);
		List<SurveyPdfDTO> result1 = new ArrayList<SurveyPdfDTO>();
		for (ChatbotSurveyResponse res : list) {
			SurveyPdfDTO temp = new SurveyPdfDTO();
			temp.setQuestion(res.getQuestion().toString());
			temp.setResponse(res.getResponse().toString());
			result1.add(temp);
		}
		String encodedString = "";
		try {
			Map<String, Object> model = new HashMap<String, Object>();
			model.put("responses", result1);
			model.put("appName",appName );
			StringWriter out = new StringWriter();
			Template t = config.getTemplate("demo.ftl");
			t.process(model, out);
			String k = FreeMarkerTemplateUtils.processTemplateIntoString(t, model);
			ByteArrayOutputStream pdfOutputStream = new ByteArrayOutputStream();
			HtmlConverter.convertToPdf(k, pdfOutputStream);
			byte[] pdfBytes = pdfOutputStream.toByteArray();
			byte[] encodedBytes = Base64.getEncoder().encode(pdfBytes);
			encodedString = new String(encodedBytes);
		} catch (Exception e) {
			e.printStackTrace();
		}

		ObjectMapper objectMapper = new ObjectMapper();
		Map<String, Object> data = new HashMap<>();
		data.put("AppName", userAppName);
		data.put("UserName", email1);
		data.put("Password", pasword);
		data.put("To", email1);
		data.put("CC", " ");
		data.put("SubjectKey", "CSB_SURVEY");
    	data.put("AttachmentContent", encodedString);
		data.put("AttachmentName", "Survey_Response_Transcript.pdf");
		String requestBody = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(data);
		System.out.println(requestBody+"requestBody");
		String result = restTemplate.postForObject(emailurl, requestBody, String.class);
		System.out.println(result + " result from email api");
		return app_id;
	}

	public void generatePdf(HttpServletResponse response, OutputStream outputStream, int appId) {
		try {
			List<Object[]> surveyResponseDetails = appRepo.getSurveyPdfDetails(appId);
			List<SurveyPdfDTO> result = new ArrayList<SurveyPdfDTO>();
			
			surveyResponseDetails.stream().forEach(objects -> {
				SurveyPdfDTO temp = new SurveyPdfDTO();
				temp.setQuestion(objects[0].toString());
				temp.setResponse(objects[1].toString());
				result.add(temp);
			});
			
			Map<String, Object> model = new HashMap<String, Object>();
			List<Object[]> rlaneDetails = caAppRepo.getBlobImagebyAppId(appId);
			rlaneDetails.stream().forEach(obj->{
				model.put("responses", result);
				model.put("appName", obj[0].toString());
				byte[] decodedBytes = Base64.getUrlDecoder().decode(obj[1].toString());				
//				String imgDataAsBase64 = new String(decodedBytes,StandardCharsets.UTF_8);
				String base64Data = Base64.getEncoder().encodeToString(decodedBytes);
//				System.out.println(base64Data+" decodedBytes");
				model.put("image", "data:image/png;base64,"+base64Data);
//				model.put("image", obj[1].toString());
				model.put("rlane", obj[2].toString());
			});
			
			StringWriter out = new StringWriter();
			Template t = config.getTemplate("demo.ftl");
			t.process(model, out);
			String k = FreeMarkerTemplateUtils.processTemplateIntoString(t, model);
			HtmlConverter.convertToPdf(k, outputStream);
			System.out.println("Working Directory = " + System.getProperty("user.dir"));
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public MessageAppDTO saveUserAndOrg(UserAndOrgDetailsDTO userdetails) {
		int count = 0;
		int userCount = 0;
		String url = "https://slk-ip-digitaltoolbox-api.azurewebsites.net/saveUserAndOrg";
		RestTemplate restTemplate = new RestTemplate();
		int orgId = restTemplate.postForObject(url, userdetails, int.class);
		MessageAppDTO message = new MessageAppDTO();
		List<String> appList = new ArrayList<String>();
		
		for (DetailsDTO project : userdetails.getDetails()) {
			if (project.getProjectName() != null) {
				count++;	
				appList.add(project.getProjectName());
			}

			List<Object[]> data = caAppRepo.getAppNameDetails(project.getProjectName(), orgId);
			if (data.isEmpty()) {
				Application apprecord = new Application();
				String appIdd = Integer.toString((int) (Math.random() * 9000) + 10000);
				apprecord.setAppId(appIdd);
				apprecord.setAppName(project.getProjectName());
				apprecord.setLobId(573);
				apprecord.setOrgId(orgId);
				caAppRepo.save(apprecord);

//				String appMasterId = caAppRepo.getAppMasterIdDetail(appIdd, orgId);

				for (MemberDetails member : project.getMembers()) {
					if (member.getUniqueName() != null) {
						userCount++;
					}
					String emailId = member.getUniqueName();
					String url2 = "https://slk-ip-digitaltoolbox-api.azurewebsites.net/getUserId/" + emailId + "/" + orgId;
					int userId = restTemplate.getForObject(url2, int.class);
					System.out.println(userId + " userId");
//					ca_user_app_mapping userApp = new ca_user_app_mapping();
//					userApp.setAppMasterId(appMasterId);
//					userApp.setLobId(573);
//					userApp.setOrgId(Integer.toString(orgId));
//					userApp.setUsrId(userId);
//					userApp.setDelegated_Usr_Id(0);
//					userApp.setRecInsDt(Calendar.getInstance().getTime());
//					userApp.setRecUpdDt(Calendar.getInstance().getTime());
//					userMappingdao.save(userApp);
					
					saveAppUser(orgId,appIdd,userId,573);
										
//					sendEmail(userId,project.getProjectName());					
					
				}
			} else {
				for (MemberDetails member : project.getMembers()) {
					if (member.getUniqueName() != null) {
						userCount++;
					}
					String emailId = member.getUniqueName();
					String url2 = "https://slk-ip-digitaltoolbox-api.azurewebsites.net/getUserId/" + emailId + "/" + orgId;
					int userId = restTemplate.getForObject(url2, int.class);
					System.out.println(userId + " userId");
					data.forEach(obj->{
//						String appMasterId  = caAppRepo.getAppMasterIdDetail(obj[0].toString(), orgId);										
//					List<Object[]> userIdFromDb=userMappingdao.userIdInDb(userId,orgId,appMasterId);				
//					if(userIdFromDb.isEmpty()) {
//					ca_user_app_mapping userApp = new ca_user_app_mapping();		
//					userApp.setAppMasterId(appMasterId);
//					userApp.setLobId(573);
//					userApp.setOrgId(Integer.toString(orgId));
//					userApp.setUsrId(userId);
//					userApp.setDelegated_Usr_Id(0);
//					userApp.setRecInsDt(Calendar.getInstance().getTime());
//					userApp.setRecUpdDt(Calendar.getInstance().getTime());
//					userMappingdao.save(userApp);
//					}
					saveAppUser(orgId,obj[0].toString(),userId,573);
					});
//					sendEmail(userId,project.getProjectName());
				}

			}
		}
		message.setAppNames(appList);
		message.setMessage(count + " Applications and " + userCount
				+ " users synced with Cloud Pacific platform. Please check email for access to the dashboard and request application managers to take up the survey.");
		return message;
	}
	
//	public void sendEmail(int userId,String projectName){
//		RestTemplate restTemplate = new RestTemplate();
//		String url3 = "https://slk-ip-digitaltoolbox-api.azurewebsites.net/GetEmailAndPassword/" + userId + "";
//		Email_passwordDTO userData1 = restTemplate.getForObject(url3, Email_passwordDTO.class);
//		String password = userData1.getPassword();
//		Base64.Decoder decoder = Base64.getDecoder();
//		String pasword = new String(decoder.decode(password));
//		
//		ObjectMapper objectMapper = new ObjectMapper();
//		Map<String, Object> emailDetails = new HashMap<>();
//		emailDetails.put("AppName",projectName);
//		emailDetails.put("UserName",userData1.getEmailid() );
//		emailDetails.put("Password", pasword);
//		emailDetails.put("To", userData1.getEmailid());
//		emailDetails.put("CC", " ");
//		emailDetails.put("SubjectKey", "CSB_SURVEY");
//
//		String requestBody;
//		try {
//			requestBody = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(emailDetails);
//			String result = restTemplate.postForObject(giraSyncEmailUrl, requestBody, String.class);
//			System.out.println(result + " result from email api");
//		} catch (JsonProcessingException e) {
//			e.printStackTrace();
//		}
//	}
	
	public void saveAppUser(int orgId,String appId,int userId,int lobId) {
		String appMasterId  = caAppRepo.getAppMasterIdDetail(appId, orgId);										
		List<Object[]> userIdFromDb=userMappingdao.userIdInDb(userId,orgId,appMasterId);				
		if(userIdFromDb.isEmpty()) {
		ca_user_app_mapping userApp = new ca_user_app_mapping();		
		userApp.setAppMasterId(appMasterId);
		userApp.setLobId(lobId);
		userApp.setOrgId(Integer.toString(orgId));
		userApp.setUsrId(userId);
		userApp.setDelegated_Usr_Id(0);
		userApp.setRecInsDt(Calendar.getInstance().getTime());
		userApp.setRecUpdDt(Calendar.getInstance().getTime());
		userMappingdao.save(userApp);
		}
		
	}
	
	public int saveChatResponse(ChatbotSurveyResponse aa, int orgId) throws IOException {
		List<AppsublookUpDTO> lookUpValues = new ArrayList<AppsublookUpDTO>();
		List<SubLookupDTO> sublookupresult = new ArrayList<SubLookupDTO>();
		List<Object[]> sublookuptable = appRepo.getsublookupTable();
		List<Object[]> lookUp = appRepo.getLookValuesId();

		sublookuptable.stream().forEach(objects -> {
			SubLookupDTO temp = new SubLookupDTO();
			temp.setSublookupid((Integer) objects[0]);
			temp.setLookupid((Integer) objects[1]);
			temp.setValues(objects[2].toString());
			sublookupresult.add(temp);
		});

		lookUp.stream().forEach(obj -> {
			AppsublookUpDTO temp = new AppsublookUpDTO();
			temp.setQuestioner_lookup_Id((Integer) obj[0]);
			temp.setQuestioner_Values(obj[1].toString());
			temp.setQuestioner_Id((Integer) obj[2]);
			temp.setQuestion_description(obj[3].toString());
			lookUpValues.add(temp);
		});

			List<Integer> idList = Arrays.asList(146, 147, 149, 164, 173, 178, 180);
			if (idList.contains(aa.getQuestionId()) == false) {

				ApplicationLevelQuestioner surveyResponse = new ApplicationLevelQuestioner();
				surveyResponse.setResponse_Id(surveyResponse.getResponse_Id());
				surveyResponse.setQuestioner_Id(aa.getQuestionId());
				surveyResponse.setApp_Id(aa.getAppId());
				if (aa.getResponse() != null) {
					surveyResponse.setComments(aa.getResponse());
				}

				lookUpValues.forEach(b -> {
					if (b.getQuestioner_Id() == aa.getQuestionId()
							&& b.getQuestioner_Values().equals(aa.getResponse())) {
						surveyResponse.setQuestioner_Lkp_Id(BigInteger.valueOf(b.getQuestioner_lookup_Id()));
					} else {
						sublookupresult.stream().forEach(sublookuprecord -> {
							if (sublookuprecord.getValues().equals(aa.getResponse())) {
								surveyResponse
										.setQuestioner_Lkp_Id(BigInteger.valueOf(sublookuprecord.getSublookupid()));
							}
						});
					}
				});

				surveyResponse.setRec_Ins_Dt(Calendar.getInstance().getTime());
				surveyResponse.setRec_Upd_Dt(Calendar.getInstance().getTime());
				surveyResponse.setUserId(aa.getUser_id());
				appRepo.save(surveyResponse);


			}
		int appMasterId = appRepo.getAppMasterId(aa.getAppId(), orgId);
		appRepo.activateApplication(appMasterId, orgId);
		return aa.getAppId();
	}
	
	public int saveChatApp(Application app,int orgId) {
		List<Object[]> data = caAppRepo.getAppNameDetails(app.getAppName(), orgId);
		Application apprecord = new Application();
		if (data.isEmpty()) {
			String appIdd = Integer.toString((int) (Math.random() * 9000) + 10000);
			apprecord.setAppId(appIdd);
			apprecord.setAppName(app.getAppName());
			apprecord.setLobId(573);
			apprecord.setOrgId(orgId);
			caAppRepo.save(apprecord);
			return Integer.parseInt(apprecord.getAppId());
		} else {
			data.stream().forEach(obj -> {
		    apprecord.setAppId(obj[0].toString());
			});
		   return Integer.parseInt(apprecord.getAppId());
		}
	}
	
	public String sendChatEmail(ChatbotSurveyResponse aa, int orgId) throws JsonProcessingException {
//		fetching email and password details from tool box DB
		RestTemplate restTemplate = new RestTemplate();
//		String userAppName = caAppRepo.getAppName(aa.getAppId(), orgId);
		String url3 = "https://slk-ip-digitaltoolbox-api.azurewebsites.net/GetEmailAndPassword/" + aa.getUser_id() + "";
		Email_passwordDTO userData1 = restTemplate.getForObject(url3, Email_passwordDTO.class);
		String email1 = userData1.getEmailid();
		String password = userData1.getPassword();
		Base64.Decoder decoder = Base64.getDecoder();
		String pasword = new String(decoder.decode(password));

		
//		Generating pdf and Email sending code
		
		List<Object[]> surveyResponseDetails = appRepo.getSurveyPdfDetails(aa.getAppId());
		List<SurveyPdfDTO> result1 = new ArrayList<SurveyPdfDTO>();
		surveyResponseDetails.stream().forEach(objects -> {
			SurveyPdfDTO temp = new SurveyPdfDTO();
			temp.setQuestion(objects[0].toString());
			temp.setResponse(objects[1].toString());
			result1.add(temp);
		});
		String encodedString = "";
		try {
			Map<String, Object> model = new HashMap<String, Object>();
			model.put("responses", result1);
			model.put("appName",aa.getAppName());
			StringWriter out = new StringWriter();
			Template t = config.getTemplate("demo.ftl");
			t.process(model, out);
			String k = FreeMarkerTemplateUtils.processTemplateIntoString(t, model);
			ByteArrayOutputStream pdfOutputStream = new ByteArrayOutputStream();
			HtmlConverter.convertToPdf(k, pdfOutputStream);
			byte[] pdfBytes = pdfOutputStream.toByteArray();
			byte[] encodedBytes = Base64.getEncoder().encode(pdfBytes);
			encodedString = new String(encodedBytes);
		} catch (Exception e) {
			e.printStackTrace();
		}

		ObjectMapper objectMapper = new ObjectMapper();
		Map<String, Object> data = new HashMap<>();
		data.put("AppName", aa.getAppName());
		data.put("UserName", email1);
		data.put("Password", pasword);
		data.put("To", email1);
		data.put("CC", " ");
		data.put("SubjectKey", "CSB_SURVEY");
    	data.put("AttachmentContent", encodedString);
		data.put("AttachmentName", "Survey_Response_Transcript.pdf");
		String requestBody = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(data);
		System.out.println(requestBody+"requestBody");
		String result = restTemplate.postForObject(emailurl, requestBody, String.class);
		System.out.println(result + " result from email api");
		return "Email sent successfully";
	}
	
	public int AppPostQuestioner1(Chat2cloudDTO list, int orgId) throws IOException {
		
			if (list.getAppName() != null) {
				List<Object[]> appdata = caAppRepo.getAppNameDetails(list.getAppName(), orgId);
				appdata.stream().forEach(obj -> {
					appRepo.delete(Integer.parseInt(obj[0].toString()));
				});
			} else {
				appRepo.delete(list.getAppId());
			}
	
		    int app_id = 0;
		    int userId = 0;
			userId = list.getUser_id();
//			List<Integer> idList = Arrays.asList(146, 147, 149, 164, 173, 178, 180);
			
			ApplicationLevelQuestioner surveyResponse = new ApplicationLevelQuestioner();	

				if (list.getAppName() == null) {
					surveyResponse.setApp_Id(list.getAppId());
				} else {
					List<Object[]> data = caAppRepo.getAppNameDetails(list.getAppName(), orgId);
					if (data.isEmpty()) {
						Integer lobId = lobRepo.getLobDetails(list.getLobName(), orgId);

						if (lobId == null) {
							LOB lob = new LOB();
							lob.setLobName(list.getLobName());
							lob.setLobManager(list.getLobName());
							lob.setOrgId(orgId);
							lob.setRecInsDt(Calendar.getInstance().getTime());
							lob.setRecUpdDt(Calendar.getInstance().getTime());
							lobRepo.save(lob);
							lobId = lob.getLobId();
						} 
						Application apprecord = new Application();
						String appIdd = Integer.toString((int) (Math.random() * 9000) + 10000);
						apprecord.setAppId(appIdd);
						apprecord.setAppName(list.getAppName());
						apprecord.setLobId(lobId);
						apprecord.setOrgId(orgId);
						caAppRepo.save(apprecord);
						surveyResponse.setApp_Id(Integer.parseInt(apprecord.getAppId()));
						
						saveAppUser(orgId,apprecord.getAppId(),list.getUser_id(),lobId);
					} else {
						data.stream().forEach(obj -> {
							surveyResponse.setApp_Id(Integer.parseInt(obj[0].toString()));
							String appId=obj[0].toString();
//							saveAppUser(orgId,appId,list.getUser_id(),573);
						});
					}

				}
				List<SurveyPdfDTO> result1 = new ArrayList<SurveyPdfDTO>();
				for (QuestionResponseDTO res : list.getResponses()) {
					ApplicationLevelQuestioner surveyResponse1 = new ApplicationLevelQuestioner();
					surveyResponse1.setResponse_Id(surveyResponse.getResponse_Id());
					surveyResponse1.setQuestioner_Id(res.getQuestionId());
				if (res.getResponse() != null) {
					surveyResponse1.setComments(res.getResponse());				
				}
				surveyResponse1.setApp_Id(surveyResponse.getApp_Id());
				surveyResponse1.setQuestioner_Lkp_Id(res.getOptionId());
				surveyResponse1.setRec_Ins_Dt(Calendar.getInstance().getTime());
				surveyResponse1.setRec_Upd_Dt(Calendar.getInstance().getTime());
				surveyResponse1.setUserId(userId);
				appRepo.save(surveyResponse1);
				SurveyPdfDTO temp = new SurveyPdfDTO();
				temp.setQuestion(res.getQuestion().toString());
				temp.setResponse(res.getResponse().toString());
				result1.add(temp);
				app_id = surveyResponse.getApp_Id();

			}
	

		int appMasterId = appRepo.getAppMasterId(app_id, orgId);
		appRepo.activateApplication(appMasterId, orgId);
		RestTemplate restTemplate = new RestTemplate();
//		String userAppName = caAppRepo.getAppName(app_id, orgId);
		String url3 = "https://slk-ip-digitaltoolbox-api.azurewebsites.net/GetEmailAndPassword/" + userId + "";
		Email_passwordDTO userData1 = restTemplate.getForObject(url3, Email_passwordDTO.class);
		String email1 = userData1.getEmailid();
		String password = userData1.getPassword();
		Base64.Decoder decoder = Base64.getDecoder();
		String pasword = new String(decoder.decode(password));

		
//		Generating pdf and Email sending code
		

//		List<SurveyPdfDTO> result1 = new ArrayList<SurveyPdfDTO>();
//		for (ChatbotSurveyResponse res : list) {
//			SurveyPdfDTO temp = new SurveyPdfDTO();
//			temp.setQuestion(res.getQuestion().toString());
//			temp.setResponse(res.getResponse().toString());
//			result1.add(temp);
//		}
		String encodedString = "";
		try {
			Map<String, Object> model = new HashMap<String, Object>();
			model.put("responses", result1);
			model.put("appName", list.getAppName());
			StringWriter out = new StringWriter();
			Template t = config.getTemplate("demo.ftl");
			t.process(model, out);
			String k = FreeMarkerTemplateUtils.processTemplateIntoString(t, model);
			ByteArrayOutputStream pdfOutputStream = new ByteArrayOutputStream();
			HtmlConverter.convertToPdf(k, pdfOutputStream);
			byte[] pdfBytes = pdfOutputStream.toByteArray();
			byte[] encodedBytes = Base64.getEncoder().encode(pdfBytes);
			encodedString = new String(encodedBytes);
		} catch (Exception e) {
			e.printStackTrace();
		}

		ObjectMapper objectMapper = new ObjectMapper();
		Map<String, Object> data = new HashMap<>();
		data.put("AppName", list.getAppName());
		data.put("UserName", email1);
		data.put("Password", pasword);
		data.put("To", email1);
		data.put("CC", " ");
		data.put("SubjectKey", "CSB_SURVEY");
    	data.put("AttachmentContent", encodedString);
		data.put("AttachmentName", "Survey_Response_Transcript.pdf");
		String requestBody = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(data);
		System.out.println(requestBody+"requestBody");
		String result = restTemplate.postForObject(emailurl, requestBody, String.class);
		System.out.println(result + " result from email api");
		return app_id;
	}
}
