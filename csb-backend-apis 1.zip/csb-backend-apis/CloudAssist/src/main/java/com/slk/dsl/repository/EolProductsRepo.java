package com.slk.dsl.repository;
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.slk.dsl.model.EolProducts;

public interface EolProductsRepo extends JpaRepository<EolProducts, Integer>{
	String deleteProduct = "delete from ca_eol_products where product_ID=:id";
	@Modifying
	@Transactional
	@Query(value = deleteProduct, nativeQuery = true)
	public void deleteProducts(int id);
	
	String updateProduct = "update ca_eol_products set  product_Name=:applicationName,product_AliasName =:aliasName,Rec_Upd_dt =:recUpdDate where product_ID=:productId ";
	@Transactional
	@Modifying
	@Query(value = updateProduct, nativeQuery = true)
	public void updateProducts(String applicationName,String aliasName,Date recUpdDate,int productId);
	
	String findQuery = "select * from ca_eol_products where product_Name=:name";

	@Query(value = findQuery, nativeQuery = true)
	public List<Object[]> geteolDistinctValues(String name);
	
}
