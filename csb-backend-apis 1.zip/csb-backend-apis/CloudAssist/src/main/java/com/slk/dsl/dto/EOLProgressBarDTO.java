package com.slk.dsl.dto;

public class EOLProgressBarDTO {
	
	int DatabaseCount;
	int DatabaseEOLCount;
	int OsCount;
	int OsEOLCount;
	int TechstackCount;
	int TechstackEOLCount;
	public int getDatabaseCount() {
		return DatabaseCount;
	}
	public void setDatabaseCount(int databaseCount) {
		DatabaseCount = databaseCount;
	}
	public int getDatabaseEOLCount() {
		return DatabaseEOLCount;
	}
	public void setDatabaseEOLCount(int databaseEOLCount) {
		DatabaseEOLCount = databaseEOLCount;
	}
	public int getOsCount() {
		return OsCount;
	}
	public void setOsCount(int osCount) {
		OsCount = osCount;
	}
	public int getOsEOLCount() {
		return OsEOLCount;
	}
	public void setOsEOLCount(int osEOLCount) {
		OsEOLCount = osEOLCount;
	}
	public int getTechstackCount() {
		return TechstackCount;
	}
	public void setTechstackCount(int techstackCount) {
		TechstackCount = techstackCount;
	}
	public int getTechstackEOLCount() {
		return TechstackEOLCount;
	}
	public void setTechstackEOLCount(int techstackEOLCount) {
		TechstackEOLCount = techstackEOLCount;
	}
	

}
