package com.slk.dsl.dto;

import java.util.List;

public class Chat2cloudDTO {

	    private int user_id;
	    private String appName;
	    private int appId;
	    private String lobName;
	    private List<QuestionResponseDTO> responses;
		public int getUser_id() {
			return user_id;
		}
		public void setUser_id(int user_id) {
			this.user_id = user_id;
		}
		public String getAppName() {
			return appName;
		}
		public void setAppName(String appName) {
			this.appName = appName;
		}
		public int getAppId() {
			return appId;
		}
		public void setAppId(int appId) {
			this.appId = appId;
		}
		public String getLobName() {
			return lobName;
		}
		public void setLobName(String lobName) {
			this.lobName = lobName;
		}
		public List<QuestionResponseDTO> getResponses() {
			return responses;
		}
		public void setResponses(List<QuestionResponseDTO> responses) {
			this.responses = responses;
		}
	    
	    
}
