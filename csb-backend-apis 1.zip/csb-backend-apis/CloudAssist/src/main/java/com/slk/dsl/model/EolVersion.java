package com.slk.dsl.model;

import java.util.BitSet;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ca_eol_version_details")

public class EolVersion {
	@Id @GeneratedValue(strategy=GenerationType.IDENTITY)
	
	@Column(name="version_ID")
    private int versionId;
	
	@Column(name="product_ID")
    private int productID;
	 

	@Column(name="version")
    private String version;
	 
	@Column(name="release_dt")
    private Date releasedt;
	
	@Column(name="support_dt")
    private Date supportdt;
	 
	@Column(name="eol_dt")
    private Date eoldt;
	
	@Column(name="is_Active")
    private int isActive;
	
	 
		@Column(name="Rec_Ins_dt")
	    private Date recInsdt;
		
		 
		@Column(name="Rec_Upd_dt")
	    private Date recUpddt;


		public int getVersionId() {
			return versionId;
		}


		public void setVersionId(int versionId) {
			this.versionId = versionId;
		}


		public int getProductID() {
			return productID;
		}


		public void setProductID(int productID) {
			this.productID = productID;
		}


		public String getVersion() {
			return version;
		}


		public void setVersion(String version) {
			this.version = version;
		}


		public Date getReleasedt() {
			return releasedt;
		}


		public void setReleasedt(Date releasedt) {
			this.releasedt = releasedt;
		}


		public Date getSupportdt() {
			return supportdt;
		}


		public void setSupportdt(Date supportdt) {
			this.supportdt = supportdt;
		}


		public Date getEoldt() {
			return eoldt;
		}


		public void setEoldt(Date eoldt) {
			this.eoldt = eoldt;
		}


	

		


		public int getIsActive() {
			return isActive;
		}


		public void setIsActive(int isActive) {
			this.isActive = isActive;
		}


		public Date getRecInsdt() {
			return recInsdt;
		}


		public void setRecInsdt(Date recInsdt) {
			this.recInsdt = recInsdt;
		}


		public Date getRecUpddt() {
			return recUpddt;
		}


		public void setRecUpddt(Date recUpddt) {
			this.recUpddt = recUpddt;
		}
	
}
