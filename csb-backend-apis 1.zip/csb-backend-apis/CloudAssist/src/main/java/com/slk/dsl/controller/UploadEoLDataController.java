package com.slk.dsl.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.slk.dsl.dto.FileResponseMessage;
import com.slk.dsl.services.EOLDataSaveAfterUploadingService;
@RestController
@CrossOrigin
public class UploadEoLDataController {
	
	private static final Logger logger = LoggerFactory.getLogger(FileUploadController.class);
	
	@Autowired
	EOLDataSaveAfterUploadingService EOLservice;
	
	 @PostMapping("/uploadEOLData")
	    public ResponseEntity<FileResponseMessage>  uploadMultipartFile(@RequestParam("UserFile") MultipartFile[] UserFile,@RequestParam("orgId")int orgId){
	       logger.info("File uploaded started");
	       String message = "";
	       //String orgId="1";

		      List<String> files = new ArrayList<>();
		     
	       
	       try {

	    	      Arrays.asList(UserFile).stream().forEach(file -> {
	    	    	  try {
	    	    		  EOLservice.saveEOLDataFromUploadFile(file,orgId);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
	    	    	  files.add(file.getOriginalFilename());
	    	      });

	    	      message = "Uploaded the files successfully: " + files;
	    	      return ResponseEntity.status(HttpStatus.OK).body(new FileResponseMessage(message,files));
	    	    } catch (Exception e) {
	    	      message = "Fail to upload files!";
	    	      
	    	      return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new FileResponseMessage(message,files));
	    	    }
		
	    	  }

	       

	  
	  

}
