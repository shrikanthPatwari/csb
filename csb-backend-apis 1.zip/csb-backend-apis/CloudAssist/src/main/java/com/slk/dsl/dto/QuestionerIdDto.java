package com.slk.dsl.dto;

public class QuestionerIdDto {
	
  private int questionerId;
  private String question;
public int getQuestionerId() {
	return questionerId;
}
public void setQuestionerId(int questionerId) {
	this.questionerId = questionerId;
}
public String getQuestion() {
	return question;
}
public void setQuestion(String question) {
	this.question = question;
}
  
  
  

}
