package com.slk.dsl.services;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.slk.dsl.dto.MoveGroupApplicationsDTO;
import com.slk.dsl.dto.MoveGroupRehostApplicationsDTO;
import com.slk.dsl.model.MoveGroupAppMapping;
import com.slk.dsl.repository.MoveGroupAppMappingRep;
import com.slk.dsl.repository.MoveGroupRepo;

@Service
public class MoveGroupAppMappingService {
	@Autowired
	MoveGroupAppMappingRep repo;

	@Autowired
	MoveGroupRepo group;

	public MoveGroupAppMapping saveMoveGroupApp(List<MoveGroupAppMapping> grpDetails) {
		int MovegrouId = 0;
		for (MoveGroupAppMapping grp1 : grpDetails) {
			MovegrouId = grp1.getMoveGroupID();
			if (group.findById(MovegrouId) != null) {
				repo.deleteapp(MovegrouId);
			}
		}
		MoveGroupAppMapping grp1 = new MoveGroupAppMapping();
		for (MoveGroupAppMapping grp : grpDetails) {
			grp.setMoveGroupID(grp.getMoveGroupID());
			grp.setAppMasterId(grp.getAppMasterId());
			grp.setRecInsDT(grp.getRecInsDT());
			grp.setRecUpDT(grp.getRecUpDT());
			repo.save(grp);
		}
		return grp1;
	}

	public List<MoveGroupApplicationsDTO> getAppNames(int MoveGroupId) {
		List<Object[]> queryResult = repo.getAppName(MoveGroupId);
		List<MoveGroupApplicationsDTO> result = new ArrayList<MoveGroupApplicationsDTO>();

		queryResult.stream().forEach(objects -> {
			MoveGroupApplicationsDTO temp = new MoveGroupApplicationsDTO();
			temp.setApp_Name(objects[0].toString());
			temp.setApp_Master_Id((Integer) objects[1]);
			result.add(temp);
		});
		return result;
	}

	public List<MoveGroupRehostApplicationsDTO> getRehostapp(int orgId) {
		List<Object[]> queryResult = repo.getRehost(orgId);
		List<MoveGroupRehostApplicationsDTO> result = new ArrayList<MoveGroupRehostApplicationsDTO>();

		queryResult.stream().forEach(objects -> {
			MoveGroupRehostApplicationsDTO temp = new MoveGroupRehostApplicationsDTO();
			temp.setApp_Master_Id((Integer) objects[0]);
			temp.setApp_Name(objects[1].toString());
			result.add(temp);
		});
		return result;
	}

	public String delete(int id) {
		repo.deleteapp(id);
		return "App deleted";
	}

	public List<MoveGroupAppMapping> getGroupById() {
		return repo.findAll();
	}
}
