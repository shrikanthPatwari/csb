package com.slk.dsl.exceptions;

public class SQLIntegrityConstraintViolationException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SQLIntegrityConstraintViolationException() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	

}
