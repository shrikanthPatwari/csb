package com.slk.dsl.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ca_process_data")

public class ProcessDataModel {
	

	@Id @GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="Process_Id",nullable = false, unique = true)
	private int ProcessId;
	
	@Column(name="Org_Id")
	private int orgId;
	
	@Column(name="App_Master_Id")
	private int AppMasterId;
	
	@Column(name="BusinessOwner")
	private String BusinessOwner;
	
	@Column(name="BusinessOwnerEmployeeID")
	private String BusinessOwnerEmployeeID;
	
	public int getProcessId() {
		return ProcessId;
	}

	public void setProcessId(int processId) {
		ProcessId = processId;
	}

	public int getOrgId() {
		return orgId;
	}

	public void setOrgId(int orgId) {
		this.orgId = orgId;
	}

	public int getAppMasterId() {
		return AppMasterId;
	}

	public void setAppMasterId(int appMasterId) {
		AppMasterId = appMasterId;
	}

	public String getBusinessOwner() {
		return BusinessOwner;
	}

	public void setBusinessOwner(String businessOwner) {
		BusinessOwner = businessOwner;
	}

	public String getBusinessOwnerEmployeeID() {
		return BusinessOwnerEmployeeID;
	}

	public void setBusinessOwnerEmployeeID(String businessOwnerEmployeeID) {
		BusinessOwnerEmployeeID = businessOwnerEmployeeID;
	}

	public String getBusinessManager() {
		return businessManager;
	}

	public void setBusinessManager(String businessManager) {
		this.businessManager = businessManager;
	}

	public String getBusinessManagerEmployeeID() {
		return businessManagerEmployeeID;
	}

	public void setBusinessManagerEmployeeID(String businessManagerEmployeeID) {
		this.businessManagerEmployeeID = businessManagerEmployeeID;
	}

	public String geteTDirector() {
		return eTDirector;
	}

	public void seteTDirector(String eTDirector) {
		this.eTDirector = eTDirector;
	}

	public String geteTDirectorEmployeeID() {
		return eTDirectorEmployeeID;
	}

	public void seteTDirectorEmployeeID(String eTDirectorEmployeeID) {
		this.eTDirectorEmployeeID = eTDirectorEmployeeID;
	}

	public String geteTManager() {
		return eTManager;
	}

	public void seteTManager(String eTManager) {
		this.eTManager = eTManager;
	}

	public String geteTManagerEmployeeID() {
		return eTManagerEmployeeID;
	}

	public void seteTManagerEmployeeID(String eTManagerEmployeeID) {
		this.eTManagerEmployeeID = eTManagerEmployeeID;
	}

	public String geteTPrimaryTechnical() {
		return eTPrimaryTechnical;
	}

	public void seteTPrimaryTechnical(String eTPrimaryTechnical) {
		this.eTPrimaryTechnical = eTPrimaryTechnical;
	}

	public String geteTPrimaryTechnicalEmployeeID() {
		return eTPrimaryTechnicalEmployeeID;
	}

	public void seteTPrimaryTechnicalEmployeeID(String eTPrimaryTechnicalEmployeeID) {
		this.eTPrimaryTechnicalEmployeeID = eTPrimaryTechnicalEmployeeID;
	}

	public String geteTSecondaryTechnical() {
		return eTSecondaryTechnical;
	}

	public void seteTSecondaryTechnical(String eTSecondaryTechnical) {
		this.eTSecondaryTechnical = eTSecondaryTechnical;
	}

	public String geteTSecondaryTechnicalEmployeeID() {
		return eTSecondaryTechnicalEmployeeID;
	}

	public void seteTSecondaryTechnicalEmployeeID(String eTSecondaryTechnicalEmployeeID) {
		this.eTSecondaryTechnicalEmployeeID = eTSecondaryTechnicalEmployeeID;
	}

	public String getSCName() {
		return SCName;
	}

	public void setSCName(String sCName) {
		SCName = sCName;
	}

	public String getQualityScore() {
		return QualityScore;
	}

	public void setQualityScore(String qualityScore) {
		QualityScore = qualityScore;
	}

	public String getDomain() {
		return Domain;
	}

	public void setDomain(String domain) {
		Domain = domain;
	}

	public String getManagerCertification() {
		return ManagerCertification;
	}

	public void setManagerCertification(String managerCertification) {
		ManagerCertification = managerCertification;
	}

	public String getDRExerciseResults() {
		return DRExerciseResults;
	}

	public void setDRExerciseResults(String dRExerciseResults) {
		DRExerciseResults = dRExerciseResults;
	}

	public String getApplicationDRPlan() {
		return ApplicationDRPlan;
	}

	public void setApplicationDRPlan(String applicationDRPlan) {
		ApplicationDRPlan = applicationDRPlan;
	}

	public String getDRExerciseDate() {
		return DRExerciseDate;
	}

	public void setDRExerciseDate(String dRExerciseDate) {
		DRExerciseDate = dRExerciseDate;
	}

	public String getDRTier() {
		return DRTier;
	}

	public void setDRTier(String dRTier) {
		DRTier = dRTier;
	}

	public String getDRPlanDate() {
		return DRPlanDate;
	}

	public void setDRPlanDate(String dRPlanDate) {
		DRPlanDate = dRPlanDate;
	}

	@Column(name="BusinessManager")
	private String businessManager;
	
	@Column(name="BusinessManagerEmployeeID")
	private String businessManagerEmployeeID;
	
	
	
	@Column(name="ETDirector")
	private String eTDirector;
	
	@Column(name="ETDirectorEmployeeID")
	private String eTDirectorEmployeeID;
	
	@Column(name="ETManager")
	private String eTManager;
	
	
	@Column(name="ETManagerEmployeeID")
	private String eTManagerEmployeeID;
	
	@Column(name="ETPrimaryTechnical")
	private String eTPrimaryTechnical;
	@Column(name="ETPrimaryTechnicalEmployeeID")
	private String eTPrimaryTechnicalEmployeeID;
	
	
	@Column(name="ETSecondaryTechnical")
	private String eTSecondaryTechnical;
	@Column(name="ETSecondaryTechnicalEmployeeID")
	private String eTSecondaryTechnicalEmployeeID;
	
	@Column(name="SCName")
	private String SCName;
	
	@Column(name="QualityScore")
	private String QualityScore;
	
	@Column(name="Domain")
	private String Domain;
	
	@Column(name="ManagerCertification")
	private String ManagerCertification;
	
	@Column(name="DRExerciseResults")
	private String DRExerciseResults;
	
	@Column(name="ApplicationDRPlan")
	private String ApplicationDRPlan;
	
	
	@Column(name="DRExerciseDate")
	private String DRExerciseDate;
	
	@Column(name="DRTier")
	private String DRTier;
	
	@Column(name="DRPlanDate")
	private String DRPlanDate;
	
}
