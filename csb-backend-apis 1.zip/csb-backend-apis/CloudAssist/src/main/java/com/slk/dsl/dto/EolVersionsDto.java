package com.slk.dsl.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class EolVersionsDto {
	int version_ID;
	String product_Name;
	String version;
	@JsonFormat(pattern="yyyy-MM-dd",timezone = "IST")
	Date release_dt;
	@JsonFormat(pattern="yyyy-MM-dd",timezone = "IST")
	Date support_dt;
	@JsonFormat(pattern="yyyy-MM-dd",timezone = "IST")
	Date eol_dt;
	int is_Active;
	int product_ID;
	public Date getSupport_dt() {
		return support_dt;
	}
	public void setSupport_dt(Date support_dt) {
		this.support_dt = support_dt;
	}
	
	
	public String getProduct_Name() {
		return product_Name;
	}
	public void setProduct_Name(String product_Name) {
		this.product_Name = product_Name;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}

	
	public Date getEol_dt() {
		return eol_dt;
	}
	public void setEol_dt(Date eol_dt) {
		this.eol_dt = eol_dt;
	}
	public int getIs_Active() {
		return is_Active;
	}
	public void setIs_Active(int is_Active) {
		this.is_Active = is_Active;
	}
	public Date getRelease_dt() {
		return release_dt;
	}
	public void setRelease_dt(Date release_dt) {
		this.release_dt = release_dt;
	}
	public int getVersion_ID() {
		return version_ID;
	}
	public void setVersion_ID(int version_ID) {
		this.version_ID = version_ID;
	}
	public int getProduct_ID() {
		return product_ID;
	}
	public void setProduct_ID(int product_ID) {
		this.product_ID = product_ID;
	}
	
	
}
