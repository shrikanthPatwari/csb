package com.slk.dsl.dto;

public class MoveGroupCountDTO {
String MoveGroupAppCount;
String MoveGroupName;

public String getMoveGroupAppCount() {
	return MoveGroupAppCount;
}
public void setMoveGroupAppCount(String moveGroupAppCount) {
	MoveGroupAppCount = moveGroupAppCount;
}
public String getMoveGroupName() {
	return MoveGroupName;
}
public void setMoveGroupName(String moveGroupName) {
	MoveGroupName = moveGroupName;
}
}
