package com.slk.dsl.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class OSServerEOLDTO {
	
	String App_Name;
	String Host_Name;
	public String getApp_Name() {
		return App_Name;
	}
	public void setApp_Name(String app_Name) {
		App_Name = app_Name;
	}
	public String getHost_Name() {
		return Host_Name;
	}
	public void setHost_Name(String host_Name) {
		Host_Name = host_Name;
	}
	public String getIP_Address() {
		return IP_Address;
	}
	public void setIP_Address(String iP_Address) {
		IP_Address = iP_Address;
	}
	public String getEnvironment() {
		return Environment;
	}
	public void setEnvironment(String environment) {
		Environment = environment;
	}
	public String getOS_Type() {
		return OS_Type;
	}
	public void setOS_Type(String oS_Type) {
		OS_Type = oS_Type;
	}
	public String getOS_Version() {
		return OS_Version;
	}
	public void setOS_Version(String oS_Version) {
		OS_Version = oS_Version;
	}


	public String getCritical() {
		return Critical;
	}
	public void setCritical(String critical) {
		Critical = critical;
	}
	public Date getSupport_dt() {
		return support_dt;
	}
	public void setSupport_dt(Date support_dt) {
		this.support_dt = support_dt;
	}
	public Date getEol_dt() {
		return eol_dt;
	}
	public void setEol_dt(Date eol_dt) {
		this.eol_dt = eol_dt;
	}
	String IP_Address;
	String Environment;
	String OS_Type;
	String OS_Version;
	@JsonFormat(pattern="yyyy-MM-dd")
	Date support_dt;
	@JsonFormat(pattern="yyyy-MM-dd")
	Date eol_dt;
	String Critical;
}
