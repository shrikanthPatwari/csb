package com.slk.dsl.dto;

public class QuestionerPrimary {

	int App_Id;
	String App_System;
	String Field_Name;
	public int getAppId() {
		return App_Id;
	}
	public void setAppId(int App_Id) {
		this.App_Id = App_Id;
	}
	public String getAppSystem() {
		return App_System;
	}
	public void setAppSystem(String App_System) {
		this.App_System = App_System;
	}
	public String getFieldName() {
		return Field_Name;
	}
	public void setFieldName(String Field_Name) {
		this.Field_Name = Field_Name;
	}
	
}
