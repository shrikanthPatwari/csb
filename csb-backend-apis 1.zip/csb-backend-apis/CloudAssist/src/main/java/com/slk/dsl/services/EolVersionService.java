package com.slk.dsl.services;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slk.dsl.dto.EolVersionsDto;
import com.slk.dsl.dto.migrationdto;
import com.slk.dsl.model.EolVersion;
import com.slk.dsl.repository.EolVersionRepo;
@Service
public class EolVersionService {
	@Autowired
	EolVersionRepo repo1;
	
	public EolVersion saveProductListVersion(EolVersion eolproductversion) {
		// TODO Auto-generated method stub
		EolVersion vers = new EolVersion();
		vers.setProductID(eolproductversion.getProductID());
		vers.setEoldt(eolproductversion.getEoldt());
		vers.setIsActive(eolproductversion.getIsActive());
		//vers.setIsActive(1);		
		vers.setVersion(eolproductversion.getVersion());
		vers.setSupportdt(eolproductversion.getSupportdt());
		vers.setReleasedt(eolproductversion.getReleasedt());
		vers.setRecInsdt(eolproductversion.getRecInsdt());
		vers.setRecUpddt(eolproductversion.getRecUpddt());
		
		return repo1.save(vers);
	}
		public List<EolVersionsDto> getAppVersions(int prodId) {  
			List<Object[]> queryResult = repo1.getAppVersions(prodId);
			List<EolVersionsDto> result = new ArrayList<EolVersionsDto>();

			queryResult.stream().forEach(objects->{
				EolVersionsDto temp = new EolVersionsDto();
				temp.setProduct_Name(objects[0].toString());
				temp.setVersion(objects[1].toString());
				temp.setSupport_dt((Date)objects[2]);
				temp.setEol_dt((Date)objects[3]);
				temp.setIs_Active((Integer)objects[4]);
				temp.setRelease_dt((Date)objects[5]);
				temp.setVersion_ID((Integer)objects[6]);
				temp.setProduct_ID((Integer)objects[7]);
				result.add(temp);
				});
			return result;
			}
		public String delete(int id) {
			
			 repo1.deleteAllVersions(id);
			  return "Product Versions deleted";
			  
		}
		public String deleteVersion(int id) {
			
			 repo1.deleteVersion(id);
			  return "Product Versions deleted";
	}
}
