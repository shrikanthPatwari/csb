package com.slk.dsl.services;

import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.slk.dsl.dto.AppIdFetchDTO;
import com.slk.dsl.dto.AppMasterIdAppNameDTO;
import com.slk.dsl.dto.DelegateSurveyDTO;
import com.slk.dsl.dto.delegateuserDetailsDTO;
import com.slk.dsl.model.Application;
import com.slk.dsl.model.DAOUser;
import com.slk.dsl.model.UserSetup;
import com.slk.dsl.model.ca_user_app_mapping;
import com.slk.dsl.repository.UserSetupDao;
import com.slk.dsl.repository.ca_user_app_mappingDAO;

@Service
public class ca_user_app_mappingService {
	@Autowired
	ca_user_app_mappingDAO userMappingdao;
	
	
	
	
public void saveUserMapping( List<ca_user_app_mapping> userMapping, String LobId) {
	userMapping.forEach(obj->{
		Date d = new Date();
		obj.setRecInsDt(d);
		obj.setLobId(Integer.valueOf(LobId));
	});
	userMappingdao.saveAll(userMapping);
	}

public List<ca_user_app_mapping[]> caUserMapping(int orgId) {  
    return userMappingdao.getcaUserMapping(orgId);
} 

public List<AppMasterIdAppNameDTO> getappidappname(int lobid) {  
    List<Object[]> object =  userMappingdao.getCaUserList(lobid);
    List<AppMasterIdAppNameDTO> appmidappName = new ArrayList<AppMasterIdAppNameDTO>();
    object.forEach(obj->{
    	AppMasterIdAppNameDTO temp = new AppMasterIdAppNameDTO();
    	temp.setApp_Master_Id((Integer)obj[0]);
    	temp.setApp_Name(obj[1].toString());
    	appmidappName.add(temp);
    });
    return appmidappName;
}

public List<AppIdFetchDTO> getappid(int userid) {  
    List<Object[]> object =  userMappingdao.getappIdList(userid);
    List<AppIdFetchDTO> appidapp = new ArrayList<AppIdFetchDTO>();
    object.forEach(obj->{
    	AppIdFetchDTO temp = new AppIdFetchDTO();
    	temp.setApp_Master_Id((Integer)obj[0]);
    	temp.setLob_Id((Integer)obj[1]);
    	temp.setUsr_Id((Integer)obj[2]);
    	temp.setLob_Name(obj[3].toString());
    	
    	//temp.setApp_Name(obj[1].toString());
    	appidapp.add(temp);
    });
    return appidapp;
}


public String delete(int id) {
	
	userMappingdao.deleteapp(id);
	  return "App deleted";
}
public void delegateuserMapping( List<ca_user_app_mapping> userMapping, String LobId) {
	
	List<ca_user_app_mapping> user_app_mapping= new ArrayList<ca_user_app_mapping>();
	
	user_app_mapping = userMappingdao.findAll();
	
	user_app_mapping.forEach(a->{
		userMapping.forEach(b->{
			if(a.getAppMasterId().equals(b.getAppMasterId()))  {
						
			a.setDelegated_Usr_Id(b.getUsrId());
				
						
				 
			}
		
	});
	
	});
	userMappingdao.saveAll(user_app_mapping);

	
}

//public List<DelegateSurveyDTO> getDelegateSurveyDetails(int orgId) {  
//    List<Object[]> object =  userMappingdao.getDelegateSurvey(orgId);
//    List<DelegateSurveyDTO> details = new ArrayList<DelegateSurveyDTO>();
//    object.forEach(obj->{
//    	DelegateSurveyDTO temp = new DelegateSurveyDTO();
//    	temp.setUsr_Id((Integer)obj[0]);
//    	temp.setApp_Master_Id((Integer)obj[1]);
//    	temp.setDelegated_Usr_Id((Integer)obj[2]);
//    	temp.setApp_Name(obj[3].toString());
//    	temp.setAssigned_By(obj[4].toString());
//    	temp.setAssigned_To(obj[5].toString());
//    	temp.setApp_Suv_Status((Integer)obj[6]);
//    	temp.setAssigned_By_MailId(obj[7].toString());
//    	temp.setAssigned_To_MailId(obj[8].toString());
//
//    	//temp.setApp_Name(obj[1].toString());
//    	details.add(temp);
//    });
//    return details;
//}

public List<DelegateSurveyDTO> getDelegateSurveyDetails(int orgId) {  
//	String url = "http://localhost:8084/GetAllUsers/" +orgId+ "";
	String url = "https://slk-ip-digitaltoolbox-api.azurewebsites.net/GetAllUsers/" +orgId+ "";
	RestTemplate restTemplate = new RestTemplate();
	delegateuserDetailsDTO[] user = restTemplate.getForObject(url,delegateuserDetailsDTO[].class);
    List<Object[]> object =  userMappingdao.getDelegateSurvey(orgId);
    List<DelegateSurveyDTO> details = new ArrayList<DelegateSurveyDTO>();
    
        object.forEach(obj->{
    	DelegateSurveyDTO temp = new DelegateSurveyDTO();
    	temp.setUsr_Id((Integer)obj[0]);
    	temp.setApp_Master_Id((Integer)obj[1]);
    	temp.setDelegated_Usr_Id((Integer)obj[2]);
    	temp.setApp_Name(obj[3].toString());
    	temp.setApp_Suv_Status((Integer)obj[4]);
    	for(delegateuserDetailsDTO usr:user) {
    	if(temp.getUsr_Id() ==usr.getUserId()) {
    	temp.setAssigned_By(usr.getFirstName());
    	temp.setAssigned_By_MailId(usr.getEmailAddress());
    	}
    	if(temp.getDelegated_Usr_Id()==usr.getUserId()) {
        	temp.setAssigned_To(usr.getFirstName());
        	temp.setAssigned_To_MailId(usr.getEmailAddress());
        }  	
    	}
    	details.add(temp);
    });
    
    return details;
}

public String deleteApps(int userId,int apps) {
	userMappingdao.deleteuncheckedapps(userId,apps);
	  return "App deleted";
}

}
