package com.slk.dsl.dto;

import java.util.List;

public class MessageAppDTO {
	
	String message;
	List<String> appNames;
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}

	public List<String> getAppNames() {
		return appNames;
	}
	public void setAppNames(List<String> appNames) {
		this.appNames = appNames;
	}
	
	

}
