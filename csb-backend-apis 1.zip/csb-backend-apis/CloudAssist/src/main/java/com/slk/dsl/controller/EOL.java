package com.slk.dsl.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.slk.dsl.dto.AppServerEOLDto;
import com.slk.dsl.dto.DatabaseEOLDTO;
import com.slk.dsl.dto.EOLProgressBarDTO;
import com.slk.dsl.dto.OSServerEOLDTO;
import com.slk.dsl.dto.OsNamesDTO;
import com.slk.dsl.dto.SoftwareEOLDTO;
import com.slk.dsl.dto.VendorandDateDTO;
import com.slk.dsl.dto.WebServerEOLDTO;
import com.slk.dsl.services.CAAppMasterService;
import com.slk.dsl.services.EOLService;
@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class EOL {
	@Autowired
	EOLService service;
	
	@GetMapping("EOLProgresslist")  
	public EOLProgressBarDTO getdatabasecount() {
		return service.EOLProgresslist();
	}
	
	@GetMapping("getDatabaseEOL")  
	public List<DatabaseEOLDTO> DatabaseEOL() {
		return service.getDatabaseEOL();

	}
	@GetMapping("getOSServerEOL")  
	public List<OSServerEOLDTO> getOSServerEOL() {
		return service.getOSServerEOL();

	}
			
	@GetMapping("getSoftwareEOL")  
	public List<SoftwareEOLDTO> getSoftwareEOL() {
		return service.getSoftwareEOL();

	}
	
@GetMapping("getAppServeEOL")  
public List<AppServerEOLDto> getAppServeEOL() {
return service.AppServeEOL();

}
@GetMapping("getWebServerEOL")  
public List<WebServerEOLDTO> WebServerEOL() {
return service.WebServerEOL();

}
//	@GetMapping("getDatabaseEOLCount")  
//	public int databaseActivecount() {
//		return service.DatabaseeActiveCount();
//	}
//	
//	
//	@GetMapping("getOsTypeCount")  
//	public int getOscount() {
//		return service.OsTypeCount();
//	}
//	
//	
//	@GetMapping("getOsEOLCount")  
//	public int OsActivecount() {
//		return service.OsActiveCount();
//	}
//	
//	@GetMapping("getTechstackTypeCount")  
//	public int getTechstackcount() {
//		return service.TechstackCount();
//	}

}
