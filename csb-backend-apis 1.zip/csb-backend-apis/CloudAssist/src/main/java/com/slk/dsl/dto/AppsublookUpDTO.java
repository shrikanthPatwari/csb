package com.slk.dsl.dto;

public class AppsublookUpDTO {
	private int questioner_lookup_Id;
	private String questioner_Values;
	private int questioner_Id;
	private String question_description;
	public int getQuestioner_lookup_Id() {
		return questioner_lookup_Id;
	}
	public void setQuestioner_lookup_Id(int questioner_lookup_Id) {
		this.questioner_lookup_Id = questioner_lookup_Id;
	}
	public String getQuestioner_Values() {
		return questioner_Values;
	}
	public void setQuestioner_Values(String questioner_Values) {
		this.questioner_Values = questioner_Values;
	}
	public int getQuestioner_Id() {
		return questioner_Id;
	}
	public void setQuestioner_Id(int questioner_Id) {
		this.questioner_Id = questioner_Id;
	}
	public String getQuestion_description() {
		return question_description;
	}
	public void setQuestion_description(String question_description) {
		this.question_description = question_description;
	}
	
	

}
