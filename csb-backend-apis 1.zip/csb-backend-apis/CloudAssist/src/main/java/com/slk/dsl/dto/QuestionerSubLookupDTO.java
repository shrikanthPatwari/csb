package com.slk.dsl.dto;

public class QuestionerSubLookupDTO {

	String questioner_sublookup_values;
	
	int questioner_lookup_Id;

	public String getQuestioner_sublookup_values() {
		return questioner_sublookup_values;
	}

	public void setQuestioner_sublookup_values(String questioner_sublookup_values) {
		this.questioner_sublookup_values = questioner_sublookup_values;
	}

	public int getQuestioner_lookup_Id() {
		return questioner_lookup_Id;
	}

	public void setQuestioner_lookup_Id(int questioner_lookup_Id) {
		this.questioner_lookup_Id = questioner_lookup_Id;
	}



	
	
}
