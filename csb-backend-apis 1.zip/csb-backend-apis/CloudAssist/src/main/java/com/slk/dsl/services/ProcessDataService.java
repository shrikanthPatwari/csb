package com.slk.dsl.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slk.dsl.dto.MoveGroupRehostApplicationsDTO;
import com.slk.dsl.dto.ProcessDataDTO;
import com.slk.dsl.model.Application;
import com.slk.dsl.model.InfraDataModel;
import com.slk.dsl.model.ProcessDataModel;
import com.slk.dsl.repository.ProcessDataRepo;
@Service
public class ProcessDataService {
	@Autowired
	ProcessDataRepo repo;
	
	public List<ProcessDataModel> getProcessData(int orgId) {  
	    return repo.getdataprocess(orgId);
}
	
	public ProcessDataModel saveProcess(ProcessDataModel processData)   {
		ProcessDataModel processrecord = new ProcessDataModel();
		processrecord.setBusinessOwner(processData.getBusinessOwner());		
		processrecord.setBusinessManager(processData.getBusinessManager());
		processrecord.setAppMasterId(processData.getAppMasterId());
		processrecord.setOrgId(processData.getOrgId());
		repo.saveProc(processData.getBusinessOwner(),processData.getBusinessManager(),processData.getAppMasterId(),processData.getOrgId());
		return processrecord;
	}
	
	
	
	public List<ProcessDataDTO> getProcessapp(int orgId) {  
		List<Object[]> queryResult = repo.getProcess(orgId);
		List<ProcessDataDTO> result = new ArrayList<ProcessDataDTO>();

		queryResult.stream().forEach(objects->{
			ProcessDataDTO temp = new ProcessDataDTO();
			temp.setApp_Master_Id((Integer)objects[0]);
			temp.setApp_Name(objects[1].toString());
			result.add(temp);
			});
		return result;
		}
	
	public void delete(int id)   {
		//repo.deleteappincainframapping(id);
		repo.deleteById(id);
	}
	
	public void updateProcess(List<ProcessDataModel> processDetails)
	{
		List<ProcessDataModel> process= new ArrayList<ProcessDataModel>();
		
		for(ProcessDataModel processData: processDetails) {
			processData.setApplicationDRPlan(processData.getApplicationDRPlan());
			processData.setAppMasterId(processData.getAppMasterId());
			processData.setBusinessManager(processData.getBusinessManager());
			processData.setBusinessManagerEmployeeID(processData.getBusinessManagerEmployeeID());
			processData.setBusinessOwner(processData.getBusinessOwner());
			processData.setBusinessOwnerEmployeeID(processData.getBusinessOwnerEmployeeID());
			processData.setDomain(processData.getDomain());
			processData.setDRExerciseDate(processData.getDRExerciseDate());
			processData.setDRExerciseResults(processData.getDRExerciseResults());
			processData.setDRPlanDate(processData.getDRPlanDate());
			processData.setDRTier(processData.getDRTier());
			processData.seteTDirector(processData.geteTDirector());
			processData.seteTDirectorEmployeeID(processData.geteTDirectorEmployeeID());
			processData.seteTManager(processData.geteTManager());
			processData.seteTManagerEmployeeID(processData.geteTManagerEmployeeID());
			processData.seteTPrimaryTechnical(processData.geteTPrimaryTechnical());
			processData.seteTPrimaryTechnicalEmployeeID(processData.geteTPrimaryTechnicalEmployeeID());
			processData.seteTSecondaryTechnical(processData.geteTSecondaryTechnical());
			processData.seteTSecondaryTechnicalEmployeeID(processData.geteTSecondaryTechnicalEmployeeID());
			processData.setManagerCertification(processData.getManagerCertification());
			processData.setOrgId(processData.getOrgId());
			processData.setProcessId(processData.getProcessId());
			processData.setQualityScore(processData.getQualityScore());
			processData.setSCName(processData.getSCName());
			 		
			process.add(processData);
		}
		
		repo.saveAll(process);
	}

}