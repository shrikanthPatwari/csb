package com.slk.dsl.dto;

import java.math.BigInteger;

public class UserDashboardDTO {

	
	int app_master_id;
	String app_name;
	String app_id;
	String lob_name;
	int Lob_Id;
	public int getLob_Id() {
		return Lob_Id;
	}
	public void setLob_Id(int lob_Id) {
		Lob_Id = lob_Id;
	}
	public String getLob_name() {
		return lob_name;
	}
	public void setLob_name(String lob_name) {
		this.lob_name = lob_name;
	}
	public String getApp_name() {
		return app_name;
	}
	public String getApp_id() {
		return app_id;
	}
	public void setApp_id(String app_id) {
		this.app_id = app_id;
	}
	public void setApp_name(String app_name) {
		this.app_name = app_name;
	}
	int app_suv_status;
	public int getApp_master_id() {
		return app_master_id;
	}
	public void setApp_master_id(int app_master_id) {
		this.app_master_id = app_master_id;
	}
	public int getApp_suv_status() {
		return app_suv_status;
	}
	public void setApp_suv_status(int app_suv_status) {
		this.app_suv_status = app_suv_status;
	}
	String lob_manager;
	String vendor;
	
	
	public String getLob_manager() {
		return lob_manager;
	}
	public void setLob_manager(String lob_manager) {
		this.lob_manager = lob_manager;
	}
	public String getVendor() {
		return vendor;
	}
	public void setVendor(String vendor) {
		this.vendor = vendor;
	}
	
	
	
}
