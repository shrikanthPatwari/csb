package com.slk.dsl.dto;

public class OsNamesDTO {
String name;
String count;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getCount() {
	return count;
}
public void setCount(String count) {
	this.count = count;
}

}
