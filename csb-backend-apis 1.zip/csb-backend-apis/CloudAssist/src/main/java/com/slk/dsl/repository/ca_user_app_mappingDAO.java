package com.slk.dsl.repository;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.slk.dsl.model.Application;
import com.slk.dsl.model.ca_user_app_mapping;

@Repository
public interface ca_user_app_mappingDAO  extends JpaRepository<ca_user_app_mapping, Integer> {

	String ca_user_mapping= "select * from ca_user_app_mapping where Org_Id=:orgId  ";
	@Modifying
	@Transactional
	@Query(value = ca_user_mapping, nativeQuery = true)
	public List<ca_user_app_mapping[]> getcaUserMapping(int orgId);
	
	String ca_usr_list= "select app_master_id,app_name from ca_app_master where LOB_Id=:lobid  and app_master_id not in (SELECT App_Master_Id FROM ca_user_app_mapping) ";
	@Query(value = ca_usr_list, nativeQuery = true)
	public List<Object[]> getCaUserList(int lobid);
	
	String app_id_list= "SELECT ca.App_Master_Id ,ca.Lob_Id,ca.Usr_Id, cl.Lob_Name FROM ca_user_app_mapping ca inner join ca_lob_master cl on ca.Lob_Id=cl.Lob_Id  where Usr_Id=:userid";
	@Query(value = app_id_list, nativeQuery = true)
	public List<Object[]> getappIdList(int userid);
	

	String deletapp = "delete from ca_user_app_mapping where usr_Id=:id";
	@Modifying
	@Transactional
	@Query(value = deletapp, nativeQuery = true)
	public void deleteapp(int id);
	
	String deletAppMapping = "delete from ca_user_app_mapping where Org_Id=:orgId";
	@Modifying
	@Transactional
	@Query(value = deletAppMapping, nativeQuery = true) 
	public void deleteappMapping(int orgId);
	
	String delegatesurveylist= "select am.Usr_Id,am.App_Master_Id,am.Delegated_Usr_Id,cm.App_Name,\r\n"
			+ "cm.App_Suv_Status from ca_user_app_mapping am\r\n"
			+ "inner join ca_app_master cm on am.App_Master_Id=cm.App_Master_Id\r\n"
			+ "where am.Org_Id=cm.Org_Id=:orgId and am.Delegated_Usr_Id !=0";
	@Query(value = delegatesurveylist, nativeQuery = true)
	public List<Object[]> getDelegateSurvey(int orgId);
	
	String deletappList = "delete from ca_user_app_mapping where App_Master_Id =:apps and Usr_Id=:userId";
	@Modifying
	@Transactional
	@Query(value = deletappList, nativeQuery = true)
	public void deleteuncheckedapps(int userId,int apps);
	
	String userIdInDb= "select Usr_App_Id from ca_user_app_mapping where Usr_Id=:userId and Org_Id=:orgId and App_Master_Id=:appMasterId";
	@Query(value = userIdInDb, nativeQuery = true)
	public List<Object[]> userIdInDb(int userId,int orgId,String appMasterId);
	
}
