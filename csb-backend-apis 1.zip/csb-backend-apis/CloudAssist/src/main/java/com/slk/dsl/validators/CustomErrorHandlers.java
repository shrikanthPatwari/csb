package com.slk.dsl.validators;

public class CustomErrorHandlers extends RuntimeException  {

}
