package com.slk.dsl.dto;

import java.util.List;


public class UserAndOrgDetailsDTO {
	
	String userEmail;
	List<DetailsDTO> details;
	
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public List<DetailsDTO> getDetails() {
		return details;
	}
	public void setDetails(List<DetailsDTO> details) {
		this.details = details;
	}


	
}
