package com.slk.dsl.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.slk.dsl.model.EolProducts;
import com.slk.dsl.model.EolVersion;
import com.slk.dsl.model.MoveGroup;
import com.slk.dsl.model.UserSetup;
import com.slk.dsl.services.EOLService;
import com.slk.dsl.services.EolProductsService;
@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class EolProductsController {

	@Autowired
	EolProductsService service;
@PostMapping("/createEolProducts")
	
	public EolProducts productDetails(@RequestBody EolProducts Eolproducts) {
		
		return service.saveProductList(Eolproducts);

	
}

	@GetMapping("Productlist")  
	public List<EolProducts> allProducts() {  
	     return service.getProducts();
	      
	}
	 @DeleteMapping("deleteProduct/{id}")
	  public String delete(@PathVariable int id)  {
		  
		 service.delete(id);
		  return "Product deleted";
	  }

	  @PutMapping("updateProducts")
		public void update(@RequestBody EolProducts Eolproducts) {
		   service.updateProducts(Eolproducts);
		  
	  }
}
