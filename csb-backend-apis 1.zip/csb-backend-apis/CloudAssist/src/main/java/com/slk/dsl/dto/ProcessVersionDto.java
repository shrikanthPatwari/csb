package com.slk.dsl.dto;

import java.io.Serializable;
import java.util.List;

import com.slk.dsl.model.ApplicationVersionData;
import com.slk.dsl.model.ProcessVersionData;

public class ProcessVersionDto  implements Serializable{
	private int versionId;
	private List<ProcessVersionData> processData;

	public int getVersionId() {
		return versionId;
	}
	public void setVersionId(int versionId) {
		this.versionId = versionId;
	}
	
	public void setProcessData(List<ProcessVersionData> processData) {
		this.processData = processData;
	}
	public List<ProcessVersionData> getProcessData() {
		// TODO Auto-generated method stub
		return processData;
	}
	
}
