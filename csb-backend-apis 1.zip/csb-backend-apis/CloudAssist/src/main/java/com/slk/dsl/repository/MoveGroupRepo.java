package com.slk.dsl.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.slk.dsl.model.MoveGroup;

public interface MoveGroupRepo extends JpaRepository <MoveGroup,Integer>{
	
	

	String appName="SELECT * FROM ca_move_group where Org_Id=:orgId";

	@Query(value = appName, nativeQuery = true)
	public List<MoveGroup[]> findByOrgId(int orgId);
	
	
	String movegroupName ="Select Move_Group_Name FROM ca_move_group where Move_Group_Name=:name and Org_Id=:orgId";

	 @Query(value = movegroupName, nativeQuery = true)
	 public String findMovegroupName(int orgId,String name);


	String updategroup = "update ca_move_group set Move_Group_Name = :moveGroupName where Move_Group_Id= :id ";
	@Transactional
	@Modifying
	@Query(value = updategroup, nativeQuery = true)
	public void updateGroup(String moveGroupName,int id);
	
	String MoveGroupAppcount = "select count(*), ca.Move_Group_Name from ca_move_group ca\n"
			+ "				inner join ca_movegroup_app_mapping app on ca.Move_Group_Id=app.Move_Group_Id \n"
			+ "				where  app.Move_Group_Id in (select distinct(Move_Group_Id) from ca_movegroup_app_mapping ) and ca.Org_Id=:orgId group by  app.Move_Group_Id  order by count(*) desc";
	@Query(value = MoveGroupAppcount, nativeQuery = true)
	public List<Object[]> getMoveGroupAppcount(int orgId);
	
	String MoveGroupTreeChart = "select ca.Move_Group_Id,ca.App_Master_Id,ca.Movegroup_App_Id,cm.Move_Group_Name,app.App_Name,lb.Lob_Name,app.App_Id from ca_movegroup_app_mapping ca \n"
			+ "inner join ca_move_group cm on ca.Move_Group_Id = cm.Move_Group_Id \n"
			+ " inner join ca_app_master app  on ca.App_Master_Id = app.App_Master_Id "
			+ "inner join ca_lob_master lb on app.LOB_Id = lb.Lob_Id where  cm.Org_Id=app.Org_Id=:orgId";
	@Query(value = MoveGroupTreeChart, nativeQuery = true)
	public List<Object[]> getMoveGroupDetails(int orgId);

	 String AutomatedMoveGroup = " SELECT ca.App_Master_Id,app.App_Master_Dependent_Id,ca.App_Complexity, rl.RLane_Strategy, am.App_Complexity as 'Dependent App Complexity' FROM ca_app_master ca\r\n"
	            + "inner join ca_app_dependency app on ca.App_Master_Id = app.App_Master_Id\r\n"
	            + "inner join ca_app_master am on am.App_Master_Id = app.App_Master_Dependent_Id\r\n"
	            + "inner join ca_rlane_strategy_lookup rl on rl.RLane_Strategy_Id = ca.RLane_Strategy_Id\r\n"
	            + "where ca.RLane_Strategy_Id in (1,3,4) and ca.app_Complexity is not null and am.App_Complexity is not null and ca.Org_Id=:orgId";
	    @Query(value = AutomatedMoveGroup, nativeQuery = true)
	    public List<Object[]> getAutomatedMoveGroupDetails(int orgId);
}
