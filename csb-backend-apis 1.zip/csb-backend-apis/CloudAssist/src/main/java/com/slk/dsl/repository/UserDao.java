package com.slk.dsl.repository;




import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.slk.dsl.model.DAOUser;
@Repository
public interface UserDao  extends JpaRepository<DAOUser, Integer>{
	

	//Email_ID from db
	DAOUser findByEmail(String email);
	
	
	String password = "select password from ca_usr_tbl where  email_id= :emailid";
	@Query(value = password, nativeQuery = true)
	public String getPasswordforUser(String emailid);
	
	String userId = "select Usr_Id from ca_usr_tbl where  email_id= :emailid";
	@Query(value = userId, nativeQuery = true)
	public String getUserIdforUser(String emailid);

	String getEmailDetails = "Select usr.Usr_Id,usr.First_Name,usr.Org_Id,org.Org_Name\r\n"
			+ "			from ca_usr_tbl usr inner join ca_org_master org			\r\n"
			+ "			where Email_Id=:email and usr.Org_Id = org.Org_Id;";
	@Query(value = getEmailDetails, nativeQuery = true)
	public List<Object[]> getUserEmailDetails(String email);		
	
	String getUserAppDetails = "Select ca.App_Id,ca.App_Name from ca_user_app_mapping app inner join ca_app_master ca\r\n"
			+ " where app.App_Master_Id = ca.App_Master_Id and app.Usr_Id=:userId";
	@Query(value = getUserAppDetails, nativeQuery = true)
	public List<Object[]> getUserAppDetails(Integer userId);
	
	String getEmailAndPassword = "select Email_Id,Password from ca_usr_tbl where Usr_Id=:userId";
	@Query(value = getEmailAndPassword, nativeQuery = true)
	public List<Object[]> getEmailAndPassword(Integer userId);
}
