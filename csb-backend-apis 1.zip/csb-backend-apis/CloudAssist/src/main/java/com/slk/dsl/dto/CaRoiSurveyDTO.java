package com.slk.dsl.dto;

public class CaRoiSurveyDTO {
	int ROI_Survey_Id;
	String ROI_Survey_Category;
	String ROI_Survey_Question;
	 String is_Active;
	public int getROI_Survey_Id() {
		return ROI_Survey_Id;
	}
	public void setROI_Survey_Id(int rOI_Survey_Id) {
		ROI_Survey_Id = rOI_Survey_Id;
	}
	public String getROI_Survey_Category() {
		return ROI_Survey_Category;
	}
	public void setROI_Survey_Category(String rOI_Survey_Category) {
		ROI_Survey_Category = rOI_Survey_Category;
	}
	public String getROI_Survey_Question() {
		return ROI_Survey_Question;
	}
	public void setROI_Survey_Question(String rOI_Survey_Question) {
		ROI_Survey_Question = rOI_Survey_Question;
	}
	public String getIs_Active() {
		return is_Active;
	}
	public void setIs_Active(String is_Active) {
		this.is_Active = is_Active;
	}
	 

}
