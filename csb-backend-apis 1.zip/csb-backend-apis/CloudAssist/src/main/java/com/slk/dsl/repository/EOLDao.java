package com.slk.dsl.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.slk.dsl.model.Application;
@Repository
public interface EOLDao extends JpaRepository<Application, Integer> {
	
	String DatabaseCount = "select count(Database_Type) FROM ca_app_master ";
	@Query(value = DatabaseCount, nativeQuery = true)
	public int getDatabaseCount();

	String DatabaseEOLCount = "select count(*)\r\n"
			+ "from ca_app_master capp inner join ca_eol_products eol on eol.product_AliasName = capp.Database_Type\r\n"
			+ "inner join ca_eol_version_details elv on elv.product_ID = eol.product_ID and capp.Database_Version = elv.version \r\n"
			+ "where elv.Is_active=0";
	@Query(value = DatabaseEOLCount, nativeQuery = true)
	public int getDatabaseEOLCount();
	
	
	String OsCount = "select count(OS_Type) from ca_infra_data";
	@Query(value = OsCount, nativeQuery = true)
	public int getOsCount();
	
	
	String OSEOLCount = "select count(*) from ca_infra_data cainfra inner join ca_eol_products eol on eol.product_AliasName = cainfra.OS_Type\r\n"
			+ "inner join  ca_eol_version_details elv on elv.product_ID = eol.product_ID and cainfra.OS_Version = elv.version \r\n"
			+ "where elv.Is_active=0";
	@Query(value = OSEOLCount, nativeQuery = true)
	public int getOsEOLCount();
	
	
	String TechstackCount = "select count(Prog_Language) from ca_appmaster_techstack";
	@Query(value = TechstackCount, nativeQuery = true)
	public int getTechstackCount();

	String TechstackEOLCount = "select count(*)from ca_appmaster_techstack caTech inner join ca_eol_products eol on eol.product_AliasName = caTech.Prog_Language\r\n"
			+ "inner join ca_eol_version_details elv on elv.product_ID = eol.product_ID and caTech.Prog_Language_version = elv.version \r\n"
			+ "where elv.Is_active=0";
	@Query(value = TechstackEOLCount, nativeQuery = true)
	public int getTechstackEOLCount();
	
	
	String databaseEOL ="select \r\n"
			+ "capp.App_Name,\r\n"
			+ "lob.Lob_Name, \r\n"
			+ "capp.Database_Type, \r\n"
			+ "capp.Database_Version, \r\n"
			+ "elv.support_dt, \r\n"
			+ "elv.eol_dt, \r\n"
			+ "Case when TIMESTAMPDIFF(MONTH, CURDATE(), eol_dt) <=6 then \"High\" when TIMESTAMPDIFF(MONTH, CURDATE(), eol_dt) >6 and TIMESTAMPDIFF(MONTH, CURDATE(), eol_dt) <=12 then \"Medium\" else \"Low\" end as Criticality,\r\n"
			+ "Case when elv.is_Active = 1 then \"Active\" when elv.is_Active = 0 then \"End of Life\" else \"\" end as isActive from ca_app_master capp \r\n"
			+ "inner join ca_lob_master lob on lob.LOB_Id = capp.LOB_Id\r\n"
			+ "inner join ca_eol_products eol on eol.product_AliasName = capp.Database_Type\r\n"
			+ "inner join ca_eol_version_details elv on elv.product_ID = eol.product_ID and capp.Database_Version = elv.version";
	@Query(value = databaseEOL, nativeQuery = true)
	public  List<Object[]>  getdatabaseEOL();
	
	
	
	String OSServerEOL = "select \r\n"
			+ "capp.App_Name,\r\n"
			+ "inf.Host_Name, \r\n"
			+ "inf.IP_Address, \r\n"
			+ "inf.Environment, \r\n"
			+ "inf.OS_Type, \r\n"
			+ "inf.OS_Version, \r\n"
			+ "elv.support_dt, \r\n"
			+ "elv.eol_dt, \r\n"
			+ "Case when TIMESTAMPDIFF(MONTH, CURDATE(), eol_dt) <=6 then \"High\" when TIMESTAMPDIFF(MONTH, CURDATE(), eol_dt) >6 and TIMESTAMPDIFF(MONTH, CURDATE(), eol_dt) <=12 then \"Medium\" else \"Low\" end as Criticality,\r\n"
			+ "Case when elv.is_Active = 1 then \"Active\" when elv.is_Active = 0 then \"End of Life\" else \"\" end as isActive\r\n"
			+ "from ca_app_master capp \r\n"
			+ "inner join ca_infra_app_mapping inmap on inmap.App_Master_Id = capp.App_Master_Id\r\n"
			+ "inner join ca_infra_data inf on inf.Infra_Id = inmap.Infra_Id\r\n"
			+ "inner join ca_eol_products eol on eol.product_AliasName = inf.OS_Type\r\n"
			+ "inner join ca_eol_version_details elv on elv.product_ID = eol.product_ID and inf.OS_Version = elv.version";
	@Query(value = OSServerEOL, nativeQuery = true)
	public  List<Object[]>  getOSServerEOL();
	
	
	
	
	String SoftwareEOL = "select capp.App_Name, lob.Lob_Name, tec.Prog_Language, tec.Prog_Language_version, \r\n"
			+ " elv.support_dt, elv.eol_dt,\r\n"
			+ "Case \r\n"
			+ "    when TIMESTAMPDIFF(MONTH, CURDATE(), eol_dt) <=6 then \"High\" \r\n"
			+ "    when TIMESTAMPDIFF(MONTH, CURDATE(), eol_dt) >6 and TIMESTAMPDIFF(MONTH, CURDATE(), eol_dt) <=12 then \"Medium\" \r\n"
			+ "    else \"Low\" end as Criticality,\r\n"
			+ "Case \r\n"
			+ "    when elv.is_Active = 1 then \"Active\" \r\n"
			+ "    when elv.is_Active = 0 then \"End of Life\" \r\n"
			+ "    else \"\" end as isActive\r\n"
			+ "from ca_app_master capp \r\n"
			+ "inner join ca_lob_master lob on lob.LOB_Id = capp.LOB_Id\r\n"
			+ "inner join ca_appmaster_techstack tec on tec.App_Master_Id = capp.App_Master_Id\r\n"
			+ "inner join ca_eol_products eol on eol.product_AliasName = tec.Prog_Language\r\n"
			+ "inner join ca_eol_version_details elv on elv.product_ID = eol.product_ID and tec.Prog_Language_version = elv.version";
	@Query(value = SoftwareEOL, nativeQuery = true)
	public  List<Object[]>  getSoftwareEOL();
	
	String AppserverEOL = "select \r\n"
			+ "capp.App_Name,\r\n"
			+ "lob.Lob_Name, \r\n"
			+ "capp.AppServer_Type, \r\n"
			+ "capp.AppServer_Version, \r\n"
			+ "elv.support_dt, \r\n"
			+ "elv.eol_dt, \r\n"
			+ "Case when TIMESTAMPDIFF(MONTH, CURDATE(), eol_dt) <=12 then \"Critical\" when TIMESTAMPDIFF(MONTH, CURDATE(), eol_dt) >=12 then \"Medium\" else \"\" end as Critical,\r\n"
			+ "Case when elv.is_Active = 1 then \"Active\" when elv.is_Active = 0 then \"End of Life\" else \"\" end as isActive\r\n"
			+ "from ca_app_master capp \r\n"
			+ "inner join ca_lob_master lob on lob.LOB_Id = capp.LOB_Id\r\n"
			+ "inner join ca_eol_products eol on eol.product_AliasName = capp.AppServer_Type\r\n"
			+ "inner join ca_eol_version_details elv on elv.product_ID = eol.product_ID and capp.AppServer_Version = elv.version";
	@Query(value = AppserverEOL, nativeQuery = true)
	public  List<Object[]>  getApserverEOL();
	
	
	String WebServerEOL = "select \r\n"
			+ "capp.App_Name,\r\n"
			+ "lob.Lob_Name, \r\n"
			+ "capp.WebServer_Type, \r\n"
			+ "capp.WebServer_Version, \r\n"
			+ "elv.support_dt, \r\n"
			+ "elv.eol_dt, \r\n"
			+ "Case when TIMESTAMPDIFF(MONTH, CURDATE(), eol_dt) <=12 then \"Critical\" when TIMESTAMPDIFF(MONTH, CURDATE(), eol_dt) >=12 then \"Medium\" else \"\" end as Critical,\r\n"
			+ "Case when elv.is_Active = 1 then \"Active\" when elv.is_Active = 0 then \"End of Life\" else \"\" end as isActive\r\n"
			+ "from ca_app_master capp \r\n"
			+ "inner join ca_lob_master lob on lob.LOB_Id = capp.LOB_Id\r\n"
			+ "inner join ca_eol_products eol on eol.product_AliasName = capp.WebServer_Type\r\n"
			+ "inner join ca_eol_version_details elv on elv.product_ID = eol.product_ID and capp.WebServer_Version = elv.version";
	@Query(value = WebServerEOL, nativeQuery = true)
	public  List<Object[]> getWebServerEOL();
	
	
}
