package com.slk.dsl.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.slk.dsl.dto.CaRoiSurveyFinalDTO;
import com.slk.dsl.dto.EOLProgressBarDTO;
import com.slk.dsl.dto.ROIPogressBarDto;
import com.slk.dsl.services.CaRoiSurveyServices;
import com.slk.dsl.services.EOLService;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class CaRoiSurveyController {
	@Autowired
	CaRoiSurveyServices service;
	
	@GetMapping("getCaRoiSurveyList")  
	public List<CaRoiSurveyFinalDTO> CaRoiSurvey() {
		return service.getCaRoiSurvey();
	}
	@GetMapping("ROIProgressBar/{orgId}")  
	public List<ROIPogressBarDto>ROIProgressBar(@PathVariable int orgId) {
		return service.getROIProgressBar(orgId);	
    }
	
}
