package com.slk.dsl.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class AppServerEOLDto {
	
	String App_Name ;
	String Lob_Name;
	String AppServer_Type;
	String AppServer_Version;
	public String getAppServer_Type() {
		return AppServer_Type;
	}
	public void setAppServer_Type(String appServer_Type) {
		AppServer_Type = appServer_Type;
	}
	public String getAppServer_Version() {
		return AppServer_Version;
	}
	public void setAppServer_Version(String appServer_Version) {
		AppServer_Version = appServer_Version;
	}
	public String getApp_Name() {
		return App_Name;
	}
	public void setApp_Name(String app_Name) {
		App_Name = app_Name;
	}
	public String getLob_Name() {
		return Lob_Name;
	}
	public void setLob_Name(String lob_Name) {
		Lob_Name = lob_Name;
	}
	
	public Date getSupport_dt() {
		return support_dt;
	}
	public void setSupport_dt(Date support_dt) {
		this.support_dt = support_dt;
	}
	public Date getEol_dt() {
		return eol_dt;
	}
	public void setEol_dt(Date eol_dt) {
		this.eol_dt = eol_dt;
	}
	public String getCritical() {
		return Critical;
	}
	public void setCritical(String critical) {
		Critical = critical;
	}
	@JsonFormat(pattern="yyyy-MM-dd")
	Date support_dt;
	@JsonFormat(pattern="yyyy-MM-dd")
	Date eol_dt;
	String Critical;

}
