package com.slk.dsl.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class DatabaseEOLDTO {
	String App_Name ;
	String Lob_Name;
	String Database_Type;
	String Database_Version;
	public String getApp_Name() {
		return App_Name;
	}
	public void setApp_Name(String app_Name) {
		App_Name = app_Name;
	}
	public String getLob_Name() {
		return Lob_Name;
	}
	public void setLob_Name(String lob_Name) {
		Lob_Name = lob_Name;
	}
	public String getDatabase_Type() {
		return Database_Type;
	}
	public void setDatabase_Type(String database_Type) {
		Database_Type = database_Type;
	}

	public String getDatabase_Version() {
		return Database_Version;
	}
	public void setDatabase_Version(String database_Version) {
		Database_Version = database_Version;
	}


	public String getCritical() {
		return Critical;
	}
	public void setCritical(String critical) {
		Critical = critical;
	}
	@JsonFormat(pattern="yyyy-MM-dd")
	Date support_dt;
	
	 public Date getSupport_dt() {
		return support_dt;
	}
	public void setSupport_dt(Date support_dt) {
		this.support_dt = support_dt;
	}
	public Date getEol_dt() {
		return eol_dt;
	}
	public void setEol_dt(Date eol_dt) {
		this.eol_dt = eol_dt;
	}
	@JsonFormat(pattern="yyyy-MM-dd")
	Date eol_dt;
	String Critical;
	
}
