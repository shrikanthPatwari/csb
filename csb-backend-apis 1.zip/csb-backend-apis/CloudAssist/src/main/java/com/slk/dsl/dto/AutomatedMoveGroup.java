package com.slk.dsl.dto;



public class AutomatedMoveGroup {
int appMasterId;
int appMasterDependentId;
String app_Complexity;
String rLane_Strategy;
String dependent_App_Complexity;
public int getAppMasterId() {
    return appMasterId;
}
public void setAppMasterId(int appMasterId) {
    this.appMasterId = appMasterId;
}
public int getAppMasterDependentId() {
    return appMasterDependentId;
}
public void setAppMasterDependentId(int appMasterDependentId) {
    this.appMasterDependentId = appMasterDependentId;
}
public String getApp_Complexity() {
    return app_Complexity;
}
public void setApp_Complexity(String app_Complexity) {
    this.app_Complexity = app_Complexity;
}
public String getrLane_Strategy() {
    return rLane_Strategy;
}
public void setrLane_Strategy(String rLane_Strategy) {
    this.rLane_Strategy = rLane_Strategy;
}
public String getDependent_App_Complexity() {
    return dependent_App_Complexity;
}
public void setDependent_App_Complexity(String dependent_App_Complexity) {
    this.dependent_App_Complexity = dependent_App_Complexity;
}




}