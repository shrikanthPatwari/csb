package com.slk.dsl.controller;

import java.io.IOException;
import java.io.OutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.slk.dsl.dto.Chat2cloudDTO;
import com.slk.dsl.dto.ChatbotSurveyResponse;
import com.slk.dsl.dto.MessageAppDTO;
import com.slk.dsl.dto.UserAndOrgDetailsDTO;
import com.slk.dsl.model.Application;
import com.slk.dsl.model.DecisionUser;
import com.slk.dsl.services.DecisionUserService;
import freemarker.template.Configuration;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class DecisionUserController {

	@Autowired
	DecisionUserService service;
	
	@Autowired
	private Configuration config;

	@RequestMapping(value = "/checkEmail", method = RequestMethod.POST)
	public ResponseEntity<?> checkEmail(@RequestBody DecisionUser userDetails) throws Exception {
		return new ResponseEntity<Object>(service.checkEmail(userDetails), HttpStatus.OK);
	}
	
	
	@RequestMapping(value ="/chatbotAppSurveyResponse/{orgId}", method = RequestMethod.POST) 
	public int AppPostQuestion(@RequestBody List<ChatbotSurveyResponse> list,@PathVariable int orgId ) throws IOException{  
         return service.AppPostQuestioner(list,orgId);
   }
	
	@RequestMapping(value ="/saveResponse/{orgId}", method = RequestMethod.POST) 
	public int AppPostQuestion1(@RequestBody Chat2cloudDTO list,@PathVariable int orgId ) throws IOException{
         return service.AppPostQuestioner1(list,orgId);
   }
    
    @GetMapping("/pdf/{appId}")
    public  void generatePdf(HttpServletResponse response,OutputStream outputStream,@PathVariable int appId) throws IOException  {
    	    DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
            String currentDateTime = dateFormatter.format(new Date());         
            String headerKey = "Content-Disposition";
            String headerValue = "attachment; filename=surveyResponse_" + currentDateTime + ".pdf";
            response.setHeader(headerKey, headerValue);  
            service.generatePdf(response,outputStream,appId);
//			Template t = config.getTemplate("demo.ftl");
//			String k = FreeMarkerTemplateUtils.processTemplateIntoString(t,null);
//			HtmlConverter.convertToPdf(k, outputStream);           

    }

	@RequestMapping(value = "/saveUserAndOrg", method = RequestMethod.POST)
	public MessageAppDTO saveUserAndOrg(@RequestBody UserAndOrgDetailsDTO userOrg){
    return service.saveUserAndOrg(userOrg);
	}
	
	@PostMapping("/saveChatApp/{orgId}")
	public int saveChatApp(@RequestBody Application appData,@PathVariable int orgId) {
		return service.saveChatApp(appData,orgId);
	}
	
	@RequestMapping(value ="/saveChatResponse/{orgId}", method = RequestMethod.POST) 
	public int saveChatResponse(@RequestBody ChatbotSurveyResponse list,@PathVariable int orgId ) throws IOException{  
         return service.saveChatResponse(list,orgId);
   }
	
	@RequestMapping(value ="/sendChatEmail/{orgId}", method = RequestMethod.POST) 
	public String sendChatEmail(@RequestBody ChatbotSurveyResponse list,@PathVariable int orgId ) throws IOException{  
         return service.sendChatEmail(list,orgId);
   }
}
