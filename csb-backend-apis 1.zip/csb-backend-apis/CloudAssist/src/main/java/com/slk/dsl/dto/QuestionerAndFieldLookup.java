package com.slk.dsl.dto;

public class QuestionerAndFieldLookup {

	
	private Object Field_Name;
	
	private String Field_AliasName;
	
	private String Questioner;

	public Object getField_Name() {
		return Field_Name;
	}

	public void setField_Name(Object Field_Name) {
		this.Field_Name = Field_Name;
	}

	public String getField_AliasName() {
		return Field_AliasName;
	}

	public void setField_AliasName(String Field_AliasName) {
		this.Field_AliasName = Field_AliasName;
	}

	public String getQuestioner() {
		return Questioner;
	}

	public void setQuestioner(String Questioner) {
		this.Questioner = Questioner;
	}
	
	
}
