package com.slk.dsl.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="ca_appmaster_techstack")
public class CaAppmasterTechstack {

	@Id @GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="Techstack_Id",nullable = false, unique = true)
	private int techstackId;
	
	@Column(name="App_Master_Id")
	private int appMasterId;

	@Column(name="Org_Id")
	private int orgId;
	 
	@Column(name="Prog_Language")
	private String progLanguage; 
	
	@Column(name="Prog_Language_version")
	private String progLanguageversion; 
	
	@Column(name="Rec_Ins_Dt")
	private Date recInsDt;
	
	@Column(name="Rec_Upd_Dt")
	private Date recUpdDt;

	public int getTechstackId() {
		return techstackId;
	}

	public void setTechstackId(int techstackId) {
		this.techstackId = techstackId;
	}

	public int getAppMasterId() {
		return appMasterId;
	}

	public void setAppMasterId(int appMasterId) {
		this.appMasterId = appMasterId;
	}

	public int getOrgId() {
		return orgId;
	}

	public void setOrgId(int orgId) {
		this.orgId = orgId;
	}

	public String getProgLanguage() {
		return progLanguage;
	}

	public void setProgLanguage(String progLanguage) {
		this.progLanguage = progLanguage;
	}

	public String getProgLanguageversion() {
		return progLanguageversion;
	}

	public void setProgLanguageversion(String progLanguageversion) {
		this.progLanguageversion = progLanguageversion;
	}

	public Date getRecInsDt() {
		return recInsDt;
	}

	public void setRecInsDt(Date recInsDt) {
		this.recInsDt = recInsDt;
	}

	public Date getRecUpdDt() {
		return recUpdDt;
	}

	public void setRecUpdDt(Date recUpdDt) {
		this.recUpdDt = recUpdDt;
	}

		
}
