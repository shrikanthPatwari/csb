# CloudAssist_SpringBoot
Backend code for cloudassist

**Build Status**

[![Build Status](https://dev.azure.com/sagarmalakannawar/DTL-Onesims/_apis/build/status/SpringCI?repoName=SLKDSL%2FSpringBoot_CSB_v2&branchName=release)](https://dev.azure.com/sagarmalakannawar/DTL-Onesims/_build/latest?definitionId=1&repoName=SLKDSL%2FSpringBoot_CSB_v2&branchName=release)

**Release status**

![Build Status](https://vsrm.dev.azure.com/sagarmalakannawar/_apis/public/Release/badge/80007c08-c434-4840-9365-b0241555fbce/3/7)
