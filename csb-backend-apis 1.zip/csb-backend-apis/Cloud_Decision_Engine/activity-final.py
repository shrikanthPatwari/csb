import pandas as pd
import numpy as np
import csv
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import category_encoders as ce
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score
from sklearn import tree
import matplotlib.pyplot as plt  # data visualization
import graphviz
from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report
from sklearn.metrics import f1_score
# from imblearn.over_sampling import SMOTE
# from imblearn.over_sampling import RandomOverSampler
import pickle
import mysql.connector


mysql_config = {
        'user': 'ipadmin',
        'password': 'DTSL@slk2022',
        'host': 'licenseportalsrv.mysql.database.azure.com',
        'database': 'csb_cloudassist',
        'port': '3306',
        'ssl_disabled': True
    }

try:
    mydb = mysql.connector.connect(**mysql_config)
except mysql.connector.Error as err:
    print("Something went wrong: {}".format(err))
    

# fetching Application and query responce from the DB
application_query = """SELECT 
        `ca_app_master`.`App_Id` AS `app_id`,
        `ca_app_master`.`App_Name` AS `App_Name`,
        `ca_app_survey_response`.`comments` AS `comments`,
        `ca_survey_questioner`.`question_description` AS `questiones`
    FROM
        ((`ca_app_master`
        JOIN `ca_app_survey_response` ON ((`ca_app_master`.`App_Id` = `ca_app_survey_response`.`app_Id`)))
        JOIN `ca_survey_questioner` ON ((`ca_survey_questioner`.`questioner_Id` = `ca_app_survey_response`.`questioner_Id`)))
    WHERE
        (`ca_survey_questioner`.`Org_App_QuestionType` = 2) and (`ca_app_master`.`RLane_Strategy_Id`<>0);


"""

application = pd.read_sql(application_query, mydb)
application = application.drop('App_Name', axis=1)


application = application.pivot_table(columns='questiones', index='app_id', values='comments',
                                      aggfunc=lambda x: ' '.join(x))
application = application.reset_index()

x = 0
for col in application.columns:
    application.rename(columns={col: col.replace(col, "Q" + str(x))}, inplace=True)
    x = x + 1

temp_columns = list(application.columns)
temp_columns[0] = 'App_ID'
application.columns = temp_columns


rlane_query = """SELECT 
        `ca_app_master`.`App_Id` AS `App_ID`,
        `ca_rlane_strategy_lookup`.`RLane_Strategy` AS `Target`
    FROM
        ((`ca_app_master`
        JOIN `ca_app_master_versioning` ON ((`ca_app_master`.`App_Id` = `ca_app_master_versioning`.`App_Id`)))
        JOIN `ca_rlane_strategy_lookup` ON ((`ca_rlane_strategy_lookup`.`RLane_Strategy_Id` = `ca_app_master`.`RLane_Strategy_Id`)))
    WHERE
        (`ca_rlane_strategy_lookup`.`Is_Active` = 1) and (`ca_app_master`.`RLane_Strategy_Id`<> 0);
"""

rlane = pd.read_sql(rlane_query, mydb)
r_lane_list = (list(rlane['Target']))
appId_list = (list(rlane['App_ID']))


result = pd.merge(application, rlane, on='App_ID')

f = result.drop(['Target', 'App_ID'], axis=1)
t = result['Target']


print('Shape of f: {}'.format(f.shape))
print('Shape of t: {}'.format(t.shape))


# split f and t into training and testing sets
# f_train, f_test, t_train, t_test = train_test_split(f, t, test_size=0.3, random_state=0)
f_train = f
f_test = f
t_test = t
t_train = t

# check the shape of f_train and f_test

print(f_train.shape, f_test.shape)


# encode variables with ordinal encoding
encoder = ce.OrdinalEncoder(f.columns)

f_train = encoder.fit_transform(f_train)
f_test = encoder.transform(f_test)

print("Number of transactions f_train dataset: ", f_train.shape)
print("Number of transactions t_train dataset: ", t_train.shape)
print("Number of transactions f_test dataset: ", f_test.shape)
print("Number of transactions t_test dataset: ", t_test.shape)


Retain_count = t_train.str.contains('Retain').sum()
print("Retain====", Retain_count)

RePlatform_count = t_train.str.contains('Replatform').sum()
print("RePlatform====", RePlatform_count)

ReArchitect_count = t_train.str.contains('Rearchitect').sum()
print("ReArchitect====", ReArchitect_count)

Rehost_count = t_train.str.contains('Rehost').sum()
print("Rehost====", Rehost_count)

ReBuild_count = t_train.str.contains('ReBuild').sum()
print("ReBuild====", ReBuild_count)

Replace_count = t_train.str.contains('Replace').sum()
print("Replace====", Replace_count)


# instantiate the DecisionTreeClassifier model with criterion gini index
clfn_gini = DecisionTreeClassifier(criterion='gini', max_depth=3, random_state=0)

# fit the model
clfn_gini.fit(f_train, t_train)

t_pred_gini = clfn_gini.predict(f_test)

# Compare the train-set and test-set accuracy
t_pred_train_gini = clfn_gini.predict(f_train)
t_pred_train_gini


# Check for overfitting and underfitting and print the scores on training and test set
print('Training set score: {:.4f}'.format(clfn_gini.score(f_train, t_train)))
print('Test set score: {:.4f}'.format(clfn_gini.score(f_test, t_test)))
# These two values are quite comparable. So, there is no sign of overfitting.



t_train1 = t_train.copy()
t_train1 = list(t_train1)

t_test1 = t_test.copy()
t_test1 = list(t_test1)

# print("t_train===>",len(t_train1),t_train1)
# print("t_pred_gini===>",len(t_pred_gini),t_pred_gini)
print("f1_score(t_train, t_pred_train_gini)====>", f1_score(t_train1, t_pred_train_gini, average='macro'))
print("f1_score(t_test, t_pred_train_gini)====>", f1_score(t_test1, t_pred_gini, average='macro'))


# Save the Model to file in the current working directory
Pkl_Filename = r"Decision_Engine.pkl"
with open(Pkl_Filename, 'wb') as file:
    pickle.dump(clfn_gini, file)
    
# Visualize decision-trees
plt.figure(figsize=(12, 8))
tree.plot_tree(clfn_gini.fit(f_train, t_train))


# Print the Confusion Matrix and slice it into four pieces
cm = confusion_matrix(t_test, t_pred_gini)
print('Confusion matrix\n\n', cm)
print(classification_report(t_test, t_pred_gini))
clfn_gini.predict(f_test.head(1))


# creating headder for result.csv file
ls_R_lanes_header = ['Applications'] + r_lane_list
ls_application_name = list(application.columns)[1:]
print(*ls_application_name)


# creating csv file of result.csv
with open(r'result.csv', 'w', newline='') as file:
    w = csv.writer(file)
    w.writerow(ls_R_lanes_header)
    
df_result = pd.read_csv(r'result.csv')
df_result.Applications = ls_application_name
df_result = df_result.set_index('Applications')
df_result.to_csv(r'result.csv')




# for updation in database


ssum = 0
flag = 0

rlane_query = "SELECT RLane_Strategy FROM ca_rlane_strategy_lookup where Is_Active=1;"
rlane = pd.read_sql(rlane_query, mydb)
r_lane_list = (list(rlane['RLane_Strategy']))
r_lane_list.remove('ReBuild')

found = 0

for app_no in application['App_ID'].unique():#ls_application_name:

    found = 0
    print("<--------------Application ", app_no, '--------------->')
    for r_lane in r_lane_list:
        
        print("<--------------", r_lane, '--------------->')
      

        if (flag == 0):
            df_result.at[(app_no), r_lane] = 1
            if (r_lane == 'Retain' or r_lane == 'Replace'):
                found += 1

            if (found == 2):
                found = 0
                r_lane = 'Retain'
                mycursor = mydb.cursor()
                rlane_query = "UPDATE `ca_app_master` SET `Comments` ='Currently application will be Retained but in future it would be considered for Replace' WHERE (`App_Id` = '" + str(
                    app_no) + "'); "
                mycursor.execute(rlane_query)

                mydb.commit()

            rlane_query = "SELECT RLane_Strategy_Id FROM ca_rlane_strategy_lookup where RLane_Strategy='" + r_lane + "';"
            rlane = pd.read_sql(rlane_query, mydb)
            rlaneId = rlane.loc[0, 'RLane_Strategy_Id']
            print(rlaneId)

            mycursor = mydb.cursor()
            rlane_query = "UPDATE `ca_app_master` SET `RLane_Strategy_Id` ='" + str(
                rlaneId) + "' WHERE (`App_Id` = '" + str(app_no) + "'); "
            mycursor.execute(rlane_query)
            print("" + str(r_lane))

            mydb.commit()


        else:
            df_result.at[app_no, r_lane] = 0
            print("not", r_lane)

df_result.to_csv(r'result.csv') 