import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app-to-lob-mapping',
  templateUrl: './app-to-lob-mapping.component.html',
  styleUrls: ['./app-to-lob-mapping.component.css']
})
export class AppToLobMappingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
