import { Injectable, } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { IdleService } from './service/idle-timeout/idle.service';

@Injectable({
  providedIn: 'root'
})
export class IdleTimoutGuard implements CanActivate {
  constructor(private idleService: IdleService) { }
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    this.idleService.startIdleTimer(900); //  seconds
    return true;
  }
}
