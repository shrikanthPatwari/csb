import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MoveGroupChartPopUpComponent } from './move-group-chart-pop-up.component';

describe('MoveGroupChartPopUpComponent', () => {
  let component: MoveGroupChartPopUpComponent;
  let fixture: ComponentFixture<MoveGroupChartPopUpComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MoveGroupChartPopUpComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MoveGroupChartPopUpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
