import { Component, OnInit, Inject } from '@angular/core';
import { HTTPService } from '../service/httpService.service';
import { Router } from '@angular/router';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import * as pageText from 'src/app/move-group-chart-pop-up/constants/move-group-chart.json';

@Component({
  selector: 'app-move-group-chart-pop-up',
  templateUrl: './move-group-chart-pop-up.component.html',
  styleUrls: ['./move-group-chart-pop-up.component.css']
})
export class MoveGroupChartPopUpComponent implements OnInit {
  pageText=(pageText as any).default; 
  constructor(private http: HTTPService,private router: Router,
    public dialogRef: MatDialogRef<MoveGroupChartPopUpComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private _snackBar: MatSnackBar) { }

chartvalue:any;
title:any;
Applicationcriticalitydata=false;
Datacriticalitydata=false;
piechartname:any;

  ngOnInit(): void {
    window.scrollTo(0, 0);
    this.piechartname=this.data.piechartname
    this.chartvalue=this.data.dataKey
    this.title=this.data.title

  }


  cancel(){
   

      this.dialogRef.close(false);
    }


}
