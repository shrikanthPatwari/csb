import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { AddOrganizationComponent } from '../add-organization/add-organization.component';
import { DeleteOrganizationComponent } from '../delete-organization/delete-organization.component';
import { Organization } from '../model/organization';
import { HTTPService } from '../service/httpService.service';
import { UpdateOrganizationComponent } from '../update-organization/update-organization.component';

@Component({
  selector: 'app-list-organization',
  templateUrl: './list-organization.component.html',
  styleUrls: ['./list-organization.component.css']
})
export class ListOrganizationComponent implements OnInit {

  orgList: Organization[];
  errorMsg: string;
  pageOfItems: Array<any>;
  page: number = 1;

  constructor(private Orgservice: HTTPService,
    public dialog: MatDialog,
    private router: Router,
    private _snackBar: MatSnackBar

  ) { }

  ngOnInit(): void {
    this.loadOrglist();
  }


  loadOrglist() {
    this.orgList = [];
    this.Orgservice.getorgList().subscribe(
      data => {

        this.orgList = data;

        console.log(this.orgList, "orglistttttttttttttttttttttt");
      },
      error => {
        this.errorMsg = "Some error"
      })
  }

  addOrg() {
    let dialogref = this.dialog.open(AddOrganizationComponent, {
      height: '95%',
      width: '40%'

    });

    dialogref.afterClosed().subscribe(data => {
      this.loadOrglist();
    })
  }

  onChangePage(pageOfItems: Array<any>) {
    this.pageOfItems = pageOfItems;
  }
  updateOrg(organization) {
    let dialogref = this.dialog.open(UpdateOrganizationComponent, {
      height: '95%',
      width: '40%',
      data: {
        Organization: organization
      }

    });

    dialogref.afterClosed().subscribe(data => {
      this.loadOrglist();
    })
  }

  deleteOrg(id: number) {
    let dialogRef = this.dialog.open(DeleteOrganizationComponent, {
      height: '28%',
      width: '28%',
      data: {
        Organization: 'Organization'
      }
    });
    dialogRef.afterClosed().subscribe((result) => {
      let selectedOption = result;
      if (selectedOption == 'true') {

        this.Orgservice.deleteOrg(id).subscribe(
          data => {
            if(data=="could not execute statement; SQL [n/a]; constraint [null]; nested exception is org.hibernate.exception.ConstraintViolationException: could not execute statement"){
              this._snackBar.open('Cannot delete the organization', 'X');
            }
            else{
              this._snackBar.open('Organization deleted Successfully', 'X');}
            this.router.navigate(['/listOrg']);         
          },
          error => {
            this._snackBar.open('Please try after sometime', 'X');
          }, () => {
            this.loadOrglist();
          }
        )

      }
    })
  }
}