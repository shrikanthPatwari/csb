import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


import { RootNavComponent } from './root-nav/root-nav.component';
// import { OrgComponent } from './org/org.component';
import { AddUserComponent } from './Usersetup/add-user/add-user.component'

import { EditUserComponent } from './Usersetup/edit-user/edit-user.component';


import { ListUserComponent } from './Usersetup/list-user/list-user.component';
import { AddOrgComponent } from './Org_setup/add-org/add-org.component';
import { EditOrgComponent } from './Org_setup/edit-org/edit-org.component';
import { ListOrgComponent } from './Org_setup/list-org/list-org.component';






import { SetupComponent } from './setup/setup.component';
import { DevelopmentComponent } from './development/development.component';
import { ExportExcelComponent } from './export-excel/export-excel.component';
import { AprHeaderComponent } from './apr-header/apr-header.component';


import { AdminComponent } from './admin/admin.component';
import { CaptureInformationComponent } from './admin/capture-information/capture-information.component';
import { UploadFilesCloudComponent } from './admin/capture-information/upload-files-cloud/upload-files-cloud.component';
import { SubmitCloudComponent } from './admin/capture-information/submit-cloud/submit-cloud.component';

import { SubmitFilesAprComponent } from './admin/capture-information/submit-files-apr/submit-files-apr.component';





import { ApplicationQuestionerComponent } from './application-questioner/application-questioner.component';
import { LoginNewComponent } from './login-new/login-new.component';



import { InfraDiscoveryComponent } from './infra-discovery/infra-discovery.component';
import { UploadFilesNewScreenComponent } from './admin/capture-information/upload-files-new-screen/upload-files-new-screen.component';
import { ApplicationDiscoveryComponent } from './application-discovery/application-discovery.component';
import { CsbDashboardComponent } from './csb-dashboard/csb-dashboard.component';
import { OverrideRlaneComponent } from './override-rlane/override-rlane.component';
import { DiscoveryToolConfigComponent } from './dialog-reports/discovery-tool-config/discovery-tool-config.component';

import { AprDashboardComponent } from './apr-dashboard/apr-dashboard.component';

import { MaintainAprComponent } from './maintain-apr/maintain-apr.component';
import { CompareScreenComponent } from './compare-screen/compare-screen.component';
import { UploadFilesNewComponent } from './upload-files-new/upload-files-new.component';
import { UserCSBDashboardComponent } from './user-csb-dashboard/user-csb-dashboard.component';
import { AdminGuardGuard } from './service/admin-guard.guard';
import { LoginGuardGuard } from './login-guard.guard';
import { IdleTimoutGuard } from './idle-timout.guard';

import { UserRegistrationComponent } from './user-registration/user-registration.component';
import { UpdateUserComponent } from './update-user/update-user.component';
import { MoveGroupComponent } from './move-group/move-group.component';
import { ListLobComponent } from './LOB/list-lob/list-lob.component';
import { EOLComponent } from './eol/eol.component';
import { ROICalculatorComponent } from './roi-calculator/roi-calculator.component';
import { MaintainEOLComponent } from './maintain-eol/maintain-eol.component';
import { EOLVersionComponent } from './eolversion/eolversion.component';
import { OrganisationQuestionnaireComponent } from './organisation-questionnaire/organisation-questionnaire.component';
import { RlaneAnalysisComponent } from './rlane-analysis/rlane-analysis.component';
import { Neo4jComponent } from './neo4j/neo4j.component';
import { LandingComponent } from './landing/landing.component';
import { ListOrganizationComponent } from './list-organization/list-organization.component';
import { VersionsUpdateComponent } from './versions-update/versions-update.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';

const routes: Routes = [
  // {

  //   path: 'homePage', component: RootNavComponent,
  //   children: [

  //     {
  //       path: 'orgSetUp', component: ListOrgComponent,
  //       children: [
  //         { path: 'addorg', component: AddOrgComponent },
  //         { path: 'editorg', component: EditOrgComponent },
  //         { path: 'editorg/:id', component: EditOrgComponent }

  //       ],
  //       canActivate: [AdminGuardGuard, LoginGuardGuard, IdleTimoutGuard]

  //     },
  //     { path: 'aprcloud', component: AprHeaderComponent },
  //     {
  //       path: 'setup', component: SetupComponent
  //     },
  //     { path: 'development', component: DevelopmentComponent },
  //     { path: 'export', component: ExportExcelComponent },

  //     {
  //       path: "uploadcloud",
  //       component: UploadFilesCloudComponent
  //     },

  //     {
  //       path: "submitcloud",
  //       component: SubmitCloudComponent
  //     },

  //     {
  //       path: "submitapr",
  //       component: SubmitFilesAprComponent
  //     },

  //     {
  //       path: "admin",
  //       component: AdminComponent,
  //       // children:[
  //       //   { path: 'capture', component: CaptureInformationComponent }
  //       // ]
  //     },



  //     {
  //       path: "capture",
  //       component: CaptureInformationComponent
  //     },

  //   ]
  // },


  {
    path: 'landing',
    component: LandingComponent,
    canActivate: [AdminGuardGuard, LoginGuardGuard, IdleTimoutGuard],
  },
  {
    path: "fileupload",
    component: UploadFilesNewScreenComponent
  },
  {
    path: "CsbDashboard",
    component: CsbDashboardComponent, canActivate: [LoginGuardGuard, IdleTimoutGuard],
  },
  {
    path: "appdiscovery",
    component: ApplicationDiscoveryComponent,
    canActivate: [LoginGuardGuard, IdleTimoutGuard],
  },
  {
    path: "override",
    component: OverrideRlaneComponent,
    canActivate: [LoginGuardGuard, AdminGuardGuard, IdleTimoutGuard]
  },
  {
    path: "OrgQuestionnaire",
    component: OrganisationQuestionnaireComponent,
    canActivate: [LoginGuardGuard, IdleTimoutGuard],
  },
  {
    path: "appque",
    component: ApplicationQuestionerComponent,
    canActivate: [LoginGuardGuard, IdleTimoutGuard],
  },
  {
    path: "discoveryconfig",
    component: DiscoveryToolConfigComponent
  },

  {
    path: "csbReport",
    component: RlaneAnalysisComponent,
    canActivate: [LoginGuardGuard, AdminGuardGuard, IdleTimoutGuard]
  },

  {
    path: "infra",
    component: InfraDiscoveryComponent,
    canActivate: [LoginGuardGuard, AdminGuardGuard, IdleTimoutGuard]
  },

  {
    path: "AprDashboard",
    component: AprDashboardComponent,
    canActivate: [AdminGuardGuard, LoginGuardGuard, IdleTimoutGuard],
  },

  {
    path: "neo4j",
    component: Neo4jComponent,
    canActivate: [LoginGuardGuard, AdminGuardGuard, IdleTimoutGuard]
  },


  {
    path: "maintainapr",
    component: MaintainAprComponent,
    canActivate: [LoginGuardGuard, AdminGuardGuard, IdleTimoutGuard]
  },


  {
    path: "datacomparsion",
    component: CompareScreenComponent,
    canActivate: [LoginGuardGuard, AdminGuardGuard, IdleTimoutGuard]
  },
  {
    path: "uploadfilesnew",
    component: UploadFilesNewComponent,
    canActivate: [LoginGuardGuard, AdminGuardGuard, IdleTimoutGuard]
  },
  {
    path: "userdashboard",
    component: UserCSBDashboardComponent,
    canActivate: [LoginGuardGuard, IdleTimoutGuard],
  },

  {
    path: "userSetup", component: ListUserComponent,
    children: [
      { path: 'adduser', component: AddUserComponent },
      { path: 'edituser', component: EditUserComponent },
      { path: 'edituser/:id', component: EditUserComponent }

    ],
    canActivate: [AdminGuardGuard, LoginGuardGuard, IdleTimoutGuard],
  },

  {
    path: '',
    component: LoginNewComponent
  },
  {
    path: 'signup',
    component: SignUpComponent
  },
  {
    path: 'forgot',
    component: ForgotPasswordComponent
  },

  {
    path: '**',
    redirectTo: 'orgsetup',
    pathMatch: 'full'
  },

  {
    path: "userRegistration",
    component: UserRegistrationComponent,

  },

  {
    path: "updateUser/:id",
    component: UpdateUserComponent
  },

  {
    path: "moveGroup",
    component: MoveGroupComponent,
    canActivate: [LoginGuardGuard, AdminGuardGuard, IdleTimoutGuard]
  },

  {
    path: "EOL",
    component: EOLComponent,
    canActivate: [LoginGuardGuard, IdleTimoutGuard]
  },
  {
    path: "ROI",
    component: ROICalculatorComponent,
    canActivate: [LoginGuardGuard, AdminGuardGuard, IdleTimoutGuard],
  },

  {
    path: "MaintainEOL",
    component: MaintainEOLComponent,
    canActivate: [LoginGuardGuard, IdleTimoutGuard, AdminGuardGuard],
  },

  {
    path: "EOLVersions/:id",
    component: EOLVersionComponent
  },

  {
    path: "listOrg",
    component: ListOrganizationComponent,
    canActivate: [LoginGuardGuard, AdminGuardGuard, IdleTimoutGuard]
  },
  {
    path: "loBsetup",
    component: ListLobComponent,
    canActivate: [LoginGuardGuard, AdminGuardGuard, IdleTimoutGuard]

  },

  {
    path: "versionsUpdate",
    component: VersionsUpdateComponent,
    canActivate: [LoginGuardGuard, IdleTimoutGuard]
  }
];


@NgModule({
  imports: [RouterModule.forRoot(routes, {
    onSameUrlNavigation: 'reload',
    useHash: true
  }
  )],
  exports: [RouterModule]
})
export class AppRoutingModule { }
