import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteEOLProductComponent } from './delete-eolproduct.component';

describe('DeleteEOLProductComponent', () => {
  let component: DeleteEOLProductComponent;
  let fixture: ComponentFixture<DeleteEOLProductComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeleteEOLProductComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteEOLProductComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
