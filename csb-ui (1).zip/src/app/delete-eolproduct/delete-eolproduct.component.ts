import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-delete-eolproduct',
  templateUrl: './delete-eolproduct.component.html',
  styleUrls: ['./delete-eolproduct.component.css']
})
export class DeleteEOLProductComponent implements OnInit {

  productVersion: any;
  constructor(@Inject(MAT_DIALOG_DATA) public data:DeleteEOLProductComponent) { }

  ngOnInit(): void {
    //this.productVersion = this.data.Product;
  }


}
