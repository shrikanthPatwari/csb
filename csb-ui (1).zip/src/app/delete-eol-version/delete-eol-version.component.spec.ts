import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteEolVersionComponent } from './delete-eol-version.component';

describe('DeleteEolVersionComponent', () => {
  let component: DeleteEolVersionComponent;
  let fixture: ComponentFixture<DeleteEolVersionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeleteEolVersionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteEolVersionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
