import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-eol-version',
  templateUrl: './delete-eol-version.component.html',
  styleUrls: ['./delete-eol-version.component.css']
})
export class DeleteEolVersionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
