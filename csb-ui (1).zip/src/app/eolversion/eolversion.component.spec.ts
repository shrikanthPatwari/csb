import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EOLVersionComponent } from './eolversion.component';

describe('EOLVersionComponent', () => {
  let component: EOLVersionComponent;
  let fixture: ComponentFixture<EOLVersionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EOLVersionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EOLVersionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
