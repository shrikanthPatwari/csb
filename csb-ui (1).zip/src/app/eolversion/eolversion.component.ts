import { Component, OnInit } from '@angular/core';
import { HTTPService } from '../service/httpService.service';
import { ActivatedRoute, Router } from '@angular/router';
import { AddEolVersionComponent } from '../add-eol-version/add-eol-version.component';
import { MatDialog } from '@angular/material/dialog';
import { DeleteEOLProductComponent } from '../delete-eolproduct/delete-eolproduct.component';
import { MatSnackBar } from '@angular/material/snack-bar';
import { UpdateEolVersionComponent } from '../update-eol-version/update-eol-version.component';
import { DeleteEolVersionComponent } from '../delete-eol-version/delete-eol-version.component';
import * as pageText from 'src/app/eolversion/constants/eol-version.json';
@Component({
  selector: 'app-eolversion',
  templateUrl: './eolversion.component.html',
  styleUrls: ['./eolversion.component.css']
})
export class EOLVersionComponent implements OnInit {
  pageText=(pageText as any).default;
  searchText;
  productName: any;
  newVersionList = [];
  isActive = [];
  productid: any;
  search: string;
  versionList: any;
  page: number = 1;
  constructor(private Service: HTTPService, private activatedRoute: ActivatedRoute,
    public dialog: MatDialog, private router: Router, private _snackBar: MatSnackBar) { }

  ngOnInit(): void {
    this.loadVersionList();

  }

  loadVersionList() {
    this.productid = this.activatedRoute.snapshot.params.id;
    this.Service.getEolVersionList(this.productid).subscribe(data => {
      this.versionList = data;
      this.versionList.map((m) => {
        this.productName = m.product_Name;
      })
      this.versionList.map((m) => {
        let obj = { version: '', releaseDate: '', endOfSupport: '', endOfLife: '', isActive: '', versionId: '', productId: '' }
        obj.version = m.version;
        obj.releaseDate = m.release_dt;
        obj.endOfSupport = m.support_dt;
        obj.endOfLife = m.eol_dt;
        if (m.is_Active == 1) {
          obj.isActive = "Yes"

        }
        else {
          obj.isActive = "No"
        }
        obj.versionId = m.version_ID;
        obj.productId = m.product_ID;
        this.newVersionList.push(obj);

      });
    });
  }

  addVersion() {
    let dialogRef = this.dialog.open(AddEolVersionComponent, {
      height: '500px',
      width: '560px',
      data: {
        id: this.productid
      }

    });
    dialogRef.afterClosed().subscribe(data => {
      this.newVersionList = [];
      this.loadVersionList();
    })
  }

  navigate() {
    this.router.navigate(['/MaintainEOL']);
  }

  deleteVersion(id) {
    let dialogRef = this.dialog.open(DeleteEolVersionComponent, {
      height: '28%',
      width: '28%',
    });


    dialogRef.afterClosed().subscribe((result) => {
      let selectedOption = result;
      if (selectedOption == 'true') {
        this.Service.deleteVersion(id).subscribe(data => {

          this._snackBar.open('Version deleted Successfully', 'X');
        },
          error => {
            this._snackBar.open('Please try after sometime', 'X');
          }, () => {

            this.loadVersionList()
          })
      }
    })
  }
  updateVersion(version) {
    let dialogref = this.dialog.open(UpdateEolVersionComponent, {
      height: '500px',
      width: '560px',
      data: {
        versionDetails: version
      }
    });

    dialogref.afterClosed().subscribe(data => {
      this.newVersionList = [];
      this.loadVersionList();
    })
  }
}
