import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-delete-organization',
  templateUrl: './delete-organization.component.html',
  styleUrls: ['./delete-organization.component.css']
})
export class DeleteOrganizationComponent implements OnInit {
  Organization: any;
 
  constructor(@Inject(MAT_DIALOG_DATA) public data: DeleteOrganizationComponent) { }

  ngOnInit(): void {
   this.Organization=this.data.Organization;
  }

}
// applicationoruser:any;
//   ngOnInit(): void {
//     this.applicationoruser = this.data.applicationoruser;
//   }