import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-infra-app-upload',
  templateUrl: './infra-app-upload.component.html',
  styleUrls: ['./infra-app-upload.component.css']
})
export class InfraAppUploadComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
