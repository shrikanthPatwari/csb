import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { StoreModule } from '@ngrx/store';
import { NgxSpinnerModule } from 'ngx-spinner';

import { AppRoutingModule } from './app-routing.module';
import { MatCardModule } from '@angular/material/card';
import { AppComponent } from './app.component';

import { NgMaterialMultilevelMenuModule } from 'ng-material-multilevel-menu';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RootNavComponent } from './root-nav/root-nav.component';
import { LayoutModule } from '@angular/cdk/layout';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import {MatSelectModule} from '@angular/material/select';



import { GridModule } from '@progress/kendo-angular-grid';
import { AngularMaterialModule } from './angular-material.module';

import { ReactiveFormsModule,FormsModule } from '@angular/forms';

import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { JWThttpInterceptorService } from './service/jwthttp-interceptor.service';
import { HTTPService } from './service/httpService.service';
import { CommonModule } from '@angular/common';
import { OrgComponent } from './org/org.component';

import { NgxPaginationModule } from 'ngx-pagination';


import { HeaderComponent } from './header/header.component';
import { MatTooltipModule } from '@angular/material/tooltip';
import { ListUserComponent } from './Usersetup/list-user/list-user.component';
import { AddUserComponent } from './Usersetup/add-user/add-user.component';
import { EditUserComponent } from './Usersetup/edit-user/edit-user.component';
import { AddOrgComponent } from './Org_setup/add-org/add-org.component';
import { EditOrgComponent } from './Org_setup/edit-org/edit-org.component';
import { ListOrgComponent } from './Org_setup/list-org/list-org.component';


import { UniqueValuesPipe } from './pipes/unique-values.pipe';
import { DropdownLOBPipe } from './pipes/dropdown-lob.pipe';

import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatCheckboxModule } from '@angular/material/checkbox';


import { DropdownBusProc1Pipe } from './pipes/dropdown-busproc1.pipe';
//import { MDBBootstrapModule } from 'angular-bootstrap-md';



import { SetupComponent } from './setup/setup.component';

import { ExportExcelComponent } from './export-excel/export-excel.component';
import { AprHeaderComponent } from './apr-header/apr-header.component';

import { DevelopmentComponent } from './development/development.component';
import { AdminComponent } from './admin/admin.component';

import { CaptureInformationComponent } from './admin/capture-information/capture-information.component';

import { UploadFilesCloudComponent } from './admin/capture-information/upload-files-cloud/upload-files-cloud.component';
import { SubmitCloudComponent } from './admin/capture-information/submit-cloud/submit-cloud.component';
import { UploadFilesAprComponent } from './admin/capture-information/upload-files-apr/upload-files-apr.component';
import { SubmitFilesAprComponent } from './admin/capture-information/submit-files-apr/submit-files-apr.component';

import { FooterComponent } from './footer/footer.component';
import { NgxDropzoneModule } from 'ngx-dropzone';


import { DialogComponent } from './dialog/dialog.component';


import { ValuePipe } from './pipes/value.pipe';
import { SpinnerComponent } from './core-commonComponents/spinner/spinner.component';
import { ExcelService } from './service/excel-service.service';
import { DownloadPopupComponent } from './download-popup/download-popup.component';

import { UploadFilesNewComponent } from './upload-files-new/upload-files-new.component';
import {
  MatDialogModule,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
// import{ConfirmationDialogComponent} from './service/confirmation-dialog-component.service'
import { ConfirmationDialogbox } from './service/confirmation-dialogbox/confirmation-dialogbox.component';
import { MatConfirmDialogComponent } from './mat-confirm-dialog/mat-confirm-dialog.component';
 



import { ApplicationQuestionerComponent } from './application-questioner/application-questioner.component';
import { LoginNewComponent } from './login-new/login-new.component';

import { ApplicationPopupComponent } from './application-popup/application-popup.component';


import { NgCircleProgressModule } from 'ng-circle-progress';

import { UploadFilesNewScreenComponent } from './admin/capture-information/upload-files-new-screen/upload-files-new-screen.component';
import { InfraDiscoveryComponent } from './infra-discovery/infra-discovery.component';
import { FileUploadPopUpComponent } from './file-upload-pop-up/file-upload-pop-up.component';
import { ApplicationDiscoveryComponent } from './application-discovery/application-discovery.component';
import { CsbDashboardComponent } from './csb-dashboard/csb-dashboard.component';
import { DashboardPopupComponent } from './dialog-reports/dashboard-popup/dashboard-popup.component';
import { RlanereportPopupComponent } from './rlanereport-popup/rlanereport-popup.component';
import { OverrideRlaneComponent } from './override-rlane/override-rlane.component';
import { DiscoveryToolConfigComponent } from './dialog-reports/discovery-tool-config/discovery-tool-config.component';
import { DialogReportsComponent } from './dialog-reports/dialog-reports.component';
import { MatTabsModule } from '@angular/material/tabs';
import { DialogboxComponent } from './dialogbox/dialogbox.component';

import { MDBBootstrapModule } from 'angular-bootstrap-md';
import { NO_ERRORS_SCHEMA } from '@angular/compiler';
import { ChartPopupComponent } from './chart-popup/chart-popup.component';
import { InfraPopupComponent } from './infra-popup/infra-popup.component';
import { SearchFilterPipe } from './search-filter.pipe';
import { AprDashboardComponent } from './apr-dashboard/apr-dashboard.component';
import { HeaderAprComponent } from './header-apr/header-apr.component';
import { MaintainAprComponent } from './maintain-apr/maintain-apr.component';
import { AccordionModule } from '@syncfusion/ej2-angular-navigations';
import { CreateapplicationComponent } from './createapplication/createapplication.component';
import { DeleteapplicationPopupComponent } from './deleteapplication-popup/deleteapplication-popup.component';
import { CompareScreenComponent } from './compare-screen/compare-screen.component';
import { from } from 'rxjs';
import { UserCSBDashboardComponent } from './user-csb-dashboard/user-csb-dashboard.component';
import { UserRegistrationComponent } from './user-registration/user-registration.component';
import { UpdateUserComponent } from './update-user/update-user.component';
import { HeaderAdminComponent } from './header-admin/header-admin.component';
import { DelegateUserComponent } from './delegate-user/delegate-user.component';
import { MoveGroupComponent } from './move-group/move-group.component';
import { CreateMovegroupComponent } from './create-movegroup/create-movegroup.component';
import { MatExpansionModule} from '@angular/material/expansion';
import { UpdateMovegroupComponent } from './update-movegroup/update-movegroup.component';

import { AddOrganizationComponent } from './add-organization/add-organization.component';
import { UpdateOrganizationComponent } from './update-organization/update-organization.component';


import { HeaderCsbComponent } from './header-csb/header-csb.component';




import { EOLComponent } from './eol/eol.component';
import { ROICalculatorComponent } from './roi-calculator/roi-calculator.component';
import { MaintainEOLComponent } from './maintain-eol/maintain-eol.component';
import { AddProductComponent } from './add-product/add-product.component';
import { EOLVersionComponent } from './eolversion/eolversion.component';
import { AddEolVersionComponent } from './add-eol-version/add-eol-version.component';
import { DeleteEOLProductComponent } from './delete-eolproduct/delete-eolproduct.component';
import { UpdateEolVersionComponent } from './update-eol-version/update-eol-version.component';
import { UpdateEolProductComponent } from './update-eol-product/update-eol-product.component';
import { DeleteEolVersionComponent } from './delete-eol-version/delete-eol-version.component';
import { MoveGroupChartPopUpComponent } from './move-group-chart-pop-up/move-group-chart-pop-up.component';
import { EolFileUploadPopupComponent } from './eol-file-upload-popup/eol-file-upload-popup.component';
import { OrganisationQuestionnaireComponent } from './organisation-questionnaire/organisation-questionnaire.component';
import { RlaneAnalysisComponent } from './rlane-analysis/rlane-analysis.component';
import { Neo4jComponent } from './neo4j/neo4j.component';
import { LandingComponent } from './landing/landing.component';
import { ListOrganizationComponent } from './list-organization/list-organization.component';
import { DeleteOrganizationComponent } from './delete-organization/delete-organization.component';
import { ListLobComponent } from './LOB/list-lob/list-lob.component';
import { AddLobComponent } from './LOB/add-lob/add-lob.component';
import { DeleteLobComponent } from './delete-lob/delete-lob.component';
import { EditLobComponent } from './LOB/edit-lob/edit-lob.component';
import { VersionsUpdateComponent } from './versions-update/versions-update.component';
import { VersionMapPopupComponent } from './version-map-popup/version-map-popup.component';

import { CharacterDirective } from './user-registration/directives/character.directives';
import { SpecialCharacterEmailDirective } from './special-character-email.directive';
import { SignUpComponent } from './sign-up/sign-up.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';



@NgModule({
  declarations: [
    AppComponent,
    RootNavComponent,
    ConfirmationDialogbox,
    DevelopmentComponent,
    OrgComponent,
    HeaderComponent,
    ListUserComponent,
    AddUserComponent,
    EditUserComponent,
    AddOrgComponent,
    EditOrgComponent,
    ListOrgComponent,
    UniqueValuesPipe,
    DropdownLOBPipe,
    DropdownBusProc1Pipe,
    DropdownBusProc1Pipe,
    SetupComponent,
    ExportExcelComponent,
    AprHeaderComponent,
    AdminComponent,
    CaptureInformationComponent,
    UploadFilesCloudComponent,
    SubmitCloudComponent,
    UploadFilesAprComponent,
    SubmitFilesAprComponent,
    FooterComponent,
    DialogComponent,
    ValuePipe,
    SpinnerComponent,
    DownloadPopupComponent,
    MatConfirmDialogComponent,
    ApplicationQuestionerComponent,
    LoginNewComponent,
    ApplicationPopupComponent,
    UploadFilesNewScreenComponent,
    InfraDiscoveryComponent,
    FileUploadPopUpComponent,
    ApplicationDiscoveryComponent,
    CsbDashboardComponent,
    DashboardPopupComponent,
    RlanereportPopupComponent,
    OverrideRlaneComponent,
    DiscoveryToolConfigComponent,
    DialogReportsComponent,
    DialogboxComponent,
    ChartPopupComponent,
    InfraPopupComponent,
    SearchFilterPipe,
    AprDashboardComponent,
    HeaderAprComponent,
    MaintainAprComponent,
    CreateapplicationComponent,
    DeleteapplicationPopupComponent,
    CompareScreenComponent,
    UploadFilesNewComponent,
    UserCSBDashboardComponent,
    UserRegistrationComponent,
    UpdateUserComponent,
    HeaderAdminComponent,
    DelegateUserComponent,
    MoveGroupComponent,
    CreateMovegroupComponent,
    UpdateMovegroupComponent,

    AddOrganizationComponent,
    UpdateOrganizationComponent,

    HeaderCsbComponent,
    EOLComponent,
    

    ROICalculatorComponent,
    MaintainEOLComponent,
    

    AddProductComponent,
    

    EOLVersionComponent,
    

    AddEolVersionComponent,
    

    DeleteEOLProductComponent,
    
    UpdateEolVersionComponent,
    

    UpdateEolProductComponent,
    

    DeleteEolVersionComponent,
    

    MoveGroupChartPopUpComponent,
    

    EolFileUploadPopupComponent,
    

    OrganisationQuestionnaireComponent,
    

    RlaneAnalysisComponent,
    

    Neo4jComponent,
    

    LandingComponent,
    
    ListOrganizationComponent,
    

    DeleteOrganizationComponent,

    ListLobComponent,

    AddLobComponent,

    EditLobComponent,

    DeleteLobComponent,

    VersionsUpdateComponent,

    VersionMapPopupComponent,
    CharacterDirective,
    SpecialCharacterEmailDirective,
    SignUpComponent,
    ForgotPasswordComponent,
  ],
  imports: [
    CommonModule,
    MatSnackBarModule,
    MDBBootstrapModule.forRoot(),
    MatTooltipModule,
    NgxSpinnerModule,
    MatCardModule,
    NgxPaginationModule,
    NgMaterialMultilevelMenuModule,
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    LayoutModule,
    MatToolbarModule,
    MatButtonModule,
    MatSidenavModule,
    MatIconModule,
    MatListModule,
    AngularMaterialModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule,
    GridModule,
    MatTabsModule,
    MatSlideToggleModule,
    MatCheckboxModule,
    NgxDropzoneModule,
    MatDialogModule,
    AccordionModule,
    MatSelectModule,
    //MatExpansionModule,
    MatExpansionModule,
    NgCircleProgressModule.forRoot({}),
  ],

  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: JWThttpInterceptorService,
      multi: true,
    },
    { provide: MatDialogRef, useValue: {} },
    { provide: MAT_DIALOG_DATA, useValue: [] },
    HTTPService,
    MatSnackBar,
    ExcelService,
    
  ],
  bootstrap: [AppComponent],

  entryComponents: [
  
    DialogComponent,
    DownloadPopupComponent,
    ConfirmationDialogbox,
    DevelopmentComponent,
    MatConfirmDialogComponent,
    ApplicationPopupComponent,
    FileUploadPopUpComponent,
    DashboardPopupComponent,
    RlanereportPopupComponent,
    DialogReportsComponent,
    DialogboxComponent,
    ChartPopupComponent,
    InfraPopupComponent,
    CreateapplicationComponent,
    DeleteapplicationPopupComponent,
    DelegateUserComponent,
    CreateMovegroupComponent,
    UpdateMovegroupComponent,
    AddOrganizationComponent,
    UpdateOrganizationComponent,
    DeleteOrganizationComponent,

    AddProductComponent,
    AddEolVersionComponent,
    DeleteEOLProductComponent,
    UpdateEolVersionComponent,
    UpdateEolProductComponent,
    DeleteEolVersionComponent,
    MoveGroupChartPopUpComponent,
    EolFileUploadPopupComponent, 
    AddLobComponent,
    EditLobComponent,
    DeleteLobComponent,
    VersionMapPopupComponent

  ],
  //entryComponents:[LoginComponent,DialogComponent,DownloadPopupComponent,ConfirmationDialogbox,DevelopmentComponent, MatConfirmDialogComponent,ApplicationPopupComponent,]
})
export class AppModule {}
