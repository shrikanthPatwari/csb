import { InfraDiscovery } from './infra-discovery';

describe('InfraDiscovery', () => {
  it('should create an instance', () => {
    expect(new InfraDiscovery()).toBeTruthy();
  });
});
