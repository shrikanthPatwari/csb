import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header-admin',
  templateUrl: './header-admin.component.html',
  styleUrls: ['./header-admin.component.css']
})
export class HeaderAdminComponent implements OnInit {
  orgName:any;
  userDisplayName:any;
  name:any;
  userName:any;
  loggedIn:boolean=true;
  roleId: any;
  Name:any
  finalName:string;

  constructor(private router: Router) { }

  ngOnInit(): void {
    this.Name=sessionStorage.getItem("Name");
    this.roleId=sessionStorage.getItem("roleId");
    this.orgName=sessionStorage.getItem("OrgName");
    this.userDisplayName = sessionStorage.getItem('username');
    this.name  = this.userDisplayName .substring(0, this.userDisplayName .lastIndexOf("@"));
   this.userName=this.name.charAt(0).toUpperCase();
       
if(this.Name.split('').length>10){
  this.finalName =this.Name.substr(0,10)+"...";
 }
 else{
 this.finalName=this.Name;
 }
  }


  ManagerUser(){
    this.router.navigate(['userSetup']);
  }

  ManageOrganization(){
    this.router.navigate(['listOrg']);
  }
  landingpage(){
    this.router.navigate(['landing']);
  }
  logout(){
    this.router.navigate(['/']);
    sessionStorage.clear();
   }

   ManageLob(){
    this.router.navigate(['loBsetup']);
   }
   manageEol(){
    this.router.navigate(['MaintainEOL']);
   }
}
