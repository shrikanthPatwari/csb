import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-uploadfilesnewscreen',
  templateUrl: './uploadfilesnewscreen.component.html',
  styleUrls: ['./uploadfilesnewscreen.component.css']
})
export class UploadfilesnewscreenComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
