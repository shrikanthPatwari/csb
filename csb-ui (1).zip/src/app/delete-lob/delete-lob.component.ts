import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-delete-lob',
  templateUrl: './delete-lob.component.html',
  styleUrls: ['./delete-lob.component.css']
})
export class DeleteLobComponent implements OnInit {
  lob: any;
  LOB: any;

  constructor(@Inject(MAT_DIALOG_DATA) public data: DeleteLobComponent) { }

  ngOnInit(): void {
   this.LOB=this.data.lob;
  }

}
