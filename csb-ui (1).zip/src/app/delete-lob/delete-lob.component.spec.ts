import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteLobComponent } from './delete-lob.component';

describe('DeleteLobComponent', () => {
  let component: DeleteLobComponent;
  let fixture: ComponentFixture<DeleteLobComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeleteLobComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteLobComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
