import { Component, OnInit } from '@angular/core';
import { HTTPService } from '../service/httpService.service';
import * as pageText from 'src/app/eol/constants/eol-component.json';

@Component({
  selector: 'app-eol',
  templateUrl: './eol.component.html',
  styleUrls: ['./eol.component.css']
})
export class EOLComponent implements OnInit {
  pageText=(pageText as any).default;
  DatabaseEOLPercent: number;
  DatabaseEOsubtitle: string;
  EOLProgresslist:any;
  OsEOLPercent: number;
  OsEOLsubtitle: string;
  techstackEOLEOLPercent: number;
  techstackEOLEOLsubtitle: string;
  EOLDatabaselist:any;
  page: number = 1;
  viewtype: any;
  OS_ServerEOLlist: any;
  SoftwarEOLOLlist: any;
  AppServerEOLlist:any;
  WebServerEOL: any;
  constructor(private Service:HTTPService,) { }


  ngOnInit(): void {
    this.viewtype = 'Database';
    this.Service.EOLProgresslist().subscribe(
      data=>{
        this.EOLProgresslist=data;
        console.log(  this.EOLProgresslist,"check")

this.calculateDatabaseEOL();
this.calculateTechstackEOL();
this.calculateOsEOL();
  })
  this.Service.DatabaseEOLTable().subscribe(
    data=>{
  this.EOLDatabaselist=data;
  
})


this.Service.OS_ServerEOL().subscribe(
  data=>{
this.OS_ServerEOLlist=data;




})

this.Service.SoftwarEOL().subscribe(
  data=>{
this.SoftwarEOLOLlist=data;


})

this.Service.AppServerEOL().subscribe(
  data=>{
this.AppServerEOLlist=data;
console.log(this.AppServerEOLlist,"AppServerEOLlist")

})
this.Service.WebServerEOL().subscribe(
  data=>{
this.WebServerEOL=data;
console.log(this.WebServerEOL,"webServerEOLlist")

})
  }
  calculateDatabaseEOL(){
    this.DatabaseEOLPercent = (  this.EOLProgresslist.databaseEOLCount/  this.EOLProgresslist.databaseCount) * 100;
    this.DatabaseEOsubtitle = this.EOLProgresslist.databaseEOLCount + '/' + this.EOLProgresslist.databaseCount;
  }

  calculateOsEOL(){
    this.OsEOLPercent = (  this.EOLProgresslist.osEOLCount/  this.EOLProgresslist.osCount) * 100;
    this.OsEOLsubtitle = this.EOLProgresslist.osEOLCount + '/' + this.EOLProgresslist.osCount;
  }
  calculateTechstackEOL(){
    this.techstackEOLEOLPercent = (  this.EOLProgresslist.techstackEOLCount/  this.EOLProgresslist.techstackCount) * 100;
    this.techstackEOLEOLsubtitle = this.EOLProgresslist.techstackEOLCount + '/' + this.EOLProgresslist.techstackCount;
  }




}
