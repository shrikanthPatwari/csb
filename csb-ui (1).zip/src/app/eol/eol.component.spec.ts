import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EOLComponent } from './eol.component';

describe('EOLComponent', () => {
  let component: EOLComponent;
  let fixture: ComponentFixture<EOLComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EOLComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EOLComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
