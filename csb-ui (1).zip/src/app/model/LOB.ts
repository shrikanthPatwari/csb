export class LOB {
  
    orgId: string;
    lobName: string;
    lobManager: string;
    recInsDt:string;
    recUpdDt:string;
    lobId:number;
}