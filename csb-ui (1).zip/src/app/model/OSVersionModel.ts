export class OSVersion{
    mappedOSVersion:String;
    osType:String;
    osVersion:String;
}