export class movegroupmapping {
    moveGroupAppID: number;
    moveGroupID : number;
    appMasterId : number;
    recInsDT : string;
    recUpDT : string;
}

