export class user {

  roleId: String;
  userId: number;
  //  lobId:number;
  //emailId:string;
  emailAddress: string;
  password: string;
  firstName: string;
  lastName: string;
  recType: boolean;
  recInsDt: string;
  recUpdDt: string;
  orgId: String;
  productId:number;
  organization: string;

}