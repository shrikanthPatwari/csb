	 
     export class AppDependency {
    appName:string;
    appDependencyId:number;
    appMasterId:number;
     appMasterDependentId:number;
     orgId:number; 
    recInsDt:String;
     recUpdDt:String;
     }