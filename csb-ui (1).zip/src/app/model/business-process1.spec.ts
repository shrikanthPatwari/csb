import { BusinessProcess1 } from './business-process1';

describe('BusinessProcess1', () => {
  it('should create an instance', () => {
    expect(new BusinessProcess1()).toBeTruthy();
  });
});
