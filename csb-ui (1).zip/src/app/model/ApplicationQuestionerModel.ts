export class AppQuestioner{
    resp_Id =0;
    app_Id=0;
    questioner_Id:number=0;
    questioner_Lkp_Id:number=0;
    comments="";
    rec_Ins_Dt="";
    rec_Upd_Dt="";
  
    constructor(){
  
    }
  }
  