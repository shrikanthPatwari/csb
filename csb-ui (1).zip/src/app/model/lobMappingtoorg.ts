export class lobMappingtoorg{

    lobId:number;
    appId:number;
    recInsDt:string;
    recUpdDt:string;
    org:number;
    appCheck:boolean;
}