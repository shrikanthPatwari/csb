export interface CA_App_Master {

    Application_ID:number;
  
    appName:string;
   
      Application_Description:String;

      Application_Manager:String;
  
      Vendor_Name:String;
  
      Application_Criticality:String;
    
      Data_Criticality:String;
    
     
}