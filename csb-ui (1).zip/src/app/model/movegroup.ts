export class movegroup {
  moveGroupId :number;
  orgId : number;
  moveGroupName:string;
  migrationStartdt:string;
  migrationEnddt:string;
  recInsDt:string;
  recUpdDt:string;
  }