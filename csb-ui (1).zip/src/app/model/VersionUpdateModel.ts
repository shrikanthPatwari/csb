export class versionUpdateModel{
	databaseType:String;
	databaseVersion:String;
	//  ProductID :String;
	mappedDatabaseVersion:String;
	appServerType:String;
	appServerVersion:String;
	mappedAppServerVersion:String;
	mappedWebServerVersion:String;
	webServerType : String;
	webServerVersion:String;
	
}