export class FHNAppData {
   
  
    versionId:number;
    appId:string;
    appSystem:string;
    description:string;
    
    hoursofOp:string;

    dataCatApp:string;
    customerFacing:string;

   
  
    rta:string;
    rpo:string;
    rpa:string;
    vendorConfirmation:string;
   
    orgId: any;
    vendor:string;



}
