export class UploadResponse {
    progress: number;
    files: [];
    message:string;
}
