export class BusinessProcess1 {
    
    busproLevel1Id: number;
    busproLevel1Name: string;
    busproLevel1Desc:string;
    orgId:number;
    recInsDt:string;
    recUpdDt:string;
    

}