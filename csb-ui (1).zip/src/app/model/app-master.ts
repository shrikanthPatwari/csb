export class AppMaster {

  appName:string;
  appDesc:string;
  appId:number;
  orgId:number;
  lobdesc:string;
  apptype:string;

}
