export class Eolproductversion{
    versionId:number;
    productID:number;
    version:String;
    releasedt:String;
    supportdt:String;
    eoldt:String;
    isActive:number;
    recInsdt:String;
    recUpddt:String;

}