export class FHN_Application_Table{


    //   public fhnAppId:number;
    
    //   public Versionid:number;
    
        public  appId:String;
    
    
        public  appSystem:String;
    
    
        public  description:String;
    
    
        public  Vendor:String;
    
    
    
        public  lastUpdate:String;
    
    
        public  businessOwner:String;
    
    
        public  businessManager:String;
    
    
        public  businessManagerEmployeeID:String;
    
    
        public  eTDirector:String;
    
    
        public  eTDirectorEmployeeID:String;
    
    
    
        public  eTManager:String;
    
    
    
        public  eTManagerEmployeeID:String;
    
        public  eTPrimaryTechnical:String;
    
        public  eTPrimaryTechnicalEmployeeID:String;
    
    
        public  eTSecondaryTechnical:String;
    
        public  eTSecondaryTechnicalEmployeeID:String;
    
        public  systemAdmin:String;
    
    
    
        public  systemAdminEmployeeID:String;
    
    
        public  dRRelationshipManager:String;
    
    
        public  dRRelationshipManagerEmployeeID:String;
    
    
        public  lob:String;
    
        public  mainPlatform:String;
    
        public  networkExposure:String;
    
    
        public  scName:String;
    
    
        public  soxCritical:String;
    
    
        public  hoursofOp:String;
    
    
        public  dataCatApp:String;
    
    
        public  customerFacing:String;
    
    
        public  qualityScore:String;
    
    
        public  rto:String;
    
    
        public  domain:String;
    
    
        public  managerCertification:String;
    
    
        public  os:String;
    
    
        public  location:String;
    
    
        public  asp:String;
    
        public  dRExerciseResults:String;
    
    
        public  applicationDRPlan:String;
    
    
        public  dRExerciseDate:String;
    
    
        public  dRTier:String;
    
    
        public  dRPlanDate:String;
    
        public  rta:String;
    
    
        public  rpo:String;
    
        public  rpa:String;
    
        public  vendorConfirmation:String;
    
    /**
     *
     */
    constructor(
    
    
    
          appId:String,
    
    
          appSystem:String,
    
    
          description:String,
    
    
          Vendor:String,
    
    
    
          lastUpdate:String,
    
    
          businessOwner:String,
    
    
          businessManager:String,
    
    
          businessManagerEmployeeID:String,
    
    
          eTDirector:String,
    
    
          eTDirectorEmployeeID:String,
    
    
    
          eTManager:String,
    
    
    
          eTManagerEmployeeID:String,
    
          eTPrimaryTechnical:String,
    
          eTPrimaryTechnicalEmployeeID:String,
    
    
          eTSecondaryTechnical:String,
    
          eTSecondaryTechnicalEmployeeID:String,
    
          systemAdmin:String,
    
    
    
          systemAdminEmployeeID:String,
    
    
          dRRelationshipManager:String,
    
    
          dRRelationshipManagerEmployeeID:String,
    
    
          lob:String,
    
          mainPlatform:String,
    
          networkExposure:String,
    
    
          scName:String,
    
    
          soxCritical:String,
    
    
          hoursofOp:String,
    
    
          dataCatApp:String,
    
    
          customerFacing:String,
    
    
          qualityScore:String,
    
    
          rto:String,
    
    
          domain:String,
    
    
          managerCertification:String,
    
    
          os:String,
    
    
          location:String,
    
    
          asp:String,
    
          dRExerciseResults:String,
    
    
          applicationDRPlan:String,
    
    
          dRExerciseDate:String,
    
    
          dRTier:String,
    
    
          dRPlanDate:String,
    
          rta:String,
    
    
          rpo:String,
    
          rpa:String,
    
          vendorConfirmation:String,
    ) {
    
    
    //   this.fhnAppId = fhnAppId
    
    //   this.Versionid = Versionid
    
      this.appId=appId
    
    
      this.appSystem=appSystem
    
    
      this.description=description
    
    
      this.Vendor=Vendor
    
    
    
      this.lastUpdate=lastUpdate
    
    
      this.businessOwner=businessOwner
    
    
      this.businessManager=businessManager
    
    
      this.businessManagerEmployeeID=businessManagerEmployeeID
    
    
      this.eTDirector=eTDirector
    
    
      this.eTDirectorEmployeeID=eTDirectorEmployeeID
    
    
    
      this.eTManager=eTManager
    
    
    
      this.eTManagerEmployeeID=eTManagerEmployeeID
    
      this.eTPrimaryTechnical=eTPrimaryTechnical
    
      this.eTPrimaryTechnicalEmployeeID=eTPrimaryTechnicalEmployeeID
    
    
      this.eTSecondaryTechnical=eTSecondaryTechnical
    
      this.eTSecondaryTechnicalEmployeeID=eTSecondaryTechnicalEmployeeID
    
      this.systemAdmin=systemAdmin
    
    
    
      this.systemAdminEmployeeID=systemAdminEmployeeID
    
    
      this.dRRelationshipManager=dRRelationshipManager
    
    
      this.dRRelationshipManagerEmployeeID=dRRelationshipManagerEmployeeID
    
    
    this.  lob=lob
    
      this.mainPlatform=mainPlatform
    
      this.networkExposure=networkExposure
    
    
      this.scName=scName
    
    
      this.soxCritical=soxCritical
    
    
      this.hoursofOp=hoursofOp
    
    
      this.dataCatApp=dataCatApp
    
    
      this.customerFacing=customerFacing
    
    
      this.qualityScore=qualityScore
    
    
    this.  rto=rto
    
    
      this.domain=domain
    
    
      this.managerCertification=managerCertification
    
    
      this.os=os
    
    
      this.location=location
    
    
    this.  asp=asp
    
      this.dRExerciseResults=dRExerciseResults
    
    
      this.applicationDRPlan=applicationDRPlan
    
    
      this.dRExerciseDate=dRExerciseDate
    
    
      this.dRTier=dRTier
    
    
      this.dRPlanDate=dRPlanDate
    
    this.  rta=rta
    
    
    this.  rpo=rpo
    
    this.  rpa=rpa
    
      this.vendorConfirmation=vendorConfirmation
    
    }
    }
    