
export class ProgramVersion{
    progLanguage :String;
	mappedProgLanguageversion:String;
	progLanguageversion:String;
}