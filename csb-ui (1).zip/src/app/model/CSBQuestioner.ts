export class CSBQuestioner{
    questioner_Id:number=0;
    questioner:string="";
    questioner_category:string="";
    questioner_values:string[]=[];
    questioner_Lkp_Id:number=0;
    response_Type:String;
    selected_val:String;
    constructor(){
  
    }
  
  }
  