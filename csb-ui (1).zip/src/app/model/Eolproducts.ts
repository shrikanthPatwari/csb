export class Eolproducts {
productId:number;
productName:String;
productAliasName:String;
recInsdt:String;
recUpddt:String;
}