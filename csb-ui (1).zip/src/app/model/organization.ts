export class Organization {
    
    orgName: string;
    orgType:Boolean;
    orgAdd: string;
    orgPostCd: string;
    orgCntName:string;
    orgCntNum:string;
    orgCntMail:string;
    recInsDt:string;
    recUpdDt:string;
    orgId:number;

}