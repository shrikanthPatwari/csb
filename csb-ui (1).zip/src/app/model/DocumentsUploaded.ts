export class DocumentsUploaded {

  id: string;
  Organization_name: string;
  file_type: string;
  uploaded_by:string;
  uploaded_on:string;
}
