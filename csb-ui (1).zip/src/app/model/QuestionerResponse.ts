export class Questioner {


    response_Id :number;
  
  org_Id :number;
  questioner_Id :number;
  questioner_Lkp_Id :number;
  comments :string;
  rec_Ins_Dt :String;
  rec_Upd_Dt :String;
  
    constructor()
    {
  
  
  
    }
  
  
  
  
  }
  