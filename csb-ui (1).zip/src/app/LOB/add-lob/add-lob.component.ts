import { Component, OnInit } from '@angular/core';
import {NgForm, FormGroup,FormControl,Validators,FormBuilder} from '@angular/forms';
import {HTTPService} from '../../service/httpService.service';
import { Organization } from '../../model/organization';
import {LOB} from '../../model/LOB';
import {Router} from '@angular/router'
import { MatDialogRef } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import * as pageText from 'src/app/LOB/add-lob/constants/add-lob.json'
@Component({
  selector: 'app-add-lob',
  templateUrl: './add-lob.component.html',
  styleUrls: ['./add-lob.component.css']
})
export class AddLobComponent implements OnInit {
pageText=(pageText as any).default;
options:any;
selectedValue:any;
submitted=false;
organization:Organization[];
lob =new LOB();
addLOB:FormGroup;
errorMsg:string;
lobList:LOB[];
  orgId: string;
get formControls() { return this.addLOB.controls; }
  constructor(private service:HTTPService,private formBuilder: FormBuilder,private router:Router,
    public dialogRef: MatDialogRef<AddLobComponent>,
    private _snackBar: MatSnackBar) { }

  ngOnInit(): void {
    this.orgDropdown();
    this.orgId=sessionStorage.getItem("orgId");
  }
  registerForm = this.formBuilder.group({
    // org: ['',Validators.required],
    lobname:['', Validators.required],
    lobmanager:['', Validators.required] 
  });

  loadpage(){
    this.service.getorgList().subscribe(
      data=>{

        this.organization=data;
      },
      error=>{
        this.errorMsg="Some error"
      }
      

         )
       

  }

  lobsetup(){
    // debugger;
    this.submitted= true;
  if(this.registerForm.invalid){
    return;
  }
    // debugger;
console.log("HI");



this.lob.recInsDt=new Date().toISOString();
this.lob.recUpdDt=new Date().toISOString();
this.lob.lobName=this.registerForm.value.lobname;
this.lob.lobManager=this.registerForm.value.lobmanager;
this.lob.orgId=this.orgId;
    this.service.createlob(this.lob).subscribe(
      data=>{
        console.log("data");
        this.dialogRef.close();
        this.registerForm.reset();
        this.router.navigate(['loBsetup']);
        this._snackBar.open('LOB Added Successfully ','X');

        
        
      }
    )
  }

  orgDropdown(){
    console.log("inside userList");
     this.service.getOrgs().subscribe(
      data=>{
  
        this.lobList=data;
        console.log(this.lobList);
        
      },
      error=>{
        this.errorMsg="Some error"
        
      }
      
  
         )
       
  
  }

get f() { 
  return this.registerForm.controls; 
} 
}
