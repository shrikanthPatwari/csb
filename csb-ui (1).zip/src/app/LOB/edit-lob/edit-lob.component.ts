import { Component, Inject, OnInit } from '@angular/core';

import {NgForm, FormGroup,FormControl,FormBuilder, Validators} from '@angular/forms';
import {HTTPService} from '../../service/httpService.service';
import { Organization } from '../../model/organization';
import {LOB} from '../../model/LOB';
import {Router, ActivatedRoute} from '@angular/router'
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AddOrganizationComponent } from 'src/app/add-organization/add-organization.component';
import { MatSnackBar } from '@angular/material/snack-bar';
@Component({
  selector: 'app-edit-lob',
  templateUrl: './edit-lob.component.html',
  styleUrls: ['./edit-lob.component.css']
})
export class EditLobComponent implements OnInit {

  options:any;
  selectedValue:any;
  submitted=false;
  organization:Organization[];
  lob =new LOB();
  addLOB:FormGroup;
  errorMsg:string;
  lobList:LOB[];
  orgId: string;
  get formControls() { return this.addLOB.controls; }
    constructor(private service:HTTPService,private formBuilder: FormBuilder,private router:Router,
      private activatedRoute:ActivatedRoute,@Inject(MAT_DIALOG_DATA) public data: any,
      public dialogRef: MatDialogRef<EditLobComponent>,
      private _snackBar: MatSnackBar) { }

  ngOnInit(): void {
    // debugger;
    // let id=parseInt(this.activatedRoute.snapshot.paramMap.get('id'));
    this.orgId=sessionStorage.getItem("orgId");
    this.lob=this.data.LOB;
    console.log(this.lob,"orgANIZATION Details PASSED")
   let id=this.data.LOB.lobId


    this.service.fetchLOBByIDForUpdate(id).subscribe(
      data=>{
      console.log("data recieved");
      this.lob=data;
      this.registerForm=this.formBuilder.group({
        org: data.orgId,
        lobname:[data.lobName,Validators.required],
        lobmanager:[data.lobManager ,Validators.required]
      })
     
    },
    error=>
      console.log("error")
    
    );
  }
  registerForm = this.formBuilder.group({
      // org: ['',Validators.required],
      lobname:['', Validators.required],
      lobmanager:['', Validators.required] 
    });

  

  updateLOB(){
    // debugger;
    this.submitted= true;
    if(this.registerForm.invalid){
      return;
    }
      // debugger;
  console.log("HI");
    this.lob.recInsDt=new Date().toISOString();
    this.lob.recUpdDt=new Date().toISOString();
    this.lob.lobName=this.registerForm.value.lobname;
    this.lob.lobManager=this.registerForm.value.lobmanager;
    this.lob.orgId=this.orgId;
   
    this.service.updateLOB(this.lob).subscribe(data=>{
      console.log("inside updatelob");
      this.dialogRef.close();
    
      this.registerForm.reset();
      this.router.navigate(['loBsetup']);
      this._snackBar.open('LOB Updated Successfully ','X');
    })
    error=>console.log("exception inside update");
  }
}
