
import { Component, ViewChild, HostListener, OnInit } from '@angular/core';
import { MatSidenav } from '@angular/material/sidenav';
import { BLACK_ON_WHITE_CSS_CLASS } from '@angular/cdk/a11y/high-contrast-mode/high-contrast-mode-detector';
import { constant as CONSTANT } from '../../constants';
import { MultilevelNodes } from 'ng-material-multilevel-menu';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { Router, NavigationEnd, RouterEvent } from '@angular/router';
import { FormGroup, FormControl } from '@angular/forms';
import { Validators, FormBuilder } from '@angular/forms';
import { Organization } from '../../model/organization';
import { HTTPService } from '../../service/httpService.service';
import { Pipe, PipeTransform } from '@angular/core';
import { getLocaleDateTimeFormat } from '@angular/common';
import { Observable } from "rxjs";
import { Directive, ElementRef } from '@angular/core';
import { filter } from 'rxjs/operators';
import { LOB } from '../../model/LOB';
import { AddLobComponent } from '../add-lob/add-lob.component';
import { MatDialog } from '@angular/material/dialog';
import { EditLobComponent } from '../edit-lob/edit-lob.component';
import { DeleteLobComponent } from 'src/app/delete-lob/delete-lob.component';
import { MatSnackBar } from '@angular/material/snack-bar';
import * as pageText from 'src/app/LOB/list-lob/constants/list-lob.json'

@Component({
  selector: 'app-list-lob',
  templateUrl: './list-lob.component.html',
  styleUrls: ['./list-lob.component.css']
})
export class ListLobComponent implements OnInit {
  pageText=(pageText as any).default;
  expandCollapseStatus = 'expand'
  opened = true;
  lobList: LOB[];
  lobSearchList: any;
  orgId: any;
  errorMsg: string;
  @ViewChild('sidenav', { static: true }) sidenav: MatSidenav;
  appitems: MultilevelNodes[] = CONSTANT.sidebarDemoLinks;
  config = CONSTANT.sidebarConfigurations;
  reuselobList: object;
  search: string;
  displayList = false;
  pageOfItems: Array<any>;
  totalRecords: number;
  page: number = 1;
  pageListdata = false;
  display = false;
  constructor(private iconRegistry: MatIconRegistry, private LOBservice: HTTPService,
    private sanitizer: DomSanitizer, private _el: ElementRef,
    private router: Router, private formBuilder: FormBuilder, public dialog: MatDialog, private _snackBar: MatSnackBar) {
    setTimeout(() => {
      this.displayList = true;
    }, 100);

  }

  ngOnInit(): void {
    this.orgId = sessionStorage.getItem("orgId");
    this.loadPage();
    this.router.events.pipe(filter((event: RouterEvent) => event instanceof NavigationEnd)

    ).subscribe(() => {


      this.loadPage();
    });
  }



  loadPage() {
    this.lobList = [];
    // this.LOBservice.getLOBList(this.orgId).subscribe(
      this.LOBservice.getLobs(this.orgId).subscribe(
      data => {

        this.lobList = data;
        this.lobSearchList = data;
        this.reuselobList = data;
      },
      error => {
        this.errorMsg = "Some error"
      }


    )


  }

  SearchFilter() {
    if (this.search == '') {
      this.lobSearchList = this.reuselobList;
    }
    else {
      this.lobSearchList = this.lobList.filter(res => {
        let lobName = res.lobName.toLocaleLowerCase().includes(this.search.toLocaleLowerCase());
        if (lobName) {
          return lobName
        }
      });
    }

  }

  selectedItem($event) {
  }
  setExpandCollapseStatus(type) {
    this.expandCollapseStatus = type;
  }

  selectedLabel($event) {
  }
  onChangePage(pageOfItems: Array<any>) {
    this.pageOfItems = pageOfItems;
  }
  redirect(link) {
    this.router.navigate([link]);
    setTimeout(() => {
      this.displayList = true;
    }, 100);
  }

  goToAddLob() {
    let dialogref = this.dialog.open(AddLobComponent, {
      height: '450px',
      width: '500px'

    });

    dialogref.afterClosed().subscribe(data => {
      this.loadPage();
    })

  }
  editLob(lob) {
    let dialogref = this.dialog.open(EditLobComponent, {
      height: '500px',
      width: '500px',
      data: {
        LOB: lob
      }

    });

    dialogref.afterClosed().subscribe(data => {
      this.loadPage();
    })

  }
  deleteLob(id: number) {
    let dialogRef = this.dialog.open(DeleteLobComponent, {
      height: '28%',
      width: '28%',
      data: {
        lob: 'lob'
      }
    });
    dialogRef.afterClosed().subscribe((result) => {
      let selectedOption = result;
      if (selectedOption == 'true') {

        this.LOBservice.deleteLOB(id).subscribe(
          data => {
            this._snackBar.open('LOB deleted Successfully', 'X');
          },
          error => {
            this._snackBar.open('User cannot delete LOB Name', 'X');
          }, () => {
            this.loadPage();
          }
        )

      }
    })
  }
}

