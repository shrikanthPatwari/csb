import { Component, OnInit, ViewChild } from '@angular/core';
import { MatAccordion } from '@angular/material/expansion';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-header-csb',
  templateUrl: './header-csb.component.html',
  styleUrls: ['./header-csb.component.css']
})
export class HeaderCsbComponent implements OnInit {

  @ViewChild(MatAccordion) accordion: MatAccordion;
  selected:any;
  userDisplayName:string;
  expandCollapseStatus: true;
  label:String;
  userName:string;
  name:string;
  currentRoute:string;
  selectedDashboard:string;
 

  loggedIn:boolean=true;
  orgName: string;
  roleId:any;
  Name:any;
  finalName:string;
  constructor( public router: Router,
    private route: ActivatedRoute ) { }



  ngOnInit(): void {
    this.Name=sessionStorage.getItem("Name");
    this.orgName=sessionStorage.getItem("OrgName");

    this.roleId=sessionStorage.getItem("roleId");

    this.userDisplayName = sessionStorage.getItem('username');
    
   this.name  = this.userDisplayName .substring(0, this.userDisplayName .lastIndexOf("@"));
 
   this.userName=this.name.charAt(0).toUpperCase();
   

   if(this.Name.split('').length>10){
    this.finalName =this.Name.substr(0,10)+"...";
   }
   else{
   this.finalName=this.Name;
   }



 
    if(this.router.url !== "appque" && this.router.url !== "csb"){
      this.selected ="";
    
    }

  }

  currentChoice: string = "dashboard";

  setActive(choice: string): void{
      this.currentChoice = choice;
  }

  getActive(choice: string) : string{
      if(this.currentChoice == choice)
           return "active";
      else
           return "not";

  }
  landingpage(){

    if(this.roleId==3)
    this.router.navigate(['userdashboard']);
    else
    this.router.navigate(['landing']);
  }
  cloudassist(){
    this.router.navigate(['/cloudassist']);
  }
  cra(){
    this.router.navigate(['/carAssessment']);
  }
Rlane(){
    this.router.navigate(['/csbReport']);
    
  }
  appSurvey(){
   
    this.router.navigate(['/appque']);
    if(this.router.url=="/appque"){
      sessionStorage.removeItem("appidfrompopup")
      window.location.reload();
    }
  
 
  }

  orgsurvey(){
    this.router.navigate(['/OrgQuestionnaire']);

  }
  onclick()
  {
    document.getElementById("content").style.visibility='visible';
  }
  onupload()
  {
    this.router.navigate(['homePage/cloudassist']);
  }
  onupload1()
  {
    this.router.navigate(['homePage/orgSetUp']);
  }

  
  onupload2()
  {
    this.router.navigate(['homePage/userSetup']);
  }
  onclick1()
  {
    this.router.navigate(['homePage/development']);
  }
  oncra()
    {
      this.router.navigate(['homePage/carAssessment']);

    }
  oncloud()
  {
    this.router.navigate(['homePage/cloudassist']);
  }
  
  admin(){
    this.router.navigate(['homePage/admin']);
  }
ROI(){
  this.router.navigate(['ROI'])
}

  dash(e){
    console.log("e.target.classList",e.target.parentElement.className)
    let liActiveClass = e.target.parentElement.className.split(' ')
    console.log("e",liActiveClass[1] )
    if(this.roleId!=3)
    this.router.navigate(['CsbDashboard']);
    else
    this.router.navigate(['userdashboard']);
  }
 csb(){
  this.router.navigate(['csb']);

 }
 rlanestatus(){
  this.router.navigate(['override']);

 }

 movegroup(){
  this.router.navigate(['moveGroup']);

 }

 app(){
  this.router.navigate(['appque']);

 }
 
 Infra(e){
  this.router.navigate(['infra']);    
  let p = e.target.parentNode;
  let liActiveClass = p.parentElement.className.split(' ')
  console.log("liActiveClass",liActiveClass);
  console.log("e",p.parentElement.className);

 }
 
 lob(){
  this.router.navigate(['homePage/override']);

 }


 aprdashboard(){
  this.router.navigate(['AprDashboard']);

 }


 changed(){
   if(this.selected=="Organisation"){
    this.router.navigate(['csb']);
   }
 else  if(this.selected=="Application"){
  sessionStorage.removeItem('apploblist');
  sessionStorage.removeItem('appidfrompopup');
  sessionStorage.removeItem('appnamefrompopup');
   
    this.router.navigate(['appque']);
   }
   
 }

 Application(){
  this.router.navigate(['appdiscovery']);
 }
 logout(){
  this.router.navigate(['/']);
  sessionStorage.clear();
 
  }

}
