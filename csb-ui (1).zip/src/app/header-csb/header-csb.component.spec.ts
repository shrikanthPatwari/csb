import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HeaderCsbComponent } from './header-csb.component';

describe('HeaderCsbComponent', () => {
  let component: HeaderCsbComponent;
  let fixture: ComponentFixture<HeaderCsbComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HeaderCsbComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HeaderCsbComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
