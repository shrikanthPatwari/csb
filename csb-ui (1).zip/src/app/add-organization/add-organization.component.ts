import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { Organization } from '../model/organization';
import { HTTPService } from '../service/httpService.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import * as pageText from 'src/app/add-organization/constants/add-org.json'

@Component({
  selector: 'app-add-organization',
  templateUrl: './add-organization.component.html',
  styleUrls: ['./add-organization.component.css']
})
export class AddOrganizationComponent implements OnInit {
  pageText=(pageText as any).default;
  submitted: boolean;
  org=new Organization();


  constructor(private formBuilder: FormBuilder,private service:HTTPService,
    private router:Router,private route: ActivatedRoute, private _snackBar: MatSnackBar,
    public dialogRef: MatDialogRef<AddOrganizationComponent>) { }

  ngOnInit(): void {
  }

  registerForm = this.formBuilder.group({
    orgName: ['', Validators.required],
    add1: ['', Validators.required],
    contactName:['', Validators.required],
  
    contact: ['', [Validators.required,Validators.pattern(/^[0-9]{10}$/)]],
    
   
    email : ['', [Validators.required,Validators.pattern(/^[a-z]+[a-z0-9._]+@[a-z]+\.[a-z.]{2,5}$/)]],
    zipCode : ['',Validators.pattern(/^[0-9]{6}$/)]
    
  });


  saveOrg(){
  
    this.submitted= true;
  if(this.registerForm.invalid){
    return;
  }
   
this.org.orgName=this.registerForm.value.orgName;
this.org.orgAdd=this.registerForm.value.add1;
this.org.orgCntName=this.registerForm.value.contactName;
this.org.orgCntMail=this.registerForm.value.email;
this.org.orgPostCd=this.registerForm.value.zipCode;
this.org.orgType=false;
this.org.orgCntNum=this.registerForm.value.contact;
this.org.orgId=this.registerForm.value.orgId;
this.org.recInsDt=new Date().toISOString();
this.org.recUpdDt=new Date().toISOString();
this.service.createOrg(this.org).subscribe(
  data=>{
    console.log("data");
    this.dialogRef.close();
    this.registerForm.reset();
    this.router.navigate(['listOrg']);
    // this._snackBar.open('Organization added Successfully ','X'); 
    this._snackBar.open('Organization added Successfully', 'X', {
      duration: 3000
    });
  }
)
}

}
