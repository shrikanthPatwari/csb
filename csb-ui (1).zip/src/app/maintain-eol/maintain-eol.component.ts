import { Component, OnInit } from '@angular/core';
import { HTTPService } from '../service/httpService.service';
import { MatDialog,MatDialogConfig } from '@angular/material/dialog';
import { AddProductComponent } from '../add-product/add-product.component';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';
import { DeleteEOLProductComponent } from '../delete-eolproduct/delete-eolproduct.component';
import { UpdateEolProductComponent } from '../update-eol-product/update-eol-product.component';
import { UploadResponse } from 'src/app/model/upload-response';
import { FileUploadPopUpComponent } from '../file-upload-pop-up/file-upload-pop-up.component';
import { EolFileUploadPopupComponent } from '../eol-file-upload-popup/eol-file-upload-popup.component';
import * as pageText from 'src/app/maintain-eol/constants/maintain-eol.json'
@Component({
  selector: 'app-maintain-eol',
  templateUrl: './maintain-eol.component.html',
  styleUrls: ['./maintain-eol.component.css']
})
export class MaintainEOLComponent implements OnInit {
  pageText=(pageText as any).default;
  fileStorage=[];
  orgId: any;
  upload: UploadResponse = new UploadResponse();
  asyncResult:UploadResponse;
  reuseproductList: object;
  productList: any;
  page: number = 1;
  search: string;
  check:any;
  productSerchList: any;
  constructor(private Service: HTTPService, public dialog: MatDialog,
    private router: Router, private _snackBar: MatSnackBar,private fileUploadService: HTTPService) { }

  ngOnInit(): void {
    this.orgId=sessionStorage.getItem("orgId");
    this.loadProductList();
  }
  loadProductList() {
    this.Service.getEolProductsList().subscribe(data => {
      this.productList = data;
      this.productSerchList = data;
      this.reuseproductList = data;
      console.log(this.productList,"product list details")
    });
  }
  SearchFilter() {

    if (this.search == '') {
      this.productList = this.reuseproductList;
    }
    else {
      this.productList = this.productSerchList.filter(res => {
        let productName = res.productName.toLocaleLowerCase().includes(this.search.toLocaleLowerCase());
        let productAliasName = res.productAliasName.toLocaleLowerCase().includes(this.search.toLocaleLowerCase());
        if (productName) {
          return productName
        }
        if (productAliasName) {
          return productAliasName
        }
      });
    }

  }

  addProduct() {
    let dialogRef = this.dialog.open(AddProductComponent, {
      height: '500px',
      width: '560px'
    });
    dialogRef.afterClosed().subscribe(data => {
      this.loadProductList();
    })
  }
  viewVersion(productId) {
    this.router.navigate(['EOLVersions', productId]);
  }

  deleteProduct(id) {
    let dialogRef = this.dialog.open(DeleteEOLProductComponent, {
      height: '28%',
      width: '28%',
      data: {
        Product: 'Product'
      }

    });


    dialogRef.afterClosed().subscribe((result) => {
      let selectedOption = result;
      if (selectedOption == 'true') {
        this.Service.deleteProductVersion(id).subscribe(data => {
          this.Service.deleteProduct(id).subscribe(
            data => {
              this.router.navigate(['/MaintainEOL']);
              this._snackBar.open('Product and its versions deleted Successfully', 'X');
            },
            error => {
              this._snackBar.open('Please try after sometime', 'X');
            }, () => {
              this.loadProductList();
            }
          )
        })
      }
    })
  }
  updateProduct(product) {
    let dialogref = this.dialog.open(UpdateEolProductComponent, {
      height: '350px',
      width: '560px',
      data: {
        productDetails: product
      }
    });

    dialogref.afterClosed().subscribe(data => {
      this.loadProductList();
    })
  }
  onSelectedFile(event: any) {
    if (event.target.files.length > 0) {
      this.onDroppedFile(event.target.files);
      event.target.value='';
    }
  }
    async onDroppedFile(droppedFiles: any) {
      let formData = new FormData();
      let file ;
  
      for(let item of droppedFiles) {
        file = droppedFiles.item(0);
        formData.append('UserFile', item);
        formData.append('orgId',String(this.orgId));
      }
  
      this.asyncResult = await  this.fileUploadService.pushEOLData(formData).toPromise();
  
      if(this.asyncResult){
        this.fileStorage = [];
        for(let i=0; i<this.asyncResult.files.length; i++){
          this.upload= this.asyncResult.files[i];
          console.log(this.upload);
          this.fileStorage.push(this.upload);
      }
      this.openDialog();
      this.loadProductList();
  //     this.fileUploadService.pushFileToStorageEOL(file,this.orgId).subscribe(data => {
  // this.check=data;
  // console.log(this.check,"checkcheckkkk name")
  //     },(err)=>{
  
  //     },()=>{
  //       this.openDialog();
  //       this.loadProductList();
  //    });
      
       
  //     }
  //     else{
  //       // console.log("error"+this.asyncResult);
  //     }
   
    }
  }
    openDialog() {

      const dialogConfig = new MatDialogConfig();
     
      // The user can't close the dialog by clicking outside its body
      dialogConfig.disableClose = true;
      dialogConfig.id = "modal-component";
      dialogConfig.height = "350px";
      dialogConfig.width = "600px";
      dialogConfig.disableClose = true;
      dialogConfig.autoFocus = true;
  
      this.dialog.open(EolFileUploadPopupComponent,{width: '330px',
      height: '600px',
      disableClose:true,
      autoFocus:true,
      id:"modal-component",
  
      data: {
        dataKey: this.fileStorage
      }
    });
    }
}
