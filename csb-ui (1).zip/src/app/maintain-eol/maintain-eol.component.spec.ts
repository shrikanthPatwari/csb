import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MaintainEOLComponent } from './maintain-eol.component';

describe('MaintainEOLComponent', () => {
  let component: MaintainEOLComponent;
  let fixture: ComponentFixture<MaintainEOLComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MaintainEOLComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MaintainEOLComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
