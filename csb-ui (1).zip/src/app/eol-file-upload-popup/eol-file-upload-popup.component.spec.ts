import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EolFileUploadPopupComponent } from './eol-file-upload-popup.component';

describe('EolFileUploadPopupComponent', () => {
  let component: EolFileUploadPopupComponent;
  let fixture: ComponentFixture<EolFileUploadPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EolFileUploadPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EolFileUploadPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
