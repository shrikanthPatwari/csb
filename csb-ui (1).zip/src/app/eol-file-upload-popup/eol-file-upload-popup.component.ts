import { Component, OnInit, Inject } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';

@Component({
  selector: 'app-eol-file-upload-popup',
  templateUrl: './eol-file-upload-popup.component.html',
  styleUrls: ['./eol-file-upload-popup.component.css']
})
export class EolFileUploadPopupComponent implements OnInit {

  form:FormGroup;
  description:string;
  constructor(private dialogRef: MatDialogRef<EolFileUploadPopupComponent>,@Inject(MAT_DIALOG_DATA) public data: any,private router: Router) { }

  ngOnInit(): void {
 
    
  }
  closeModal() {
    this.dialogRef.close();
  }
  actionFunction() {
    alert("You have logged out.");
    this.closeModal();
  }

}

