export class InfraDiscovery {
}
