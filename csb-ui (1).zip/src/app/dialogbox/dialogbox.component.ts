import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';
import { FormBuilder, FormControl, FormGroup, Validators } from  '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { HTTPService } from '../service/httpService.service';

interface DiscoveryTools {
  value: string;
  viewValue: string;
}
@Component({
  selector: 'app-dialogbox',
  templateUrl: './dialogbox.component.html',
  styleUrls: ['./dialogbox.component.css']
})

export class DialogboxComponent implements OnInit {
  hostNameControl:any;
  cNameControl:any;
  group= new FormGroup({
    cNameControl: new FormControl('', [Validators.required, Validators.minLength(3)]),
    cDescControl: new FormControl('', [Validators.required])
  })
  tools: DiscoveryTools[] = [
    {value: 'BMC-o', viewValue: 'BMC'},
    {value: 'Dynatrace-1', viewValue: 'Dynatrace'},
    {value: 'Device42-2', viewValue: 'Device42'}
  ];
  loginForm: FormGroup;
 
  get formControls() { return this.loginForm.controls; }
  constructor(private router: Router,   private formBuilder: FormBuilder,    private service:HTTPService,public dialogRef: MatDialogRef<DialogboxComponent>
   ) { }
  

ngOnInit(): void {

  this.loginForm  =  this.formBuilder.group({
    email: ['', Validators.required],
    password: ['', Validators.required],
    hostname:[''],
    // org:[''],
    // userOrAdmin:['user',Validators.required]
  
  });
  console.log(this.loginForm,"value")
}

gotToUpload(){
  this.dialogRef.close();
  this.router.navigate(['fileupload']);

}
upload(){
 if(this.loginForm.valid){
   console.log(this.loginForm,"testttt")
  this.service.test(this.loginForm.value.email,this.loginForm.value.password,this.loginForm.value.hostname).subscribe(data=>{
    console.log(data);
    
  });
  this.service.test1(this.rlanePercent).subscribe(data=>{
  });
  this.service.test2(this.rlanePercent).subscribe(data=>{
  });
 }
  
}
  rlanePercent(rlanePercent: any) {
    throw new Error('Method not implemented.');
  }


}
