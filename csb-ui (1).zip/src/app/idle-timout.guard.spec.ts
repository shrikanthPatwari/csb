import { TestBed } from '@angular/core/testing';

import { IdleTimoutGuard } from './idle-timout.guard';

describe('IdleTimoutGuard', () => {
  let guard: IdleTimoutGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    guard = TestBed.inject(IdleTimoutGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});
