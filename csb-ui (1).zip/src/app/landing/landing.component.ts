
import { Component, OnInit,HostListener } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { AuthenticationService } from './../service/authentication.service';

//import { NewScreenOrgDropdownComponent } from '../LOB/new-screen-org-dropdown/new-screen-org-dropdown.component';
import { HTTPService } from '../service/httpService.service';
import {IdleService} from '../service/idle-timeout/idle.service'

@Component({
  selector: 'app-landing',
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.css']
})
export class LandingComponent implements OnInit {

  name: string;
  userDisplayName: string;
  userName: string;
  orgName: string = "";
  loggedIn: boolean = true;
  selectedDropdown = { id: 0, name: '' };
  org = { id: 1, name: 'SLK' };
  lobList: any;
  roleId: String;

  constructor(private router: Router,
    private route: ActivatedRoute,
    private service: HTTPService,
    private authService: AuthenticationService,
    private idleService:IdleService,
    ) { }

  ngOnInit(): void {
    this.roleId = sessionStorage.getItem("roleId");
    if (this.roleId == "1") {
      this.service.getOrgs().subscribe(
        data => {
          this.lobList = data;
          console.log(this.lobList, "check")
        })
    }



    this.orgName = sessionStorage.getItem("OrgName");


    this.userDisplayName = sessionStorage.getItem('username');
    this.name = this.userDisplayName.substring(0, this.userDisplayName.lastIndexOf("@"));

  }


  onChangeOfDropdown($event) {

    this.selectedDropdown = this.org;

    sessionStorage.setItem("OrgName", this.selectedDropdown.name);
    sessionStorage.setItem("orgId", this.selectedDropdown.id.toString());
    // window.location.reload();


  }
  orgmenu() {
    this.router.navigate(['CsbDashboard']);
  }


  aprdashboard() {
    this.router.navigate(['AprDashboard']);

  }
  configuration() {
    this.router.navigate(['userSetup']);
  }
  // @HostListener('document:mousemove')
  // @HostListener('document:keypress')
  // onUserAction() {
  //   this.idleService.reset();
  // }
}
