import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router'
import { AuthenticationService } from '../service/authentication.service';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { LOB } from '../model/LOB';
import { HTTPService } from '../service/httpService.service';
import {
  MatSnackBar, MatSnackBarHorizontalPosition,
  MatSnackBarVerticalPosition, MatSnackBarModule
} from '@angular/material/snack-bar';
import * as pageText from 'src/app/login-new/constants/login-new.json'
@Component({
  selector: 'app-login-new',
  templateUrl: './login-new.component.html',
  styleUrls: ['./login-new.component.css']
})
export class LoginNewComponent implements OnInit {
  email = ''
  password = ''
  loginForm: FormGroup;
  invalidLogin = false;
  isSubmitted = false;
  successMessage = "";
  lobList: LOB[];
  errorMsg = "";
  orgId: any;
  showErrorMessage: any
  selectedDropdown: any;
  orgdetails: any;
  pageText = (pageText as any).default;
  uservalidation: any;
  userIdEmailMAp: any;

  get formControls() { return this.loginForm.controls; }
  constructor(private router: Router,
    private loginservice: AuthenticationService,
    private service: HTTPService,
    private formBuilder: FormBuilder,
    private _snackBar: MatSnackBar) { }

  ngOnInit(): void {
    // this.orgDropdown();
    this.loginForm = this.formBuilder.group({
      email: ['', Validators.required],
      password: ['', Validators.required],
      // org:[''],
      // userOrAdmin:['user',Validators.required]

    });
    // console.log("onInit----")
    // this.service.uservalidation().subscribe((data) => {
    //   console.log("onInit",data)
    //   this.uservalidation = data;
    //   this.userIdEmailMAp = new Map<string, number>();
    //   this.uservalidation.map(m => {
    //     this.userIdEmailMAp.set(m.migration_Strategy.toLowerCase(), m.num);
    //   })
    // }); //end

  }
  login() {

    this.isSubmitted = true;
    // if(this.loginForm.get('userOrAdmin').value == 'admin'){
    // if(this.userIdEmailMAp.get(this.loginForm.value.email) != 3) {
    //  this.loginForm.get('org').setValidators([Validators.required]);

    //  if(this.loginForm.get('org').value == ''){
    //  this._snackBar.open("Organization Field is Mandatory","X");
    //  return;
    // }
    // else{
    if (this.loginForm.valid) {
      this.loginservice.authenticate(this.loginForm.value.email, this.loginForm.value.password).subscribe((result) => {
        this.isSubmitted = true;
        this.invalidLogin = false;

        if (result.message != null) {
          this._snackBar.open(result.message, "X");
        }
        else {
          this.service.Orgname(this.loginForm.value.email).subscribe(
            data => {
              this.orgdetails = data;
              // sessionStorage.setItem("Name", this.orgdetails[0].first_Name + " " + this.orgdetails[0].last_Name);
              sessionStorage.setItem("Name", this.orgdetails[0].emailId);
              sessionStorage.setItem("OrgName", this.orgdetails[0].org_name);
              sessionStorage.setItem("orgId", this.orgdetails[0].org_Id);
              sessionStorage.setItem("roleId", this.orgdetails[0].user_role_id)
              sessionStorage.setItem("LobId", this.orgdetails[0].lob_Id)
              sessionStorage.setItem("userId", this.orgdetails[0].user_id)

              // if(this.userIdEmailMAp.get(this.loginForm.value.email) == 3){
              //   this.router.navigate(['userdashboard']);
              // }
              if (this.orgdetails[0].user_role_id == 3) {
                this.router.navigate(['userdashboard']);
              }
              else {
                // this.router.navigate(['landing']);
                this.router.navigate(['csbReport']);
              }
            });

        }
      }, (err) => {
        // console.log("res======>>>>>>",err)
        // console.log("res==>>>>>>",err.error)
        this.invalidLogin = true;
        this.successMessage = err.error;
        this._snackBar.open(this.successMessage, "X");

      });
    } else {
      this._snackBar.open("Both fields are Mandatory", "X")
    }
    // }
    // }
    // else{
    // this._snackBar.open("Entered Email is not Registered as Admin, Please Login as a User","X");
    // }
    // }
    // else{
    //   if(this.userIdEmailMAp.get(this.loginForm.value.email) == 3)
    // {
    // this.loginForm.get('org').clearValidators();
    // this.loginservice.authenticate(this.loginForm.value.email, this.loginForm.value.password).subscribe((result)=> {

    //   this.isSubmitted = true;
    //   this.invalidLogin = false;
    //   this.service.Orgname(this.loginForm.value.email).subscribe(
    //     data=>{
    // this.orgdetails = data;

    // sessionStorage.setItem("OrgName",this.orgdetails[0].org_name);
    // sessionStorage.setItem("orgId",this.orgdetails[0].org_Id);
    // sessionStorage.setItem("roleId",this.orgdetails[0].user_role_id)
    // sessionStorage.setItem("LobId",this.orgdetails[0].lob_Id)

    //   this.router.navigate(['userdashboard']);


    //     });

    // }, () => {
    //   this.invalidLogin = true;
    // this.successMessage="Login failed, Invalid username or password , please try again";
    // this._snackBar.open(this.successMessage,"X");

    // });
    // }
    // else{
    //   this._snackBar.open("Entered Email is not Registered as User ,Please Login as a Admin","X");
    // }
    // }

  }

  // orgDropdown() {

  //   this.service.getOrgs().subscribe(
  //     data => {

  //       this.lobList = data;


  //     },
  //     error => {
  //       this.errorMsg = "Some error"

  //     }


  //   )


  // }
  onChangeOfDropdown($event) {

    this.selectedDropdown = this.loginForm.value.org.name;
    this.orgId = this.loginForm.value.org.id;
    if (this.loginForm.get('userOrAdmin').value == 'admin') {
      sessionStorage.setItem("OrgName", this.selectedDropdown);
      sessionStorage.setItem("orgId", this.orgId);
    }

  }



}

