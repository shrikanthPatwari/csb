import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';

import { HTTPService } from '../service/httpService.service';
import { MatDialog } from '@angular/material/dialog';
import * as am4core from '@amcharts/amcharts4/core';
import * as am4charts from '@amcharts/amcharts4/charts';
import { CategoryAxis, ValueAxis } from '@amcharts/amcharts4/charts';
import { truncateWithEllipsis } from '@amcharts/amcharts4/.internal/core/utils/Utils';
import { Router, RouterStateSnapshot } from '@angular/router';
import { DashboardPopupComponent } from '../dialog-reports/dashboard-popup/dashboard-popup.component';
// import { ProgressBarModule } from 'angular-progress-bar';
import { DialogReportsComponent } from '../dialog-reports/dialog-reports.component';
import { DialogboxComponent } from '../dialogbox/dialogbox.component';
import { ChartPopupComponent } from '../chart-popup/chart-popup.component';
import { InfraPopupComponent } from '../infra-popup/infra-popup.component';
import { MoveGroupChartPopUpComponent } from '../move-group-chart-pop-up/move-group-chart-pop-up.component';
import { VersionMapPopupComponent } from '../version-map-popup/version-map-popup.component';
import { MatSnackBar } from '@angular/material/snack-bar';
import { user } from '../model/user';
import * as pageText from 'src/app/csb-dashboard/constants/csb-dashboard.json';
// import { ApplicationPopupComponent } from '../application-popup/application-popup.component';

@Component({
  selector: 'app-csb-dashboard',
  templateUrl: './csb-dashboard.component.html',
  styleUrls: ['./csb-dashboard.component.css'],
})
export class CsbDashboardComponent implements OnInit {
  pageText = (pageText as any).default;
  progressBarCount: boolean;
  getEOLProgressCount: boolean;
  values = [];
  groupCount: boolean;
  progressBarData: any;
  groupAppData: any;
  groupmap = new Map();
  groupList: any;
  lobarr = [];
  arrtohtml = [];
  modelobject = {
    lobname: '',
    total: '',
    active: '',
    notactiveapplications: [],
  };
  loblist: any;
  modelobjectArray = [];
  @ViewChild('chartElement') chartElement: ElementRef<HTMLElement>;
  rehostcount = 0;
  replatformcount = 0;
  replacecount = 0;
  csbReport: string = 'CSB Dashboard';
  rearchiturecount = 0;
  retaincount = 0;
  retirecount = 0;
  rlanesubtitle = '';
  test = [];
  subTitle = '';
  rlanePercent: any;
  rlanecount = 0;
  noofenvironment: any;
  Environmentcounting: any;
  // popup1=true;

  infradatacountdisplay = 0;
  Environmentcount: any;
  osdata: any;
  lobdata: any;
  appSurvey: boolean = false;
  caappmasterdata: any;
  evaluatedapps: any;
  applicationcount = 0;
  Rlane: any;
  infradatacount: any;
  updateddate: any;
  lobcount: any;
  moveGroupData: any;
  vendorcount = 0;
  datacentercount = 0;
  ApplicationSurveycount: any;
  CAAppMaster: any;
  lob: any;
  lobmap: any;
  CAInfradata: any;
  datacentreview: object;
  orgId: any;
  EOLProgresslist: any;
  OsEOLPercent: number;
  OsEOLsubtitle: string;
  techstackEOLEOLPercent: number;
  techstackEOLEOLsubtitle: string;
  OS_ServerEOLlist: any;
  SoftwarEOLOLlist: any;
  mappedversionData: any;
  productId: any;
  SurveyDetails: any[];
  userArray = [];
  delegateArray = [];
  delegateSurveyObject = {
    userId: '',
    userName: '',
    delegatedBy: '',
    total: '',
    active: '',
    notactiveapplications: [],
    delegatedToEmailId: '',
    delegatedByEmailID: ''
  };
  AppCountArray = [];
  userList: user[];
  emailpwordcombo = [];
  constructor(
    private Service: HTTPService,
    private dialogue: MatDialog,
    private router: Router,
    private _snackBar: MatSnackBar
  ) { }

  ngOnInit(): void {

    this.orgId = sessionStorage.getItem("orgId");
    this.productId = sessionStorage.getItem("productId");
    this.Service.CAAppMaster(this.orgId).subscribe((data: any[]) => {
      this.CAAppMaster = data;
      // this.CAAppMaster=undefined;
      if (data.length == 0) {
        this.popup();
      }

    });

    this.delegateSurveyStatus();

    this.Service.ApplicationVersion(this.orgId).subscribe((data) => {
      this.mappedversionData = data;
      console.log(this.mappedversionData, "versions")

      if (this.mappedversionData.length != 0) {
        this.dialogue.open(VersionMapPopupComponent, {
          width: '500px',
          height: '250px',
          disableClose: true,
          autoFocus: true,
        });

      }
    });



    this.Service.getLobs(this.orgId).subscribe((data) => {
      this.lob = data;
      let d = new Map();
      //count starts
      this.lob.map((m) => {
        d.set(m.lobId, m.lobName);
      });
      this.lobmap = d;
    }); //end

    this.Service.EOLProgresslist().subscribe(
      data => {
        this.EOLProgresslist = data;
        console.log("this.EOLProgresslist",this.EOLProgresslist)
        if (this.EOLProgresslist.length != 0) {
          this.getEOLProgressCount = true;

          this.calculateTechstackEOL();
          this.calculateOsEOL();
        }
      })


    this.Service.OS_ServerEOL().subscribe(
      data => {
        this.OS_ServerEOLlist = data;
      })

    this.Service.SoftwarEOL().subscribe(
      data => {
        this.SoftwarEOLOLlist = data;
      })

    this.ROIStackBar();

    this.Service.getMoveGroup(this.orgId).subscribe(data => {
      this.groupList = data;
      // console.log(this.groupList, "group namessss")
      this.groupList.map(m => {
        this.groupmap.set(m[0].moveGroupName, m[0].moveGroupId);
        // console.log(this.groupmap, "group name and id")
      })
    })

    this.Service.getMoveGroupAppsforTreeChart(this.orgId).subscribe((data) => {
      this.groupAppData = data;
    });

    this.Service.MoveGroupAppCount(this.orgId).subscribe(data => {
      this.moveGroupData = data;
      if (this.moveGroupData.length != 0) {
        this.groupCount = true;
        this.createtreechart()
      }
    });

    this.caInfraData()

  }
  caInfraData(){
    this.Service.CAInfradata(this.orgId).subscribe((data) => {
      this.CAInfradata = data;
      console.log("CAInfradata",this.CAInfradata)
      this.piechartEnv();
      this.pieChartOs();
    }); //end
  }

  calculateOsEOL() {
    this.OsEOLPercent = (this.EOLProgresslist.osEOLCount / this.EOLProgresslist.osCount) * 100;
    this.OsEOLsubtitle = this.EOLProgresslist.osEOLCount + '/' + this.EOLProgresslist.osCount;
  }
  calculateTechstackEOL() {
    this.techstackEOLEOLPercent = (this.EOLProgresslist.techstackEOLCount / this.EOLProgresslist.techstackCount) * 100;
    this.techstackEOLEOLsubtitle = this.EOLProgresslist.techstackEOLCount + '/' + this.EOLProgresslist.techstackCount;
  }
  popup() {
    var dialogRef = this.dialogue.open(DialogboxComponent, {
      width: '40%',
      minHeight: 'calc(100vh - 90px)',
      height: 'auto',

      disableClose: true,

      data: {
        dataKey: this.csbReport,
      },
    });
    // this.popup1=false;
    //this.router.navigate(['/dashboardpopup'])
    dialogRef.afterClosed().subscribe((result) => {
      let res = result;
    });
  }
  appque() {
    this.router.navigate(['/appque']);
  }
  ngAfterViewInit() {
    this.getrlanedata();
    this.getappPercent();

    this.Service.datacentreview(this.orgId).subscribe((data) => {
      this.datacentercount = Object.keys(data).length;
    });

    this.Service.ApplicationSurveycount(this.orgId).subscribe((data) => {
      this.ApplicationSurveycount = data;
      // console.log(this.ApplicationSurveycount, "applicationSurveyCount")
      let marr = [];

      this.ApplicationSurveycount.map((m, i) => {
        let lobobj = { lobname: '', app: [] };
        let application = { appname: '', activestatus: '' };
        if (i == 0) {
          lobobj = { lobname: '', app: [] };
          application = { appname: '', activestatus: '' };
          application.appname = m.app_Name;
          application.activestatus = m.app_Suv_Status;
          lobobj.lobname = m.lob_Name;
          lobobj.app.push(application);
          marr.push(lobobj);
          // console.log(marr,"lob with applications ")
        } else {
          marr.map((f) => {
            lobobj = { lobname: '', app: [] };
            application = { appname: '', activestatus: '' };
            if (f.lobname == m.lob_Name) {
              application.appname = m.app_Name;
              application.activestatus = m.app_Suv_Status;
              f.app.push(application);
            } else {
              lobobj = { lobname: '', app: [] };
              application = { appname: '', activestatus: '' };
              lobobj.lobname = m.lob_Name;
              application.appname = m.app_Name;
              application.activestatus = m.app_Suv_Status;
              lobobj.app.push(application);
            }
          });
          marr.push(lobobj);

        }
        // console.log(marr,"lob with applications, else works ")
      });
      marr.filter((f) => {
        if (f.lobname !== '') {
          this.modelobjectArray.push(f);
        }
      });
      // console.log(this.modelobjectArray, "model object ");

      let newarrtohtml = [];
      this.modelobjectArray.filter((f, i) => {
        if (i == 0) {
          this.arrtohtml.push(f);
        }
        else if (f.lobname !== this.modelobjectArray[i - 1].lobname) {
          this.arrtohtml.push(f);
        }
      });
      // console.log(this.arrtohtml, "arraytoHTML")
      newarrtohtml = this.arrtohtml;
      let res = [];
      this.arrtohtml.map((m, i) => {
        if (i == 0) {
          res.push(m);
        }
        else {
          let pusar = [];
          for (let j = 0; j < res.length; j++) {
            let pushing = true;
            if (res[j].lobname != m.lobname) {
              pushing = true; pusar.push(pushing);
            } else {
              pushing = false; pusar.push(pushing);
            }
          }

          if (!pusar.includes(false)) {
            res.push(m);
          }
        }
      });
      this.arrtohtml = res;
      // console.log(this.arrtohtml, "arraytoHTML")
      this.arrtohtml.map((m) => {
        this.modelobject = {
          lobname: '',
          total: '',
          active: '',
          notactiveapplications: [],
        };
        this.modelobject.total = m.app.length;
        this.modelobject.lobname = m.lobname;
        let c = 0;
        m.app.map((h) => {
          if (h.activestatus == 1) {
            c = c + 1;
          } else {
            this.modelobject.notactiveapplications.push(h);
          }
        });
        this.modelobject.active = c + '';
        this.lobarr.push(this.modelobject);

      });
    });



    this.Service.infradatacount(this.orgId).subscribe((data) => {
      // this.infradatacountdisplay=Object.keys(data).length=0;
      let total = 0;
      Object.keys(data).map(m => {
        total = total + data[m].num;
      })
      this.infradatacountdisplay = total;

      if (Object.keys(data).length > 0) {
        // this.infradatacountdisplay = data[0].num;
        this.updateddate = data[0].migration_Strategy;
        this.updateddate = this.updateddate.split(' ')[0];
      } else if (Object.keys(data).length == 0) {
        // this.popup();
      } else {
      }

      //     //infraapplication count
    }); //end

    //lobcount
    this.Service.getLobs(this.orgId).subscribe((data) => {
      let count = 0;
      this.lobcount = data;
      this.loblist = data;

      this.lobcount.map((m) => {
        count = count + 1;
      });
      this.lobcount = count;


      let d = new Map();
      //count starts
      this.lob.map((m) => {

        d.set(m.lobId, m.lobName);
      });



    }); //end

    this.Service.getvendoranddate(this.orgId).subscribe((data) => {
      this.vendorcount = data[0].vendorcount;
      this.updateddate = data[0].dateupdated;
      this.updateddate = this.updateddate.split(' ')[0];
    });

    //OSData
    // this.Service.getOStochart(this.orgId).subscribe((data) => {
    //   this.osdata = data;
    //   console.log(this.osdata, "os dataaaaaaaa")
    //   let wpercent = 0;
    //   let c = '#00416';
    //   let outerdiv = document.getElementById('dynamicdiv');
    //   let outerdivtext = document.getElementById('dynamicdivtext');
    //   outerdiv.style.width = '200px';
    //   outerdivtext.style.width = '200px';
    //   this.osdata.map((m) => {
    //     wpercent = wpercent + parseInt(m.count);
    //   });

    //   this.osdata.map((m, i) => {
    //     let name = m.name.split(' ').join('');
    //     var nametag = document.createElement('span');
    //     var innerdiv = document.createElement('div');
    //     var nametagtext = document.createElement('span');
    //     var innerdivtext = document.createElement('div');
    //     let ppercent = (m.count / wpercent) * 100;
    //     innerdiv.setAttribute('id', name);
    //     innerdivtext.setAttribute('idtext', name);
    //     nametag.innerText = name;
    //     innerdiv.style.paddingRight = ppercent / 2 + '%';
    //     innerdiv.style.paddingLeft = ppercent / 2 + '%';
    //     nametagtext.innerText = name;
    //     innerdivtext.style.paddingRight = ppercent / 2 + '%';
    //     innerdivtext.style.paddingLeft = ppercent / 2 + '%';
    //     innerdiv.style.cursor = 'pointer';
    //     innerdivtext.innerText = name;

    //     innerdiv.innerText = name;
    //     innerdiv.addEventListener('click', () => {
    //       ////

    //       let reftodilog = this.dialogue;

    //       let displayelements = [];

    //       let infratable = this.CAInfradata;
    //       let topopup = [];

    //       displayelements = [];

    //       topopup = [];

    //       infratable.map((f) => {
    //         if (f.osType == m.name) {
    //           var obj = {
    //             Host_Name: '',
    //             IP_Address: '',
    //             Environment: '',
    //             Data_Center: '',
    //           };
    //           obj.Host_Name = f.hostName;
    //           obj.IP_Address = f.ipAddress;
    //           obj.Environment = f.environment;
    //           obj.Data_Center = f.dataCenter;
    //           topopup.push(obj);
    //         }
    //       });

    //       var dref = reftodilog.open(InfraPopupComponent, {
    //         height: '75%',
    //         width: '60%',
    //         disableClose: false,
    //         data: {
    //           dataKey: topopup,
    //           title: m.name,
    //           datacenter: false,
    //           physicalvsvirtual: true,
    //           piechartname: 'OS Type',
    //         },
    //       });

    //       //////
    //     });
    //     if (i % 2 == 0) {
    //       innerdiv.style.backgroundColor = c + i;
    //       innerdiv.style.color = 'transparent';
    //       innerdivtext.style.backgroundColor = 'transparent';
    //       innerdivtext.style.color = 'black';
    //     } else {
    //       innerdiv.style.backgroundColor = '#BBCEF2';
    //       innerdiv.style.color = 'transparent';
    //       innerdivtext.style.backgroundColor = 'transparent';
    //       innerdivtext.style.color = 'black';
    //     }
    //     outerdiv.appendChild(innerdiv);
    //     outerdivtext.appendChild(innerdivtext);
    //   });
    // }); //end
    // this.Service.getOStochart(this.orgId).subscribe((data) => {
    //   this.osdata = data;
    //   // this.createOSNamechart();
    //   let windows = 0;
    //   let linux = 0;
    //   let windowsServer = 0;
    //   this.osdata.map((m) => {
    //     if (m.name == 'Windows') windows = m.count;
    //     if (m.name == 'Linux') linux = m.count;
    //   });
    //   windows = Math.round(windows / 3);
    //   // windowsServer =  Math.round(windowsServer/3);
    //   linux = Math.round(linux / 3);

    //   var prod = document.getElementById('windows');
    //   prod.style.width = windows + 'px';
    //   prod.style.backgroundColor = '#00416D';

    //   var preprod = document.getElementById('Linux');
    //   preprod.style.width = linux + 'px';
    //   preprod.style.backgroundColor = '#007ACC';
    // });

    // //OScount stackedbar graph Environment
    // this.Service.Environmentcount(this.orgId).subscribe((data) => {
    //   this.Environmentcount = data;
    //   console.log(this.Environmentcount, "environment count")
    //   this.Environmentcounting = Object.keys(data).length;

    //   let wpercent = 0;
    //   // let c = '#00416';
    //   let c = '#00416';
    //   let outerdiv = document.getElementById('dynamicdivenv');
    //   let outerdivtext = document.getElementById('dynamicdivenvtext');
    //   outerdiv.style.width = '400px';
    //   outerdivtext.style.width = '400px';
    //   this.Environmentcount.map((m) => {
    //     wpercent = wpercent + parseInt(m.num);
    //   });

    //   this.Environmentcount.map((map, i) => {
    //     let name = map.migration_Strategy.split(' ').join('');
    //     var nametag = document.createElement('span');
    //     var nametagtext = document.createElement('span');
    //     var innerdiv = document.createElement('div');
    //     var innerdivtext = document.createElement('div');
    //     let ppercent = (map.num / wpercent) * 100;
    //     innerdiv.setAttribute('id', name);
    //     innerdivtext.setAttribute('id', name);
    //     nametag.innerText = name;
    //     nametagtext.innerText = name;
    //     innerdiv.style.paddingRight = ppercent / 2 + '%';
    //     innerdiv.style.paddingLeft = ppercent / 2 + '%';
    //     innerdivtext.style.paddingRight = ppercent / 2 + '%';
    //     innerdivtext.style.paddingLeft = ppercent / 2 + '%';
    //     innerdiv.style.cursor = 'pointer';
    //     innerdiv.innerText = name;
    //     innerdiv.appendChild(nametag);
    //     innerdivtext.appendChild(nametag);
    //     if (i % 2 == 0) {
    //       innerdiv.style.backgroundColor = c + i;
    //       innerdiv.style.color = 'transparent';
    //       innerdivtext.style.backgroundColor = 'transparent';
    //       innerdivtext.style.color = 'black';
    //     } else {
    //       innerdiv.style.backgroundColor = '#BBCEF2';
    //       innerdiv.style.color = 'transparent';
    //       innerdivtext.style.backgroundColor = 'transparent';
    //       innerdivtext.style.color = 'black';
    //     }
    //     outerdiv.appendChild(innerdiv);
    //     outerdivtext.appendChild(innerdivtext);
    //     innerdiv.addEventListener('click', () => {
    //       let reftodilog = this.dialogue;
    //       let displayelements = [];
    //       let list = this.CAInfradata;
    //       let topopup = [];
    //       displayelements = [];
    //       topopup = [];
    //       list.map((m) => {
    //         if (m.environment.split(' ').join('') == name) {
    //           displayelements.push(m);
    //           var obj = {
    //             Host_Name: '',
    //             IP_Address: '',
    //             Environment: '',
    //             Data_Center: '',
    //           };
    //           obj.Host_Name = m.hostName;
    //           obj.IP_Address = m.ipAddress;
    //           obj.Environment = m.environment;
    //           obj.Data_Center = m.dataCenter;
    //           topopup.push(obj);
    //         }
    //       });
    //       var dref = reftodilog.open(InfraPopupComponent, {
    //         height: '75%',
    //         width: '60%',
    //         disableClose: false,
    //         data: {
    //           dataKey: topopup,
    //           title: name,
    //           datacenter: false,
    //           physicalvsvirtual: true,
    //           // Environment:true,
    //           piechartname: 'Environment',
    //         },
    //       });
    //     });
    //   });
    // });

    //lob name n count
    this.Service.getlobcount(this.orgId).subscribe((data) => {
      this.lobdata = data;
    });
  }
  // total progress
  getappPercent() {
    this.Service.getapppercent(parseInt(this.orgId)).subscribe((data) => {
      this.caappmasterdata = data;

      if (this.caappmasterdata) {
        let a = this.caappmasterdata[1].num;
        let b = this.caappmasterdata[0].num;
        this.subTitle = a + '/' + b;
        this.applicationcount = this.caappmasterdata[0].num;

        this.evaluatedapps = (a / b) * 100;

        this.createradar();
        this.getrlanedata();
      }
    }); // total progressends
  }

  piechartEnv() {
    this.Service.Environmentcount(this.orgId).subscribe((data) => {
      this.Environmentcount = data;
      this.Environmentcounting = Object.keys(data).length;
      const colorList = ["#65348F", "#217378", "#595A5C", "#CC8787", "#4670B4"]
      this.Environmentcount.forEach((e, i) => {
        this.Environmentcount[i]["color"] = colorList[i]
      })
      console.log("this.Environmentcount", this.Environmentcount,)
      let chart = am4core.create("pieChartEnv", am4charts.PieChart);
      chart.logo.dispose();
      chart.data = this.Environmentcount;
      chart.innerRadius = 80;
      chart.radius = am4core.percent(70);
      // chart.radius = am4core.percent(100);
      let label = chart.seriesContainer.createChild(am4core.Label);
      label.horizontalCenter = "middle";
      label.verticalCenter = "middle";
      label.fontSize = 20;
      let pieSeries = chart.series.push(new am4charts.PieSeries());
      pieSeries.dataFields.value = "num";
      pieSeries.dataFields.category = "migration_Strategy";
      pieSeries.slices.template.propertyFields.fill = "color";
      pieSeries.slices.template.stroke = am4core.color("#ffff");
      pieSeries.slices.template.strokeWidth = 2;
      pieSeries.slices.template.strokeOpacity = 1;
      pieSeries.alignLabels = false;
      const reftodilog: any = this.dialogue;
      let displayelements = [];
      let valueselected = ''
      const list = this.CAInfradata;
      const envData = this.Environmentcount;

      pieSeries.slices.template.events.on("hit", function (ev) {
        valueselected = ev.target.dataItem.properties.category;
        let count = 0;
        const series: any = ev.target.dataItem.component;
        series.slices.each(function (item) {
          if (item.isActive && item != ev.target) {
            item.isActive = false;
          }
          if (count < 1) {
            envData.map((map, i) => {
              // console.log("map",map)
              let name = map.migration_Strategy.split(' ').join('');
              let topopup = [];
              displayelements = [];
              topopup = [];
              list.map((m) => {
                // console.log("m",m)
                if ((m.environment)&& m.environment.split(' ').join('')== name) {
                  displayelements.push(m);
                  var obj = {
                    Host_Name: '',
                    IP_Address: '',
                    Environment: '',
                    Data_Center: '',
                  };
                  obj.Host_Name = m.hostName;
                  obj.IP_Address = m.ipAddress;
                  obj.Environment = m.environment;
                  obj.Data_Center = m.dataCenter;
                  topopup.push(obj);
                }
              });
              let selectedName = name == "PreProd" ? "Pre Prod" : name;
              console.log("selectedName",)
              if (valueselected == selectedName) {
                reftodilog.open(InfraPopupComponent, {
                  height: '75%',
                  width: '60%',
                  disableClose: false,
                  data: {
                    dataKey: topopup,
                    title: name,
                    datacenter: false,
                    physicalvsvirtual: true,
                    // Environment:true,
                    piechartname: 'Environment',
                  },
                });

              }

            })
            count = count + 1
          }
        })

      });
      chart.legend = new am4charts.Legend();
      chart.legend.position = "right"
      chart.legend.labels.template.maxWidth = 10;
      chart.legend.itemContainers.template.clickable = false;
      chart.legend.itemContainers.template.focusable = false;
      let marker: any = chart.legend.markers.template.children.getIndex(0);
      marker.cornerRadius(12, 12, 12, 12, 12);
      pieSeries.labels.template.disabled = true;
      // pieSeries.slices.template.tooltipText = "";

    })

  }
  pieChartOs() {
    this.Service.getOStochart(this.orgId).subscribe((data) => {
      this.osdata = data;
      const colorListOs = ["#CC8787", "#595A5C", "#217378"]
      this.osdata.forEach((l, i) => {
        this.osdata[i].count = parseInt(l.count);
        this.osdata[i]["color"] = colorListOs[i]
      })
      // this.Environmentcounting = Object.keys(data).length;
      console.log("this.osdata", this.osdata,)
      let chart = am4core.create("pieChartOsType", am4charts.PieChart);
      chart.logo.dispose();
      chart.data = this.osdata;
      chart.innerRadius = 80;
      chart.radius = am4core.percent(70);
      let label = chart.seriesContainer.createChild(am4core.Label);
      label.horizontalCenter = "middle";
      label.verticalCenter = "middle";
      // label.fontSize = 50;
      let pieSeries = chart.series.push(new am4charts.PieSeries());
      pieSeries.dataFields.value = "count";
      pieSeries.dataFields.category = "name";
      pieSeries.slices.template.propertyFields.fill = "color";
      pieSeries.slices.template.stroke = am4core.color("#ffff");
      pieSeries.slices.template.strokeWidth = 2;
      pieSeries.slices.template.strokeOpacity = 1;
      pieSeries.alignLabels = false;
      chart.legend = new am4charts.Legend();
      chart.legend.position = "right"
      chart.legend.itemContainers.template.clickable = false;
      chart.legend.itemContainers.template.focusable = false;
      pieSeries.labels.template.disabled = true;
      let marker: any = chart.legend.markers.template.children.getIndex(0);
      marker.cornerRadius(12, 12, 12, 12, 12);
      // pieSeries.slices.template.tooltipText = "";

      const reftodilog: any = this.dialogue;
      let displayelements = [];
      let valueselected = ''
      const osTypeData = this.osdata;
      const list = this.CAInfradata;
      pieSeries.slices.template.events.on("hit", function (ev) {
        const series: any = ev.target.dataItem.component;
        valueselected = ev.target.dataItem.properties.category;
        let count = 0;
        series.slices.each(function (item) {
          if (item.isActive && item != ev.target) {
            item.isActive = false;
          }
        })
        if (count < 1) {
          console.log("Listttttt",list)
          osTypeData.map((ele) => {
            let name = ele.name.split(' ').join('');
            console.log("nameeeee",name)
            let topopup = [];
            displayelements = [];
            topopup = [];
            list.map((f) => {
              if (f.osType == ele.name) {
                var obj = {
                  Host_Name: '',
                  IP_Address: '',
                  Environment: '',
                  Data_Center: '',
                };
                obj.Host_Name = f.hostName;
                obj.IP_Address = f.ipAddress;
                obj.Environment = f.environment;
                obj.Data_Center = f.dataCenter;
                topopup.push(obj);
                
              }
              // console.log("topopup",topopup)
            });
            let selectedName = name == "MicrosoftWindowsServer2012Datacenter" ? "Microsoft Windows Server 2012 Datacenter" : name
            // console.log("===========",valueselected,"name--",name)
            if (valueselected == selectedName) {
              reftodilog.open(InfraPopupComponent, {
                height: '75%',
                width: '60%',
                disableClose: false,
                data: {
                  dataKey: topopup,
                  title: ele.name,
                  datacenter: false,
                  physicalvsvirtual: true,
                  piechartname: 'OS Type',
                },
              });
            }
          })
        }
      });
    })
  }

  createradar() {
    var chart = am4core.create(
      'chartdivEnvironmentvsServer',
      am4charts.RadarChart
    );
    chart
    // am4core.color("red");
    chart.logo.dispose()
    let resultretiredapp = { DataCat: '', num: 0 };
    resultretiredapp["config"] = { "fill": "red" }
    let DatavsIP = [];
    console.log("this.rlane",this.Rlane)
    this.Rlane.forEach((m) => {
      resultretiredapp.DataCat = m.migration_Strategy;
      resultretiredapp.num = m.num;
      DatavsIP.push(resultretiredapp);
      this.rlanecount = this.rlanecount + m.num;
      resultretiredapp = { DataCat: '', num: 0 };
    });

    this.calculaterlanePercent();

    chart.data = DatavsIP;

    /* Create axes */
    var categoryAxis = chart.xAxes.push(
      new CategoryAxis<am4charts.AxisRendererCircular>()
    );
    // categoryAxis._renderer._gridType =

    categoryAxis.dataFields.category = 'DataCat';
    categoryAxis.renderer.grid.template.location = 0.5;
    categoryAxis.renderer.tooltipLocation = 0.001;

    var valueAxis = chart.yAxes.push(
      new ValueAxis<am4charts.AxisRendererRadial>()
    );
    valueAxis.renderer.gridType = 'polygons';
    valueAxis.renderer.axisFills.template.fill = chart.colors.getIndex(2);
    valueAxis.renderer.axisFills.template.fillOpacity = 0.05;

    /* Create and configure series */
    var series = chart.series.push(new am4charts.RadarSeries());
    series.dataFields.valueY = 'num';
    series.dataFields.categoryX = 'DataCat';
    series.name = 'DataCat';
    series.strokeWidth = 3;
    chart.config = { "fill": "red" }
    // series.columns.template.fill = am4core.color("#B976C3");

    chart.cursor = new am4charts.RadarCursor();
    chart.cursor.fullWidthLineX = true;
    chart.cursor.xAxis = categoryAxis;
    chart.cursor.lineY.disabled = true;
    chart.cursor.lineX.fill = chart.colors.getIndex(3);
    chart.cursor.lineX.fillOpacity = 0.3;
  }

  calculaterlanePercent() {
    // debugger;
    this.rlanePercent = (this.rlanecount / this.applicationcount) * 100;
    console.log("rlanePercent------", this.rlanePercent)
    this.rlanesubtitle = this.rlanecount + '/' + this.applicationcount;
    if (this.rlanecount > 0) {
      this.appSurvey = true;
    }
  }

  Rehostingdata() {
    // debugger;
    let chartdivphysical = am4core.create('rehosting', am4charts.PieChart);
    let resultphysical = { migration_Strategy: '', num: 0 };
    let physicaldata = [];
    resultphysical.num = this.rehostcount;
    resultphysical.migration_Strategy = 'rehost';
    physicaldata.push(resultphysical);
    resultphysical = { migration_Strategy: '', num: 0 };
    resultphysical.num = this.rlanecount;

    resultphysical.migration_Strategy = 'total';
    physicaldata.push(resultphysical);
    // console.log(physicaldata, "physicaldata");

    chartdivphysical.data = physicaldata;

    let pieSeriesarch = chartdivphysical.series.push(new am4charts.PieSeries());
    pieSeriesarch.dataFields.value = 'num';
    pieSeriesarch.dataFields.category = 'migration_Strategy';
    // chartdivphysical.legend = new am4charts.Legend();
    pieSeriesarch.slices.template.cursorOverStyle = am4core.MouseCursorStyle.pointer;
    pieSeriesarch.ticks.template.disabled = true;
    pieSeriesarch.alignLabels = false;
    pieSeriesarch.labels.template.text = '{value}';
    pieSeriesarch.labels.template.fontWeight = "bold";
    pieSeriesarch.labels.template.radius = am4core.percent(-40);

    pieSeriesarch.colors.list = [
      am4core.color('#CED2D9'),
      am4core.color('#AAB5CA'),
      am4core.color('#9DB0D8'),
      am4core.color('#81A9F8'),
      am4core.color('#5188F6'),
      am4core.color('#3A79F8'),
    ];


    let reftodilog = this.dialogue;
    let valueselected;
    let displayelements = [];
    let list = this.CAAppMaster;
    let locallob = this.lobmap;
    let topopup = [];
    let aa = [];

    pieSeriesarch.slices.template.events.on('hit', function (ev) {
      displayelements = [];
      valueselected = ev.target.dataItem.properties.category;
      topopup = [];
      aa = [];
      list.map((m) => {
        if (m[0].rlaneStrategyId == 1 && valueselected == 'rehost') {
          displayelements.push(m);
          var obj = { lobname: '', appname: '', appid: 0 };
          obj.lobname = locallob.get(m[0].lobId);
          obj.appname = m[0].appName;
          obj.appid = m[0].appId;
          topopup.push(obj);
        } else if (valueselected != 'rehost' && m[0].rlaneStrategyId != 0) {
          displayelements.push(m);
          var obj = { lobname: '', appname: '', appid: 0 };
          obj.lobname = locallob.get(m[0].lobId);
          obj.appname = m[0].appName;
          obj.appid = m[0].appId;
          aa.push(obj);
        }
      });
      if (aa.length > 0) {
        topopup = aa;
      }
      var dref = reftodilog.open(ChartPopupComponent, {
        height: '75%',
        width: '60%',
        disableClose: false,
        data: {
          dataKey: topopup,
          title: valueselected,
          Applicationcriticalitydata: true,
          Datacriticalitydata: false,
          piechartname: 'Rehost',
        },
      });
    });
  }

  Replatformdata() {
    // debugger;
    let chartdivphysical = am4core.create('Replatformdata', am4charts.PieChart);
    let resultphysical = { migration_Strategy: '', num: 0 };
    let physicaldata = [];
    resultphysical.num = this.replatformcount;
    resultphysical.migration_Strategy = 'Replatform';
    physicaldata.push(resultphysical);
    resultphysical = { migration_Strategy: '', num: 0 };
    resultphysical.num = this.rlanecount;
    resultphysical.migration_Strategy = 'total';
    physicaldata.push(resultphysical);

    chartdivphysical.data = physicaldata;

    let pieSeriesarch = chartdivphysical.series.push(new am4charts.PieSeries());
    pieSeriesarch.dataFields.value = 'num';
    pieSeriesarch.dataFields.category = 'migration_Strategy';
    // chartdivphysical.legend = new am4charts.Legend();

    pieSeriesarch.ticks.template.disabled = true;
    pieSeriesarch.alignLabels = false;
    pieSeriesarch.labels.template.text = '{value}';
    pieSeriesarch.labels.template.fontWeight = "bold";
    pieSeriesarch.labels.template.radius = am4core.percent(-40);

    pieSeriesarch.colors.list = [
      am4core.color('#CED2D9'),
      am4core.color('#AAB5CA'),
      am4core.color('#9DB0D8'),
      am4core.color('#81A9F8'),
      am4core.color('#5188F6'),
      am4core.color('#3A79F8'),
    ];
    pieSeriesarch.slices.template.cursorOverStyle = am4core.MouseCursorStyle.pointer;

    let reftodilog = this.dialogue;
    let valueselected;
    let displayelements = [];
    let list = this.CAAppMaster;
    let locallob = this.lobmap;
    let topopup = [];
    let aa = [];

    pieSeriesarch.slices.template.events.on('hit', function (ev) {
      displayelements = [];
      valueselected = ev.target.dataItem.properties.category;
      topopup = [];
      aa = [];
      list.map((m) => {
        if (m[0].rlaneStrategyId == 3 && valueselected == 'Replatform') {
          displayelements.push(m);
          var obj = { lobname: '', appname: '', appid: 0 };
          obj.lobname = locallob.get(m[0].lobId);
          obj.appname = m[0].appName;
          obj.appid = m[0].appId;
          topopup.push(obj);
        } else if (valueselected != 'Replatform' && m[0].rlaneStrategyId != 0) {
          displayelements.push(m);
          var obj = { lobname: '', appname: '', appid: 0 };
          obj.lobname = locallob.get(m[0].lobId);
          obj.appname = m[0].appName;
          obj.appid = m[0].appId;
          aa.push(obj);
        }
      });
      if (aa.length > 0) {
        topopup = aa;
      }
      var dref = reftodilog.open(ChartPopupComponent, {
        height: '75%',
        width: '60%',
        disableClose: false,
        data: {
          dataKey: topopup,
          title: valueselected,

          piechartname: 'Replatform',
        },
      });
    });
  }

  Repurchasingdata() {
    // debugger;
    let chartdivphysical = am4core.create('Replacedata', am4charts.PieChart);
    let resultphysical = { migration_Strategy: '', num: 0 };
    let physicaldata = [];
    resultphysical.num = this.replacecount;
    resultphysical.migration_Strategy = 'Replace';
    physicaldata.push(resultphysical);
    resultphysical = { migration_Strategy: '', num: 0 };
    resultphysical.num = this.rlanecount;
    resultphysical.migration_Strategy = 'total';
    physicaldata.push(resultphysical);

    chartdivphysical.data = physicaldata;

    let pieSeriesarch = chartdivphysical.series.push(new am4charts.PieSeries());
    pieSeriesarch.dataFields.value = 'num';
    pieSeriesarch.dataFields.category = 'migration_Strategy';
    // chartdivphysical.legend = new am4charts.Legend();

    pieSeriesarch.ticks.template.disabled = true;
    pieSeriesarch.alignLabels = false;
    pieSeriesarch.labels.template.text = '{value}';
    pieSeriesarch.labels.template.fontWeight = "bold";
    pieSeriesarch.labels.template.radius = am4core.percent(-40);

    pieSeriesarch.colors.list = [
      am4core.color('#CED2D9'),
      am4core.color('#AAB5CA'),
      am4core.color('#9DB0D8'),
      am4core.color('#81A9F8'),
      am4core.color('#5188F6'),
      am4core.color('#3A79F8'),
    ];
    pieSeriesarch.slices.template.cursorOverStyle = am4core.MouseCursorStyle.pointer;

    let reftodilog = this.dialogue;
    let valueselected;
    let displayelements = [];
    let list = this.CAAppMaster;
    let locallob = this.lobmap;
    let topopup = [];
    let aa = [];

    pieSeriesarch.slices.template.events.on('hit', function (ev) {
      displayelements = [];
      valueselected = ev.target.dataItem.properties.category;
      topopup = [];
      aa = [];
      list.map((m) => {
        if (m[0].rlaneStrategyId == 6 && valueselected == 'Replace') {
          displayelements.push(m);
          var obj = { lobname: '', appname: '', appid: 0 };
          obj.lobname = locallob.get(m[0].lobId);
          obj.appname = m[0].appName;
          obj.appid = m[0].appId;
          topopup.push(obj);
        } else if (valueselected != 'Replace' && m[0].rlaneStrategyId != 0) {
          displayelements.push(m);
          var obj = { lobname: '', appname: '', appid: 0 };
          obj.lobname = locallob.get(m[0].lobId);
          obj.appname = m[0].appName;
          obj.appid = m[0].appId;
          aa.push(obj);
        }
      });
      if (aa.length > 0) {
        topopup = aa;
      }
      var dref = reftodilog.open(ChartPopupComponent, {
        height: '75%',
        width: '60%',
        disableClose: false,
        data: {
          dataKey: topopup,
          title: valueselected,

          piechartname: 'Replace',
        },
      });
    });
  }

  Rearchitecting() {
    let chartdivphysical = am4core.create(
      this.chartElement.nativeElement,
      am4charts.PieChart
    );
    let resultphysical = { migration_Strategy: '', num: 0 };
    let physicaldata = [];
    resultphysical.num = this.rearchiturecount;
    resultphysical.migration_Strategy = 'Rearchitect';
    physicaldata.push(resultphysical);
    resultphysical = { migration_Strategy: '', num: 0 };
    resultphysical.num = this.rlanecount;
    resultphysical.migration_Strategy = 'total';
    physicaldata.push(resultphysical);

    chartdivphysical.data = physicaldata;

    let pieSeriesarch = chartdivphysical.series.push(new am4charts.PieSeries());
    pieSeriesarch.dataFields.value = 'num';
    pieSeriesarch.dataFields.category = 'migration_Strategy';
    // chartdivphysical.legend = new am4charts.Legend();

    pieSeriesarch.ticks.template.disabled = true;
    pieSeriesarch.alignLabels = false;
    pieSeriesarch.labels.template.text = '{value}';
    pieSeriesarch.labels.template.fontWeight = "bold";
    pieSeriesarch.labels.template.radius = am4core.percent(-40);

    pieSeriesarch.colors.list = [
      am4core.color('#CED2D9'),
      am4core.color('#AAB5CA'),
      am4core.color('#9DB0D8'),
      am4core.color('#81A9F8'),
      am4core.color('#5188F6'),
      am4core.color('#3A79F8'),
    ];
    pieSeriesarch.slices.template.cursorOverStyle = am4core.MouseCursorStyle.pointer;

    let reftodilog = this.dialogue;
    let valueselected;
    let displayelements = [];
    let list = this.CAAppMaster;
    let locallob = this.lobmap;
    let topopup = [];
    let aa = [];

    pieSeriesarch.slices.template.events.on('hit', function (ev) {
      displayelements = [];
      valueselected = ev.target.dataItem.properties.category;
      topopup = [];
      aa = [];
      list.map((m) => {
        if (m[0].rlaneStrategyId == 4 && valueselected == 'Rearchitect') {
          displayelements.push(m);
          var obj = { lobname: '', appname: '', appid: 0 };
          obj.lobname = locallob.get(m[0].lobId);
          obj.appname = m[0].appName;
          obj.appid = m[0].appId;
          topopup.push(obj);
        } else if (valueselected != 'Rearchitect' && m[0].rlaneStrategyId != 0) {
          displayelements.push(m);
          var obj = { lobname: '', appname: '', appid: 0 };
          obj.lobname = locallob.get(m[0].lobId);
          obj.appname = m[0].appName;
          obj.appid = m[0].appId;
          aa.push(obj);
        }
      });
      if (aa.length > 0) {
        topopup = aa;
      }
      var dref = reftodilog.open(ChartPopupComponent, {
        height: '75%',
        width: '60%',
        disableClose: false,
        data: {
          dataKey: topopup,
          title: valueselected,

          piechartname: 'Rearchitect',
        },
      });
    });
  }

  Retaindata() {
    let chartdivphysical = am4core.create('Retaindata', am4charts.PieChart);
    let resultphysical = { migration_Strategy: '', num: 0 };
    let physicaldata = [];
    resultphysical.num = this.retaincount;
    resultphysical.migration_Strategy = 'Retain';
    physicaldata.push(resultphysical);
    resultphysical = { migration_Strategy: '', num: 0 };
    resultphysical.num = this.rlanecount;
    resultphysical.migration_Strategy = 'total';

    physicaldata.push(resultphysical);

    chartdivphysical.data = physicaldata;

    let pieSeriesarch = chartdivphysical.series.push(new am4charts.PieSeries());
    pieSeriesarch.dataFields.value = 'num';
    pieSeriesarch.dataFields.category = 'migration_Strategy';
    // chartdivphysical.legend = new am4charts.Legend();

    pieSeriesarch.ticks.template.disabled = true;
    pieSeriesarch.alignLabels = false;
    pieSeriesarch.labels.template.text = '{value}';
    pieSeriesarch.labels.template.fontWeight = "bold";
    pieSeriesarch.labels.template.radius = am4core.percent(-40);

    pieSeriesarch.colors.list = [
      am4core.color('#CED2D9'),
      am4core.color('#AAB5CA'),
      am4core.color('#9DB0D8'),
      am4core.color('#81A9F8'),
      am4core.color('#5188F6'),
      am4core.color('#3A79F8'),
    ];
    pieSeriesarch.slices.template.cursorOverStyle = am4core.MouseCursorStyle.pointer;

    let reftodilog = this.dialogue;
    let valueselected;
    let displayelements = [];
    let list = this.CAAppMaster;
    let locallob = this.lobmap;
    let topopup = [];
    let aa = [];

    pieSeriesarch.slices.template.events.on('hit', function (ev) {
      displayelements = [];
      valueselected = ev.target.dataItem.properties.category;
      topopup = [];
      aa = [];
      list.map((m) => {
        if (m[0].rlaneStrategyId == 2 && valueselected == 'Retain') {
          displayelements.push(m);
          var obj = { lobname: '', appname: '', appid: 0 };
          obj.lobname = locallob.get(m[0].lobId);
          obj.appname = m[0].appName;
          obj.appid = m[0].appId;
          topopup.push(obj);
        } else if (valueselected != 'Retain' && m[0].rlaneStrategyId != 0) {
          displayelements.push(m);
          var obj = { lobname: '', appname: '', appid: 0 };
          obj.lobname = locallob.get(m[0].lobId);
          obj.appname = m[0].appName;
          obj.appid = m[0].appId;
          aa.push(obj);
        }
      });
      if (aa.length > 0) {
        topopup = aa;
      }
      var dref = reftodilog.open(ChartPopupComponent, {
        height: '75%',
        width: '60%',
        disableClose: false,
        data: {
          dataKey: topopup,
          title: valueselected,

          piechartname: 'Retain',
        },
      });
    });
  }

  Retire() {
    let chartdivphysical = am4core.create('Retiredata', am4charts.PieChart);
    let resultphysical = { migration_Strategy: '', num: 0 };
    let physicaldata = [];
    resultphysical.num = this.retirecount;
    resultphysical.migration_Strategy = 'ReBuild';
    physicaldata.push(resultphysical);
    resultphysical = { migration_Strategy: '', num: 0 };
    resultphysical.num = this.rlanecount;
    resultphysical.migration_Strategy = 'total';
    physicaldata.push(resultphysical);

    chartdivphysical.data = physicaldata;

    let pieSeriesarch = chartdivphysical.series.push(new am4charts.PieSeries());
    pieSeriesarch.dataFields.value = 'num';
    pieSeriesarch.dataFields.category = 'migration_Strategy';
    // chartdivphysical.legend = new am4charts.Legend();

    pieSeriesarch.ticks.template.disabled = true;
    pieSeriesarch.alignLabels = false;
    pieSeriesarch.labels.template.text = '{value}';
    pieSeriesarch.labels.template.fontWeight = "bold";
    pieSeriesarch.labels.template.radius = am4core.percent(-40);

    pieSeriesarch.colors.list = [
      am4core.color('#CED2D9'),
      am4core.color('#AAB5CA'),
      am4core.color('#9DB0D8'),
      am4core.color('#81A9F8'),
      am4core.color('#5188F6'),
      am4core.color('#3A79F8'),
    ];
    pieSeriesarch.slices.template.cursorOverStyle = am4core.MouseCursorStyle.pointer;

    let reftodilog = this.dialogue;
    let valueselected;
    let displayelements = [];
    let list = this.CAAppMaster;
    let locallob = this.lobmap;
    let topopup = [];
    let aa = [];

    pieSeriesarch.slices.template.events.on('hit', function (ev) {
      displayelements = [];
      valueselected = ev.target.dataItem.properties.category;
      topopup = [];
      aa = [];
      list.map((m) => {
        if (m[0].rlaneStrategyId == 5 && valueselected == 'ReBuild') {
          displayelements.push(m);
          var obj = { lobname: '', appname: '', appid: 0 };
          obj.lobname = locallob.get(m[0].lobId);
          obj.appname = m[0].appName;
          obj.appid = m[0].appId;
          topopup.push(obj);
        } else if (valueselected != 'ReBuild' && m[0].rlaneStrategyId != 0) {
          displayelements.push(m);
          var obj = { lobname: '', appname: '', appid: 0 };
          obj.lobname = locallob.get(m[0].lobId);
          obj.appname = m[0].appName;
          obj.appid = m[0].appId;
          aa.push(obj);
        }
      });
      if (aa.length > 0) {
        topopup = aa;
      }
      var dref = reftodilog.open(ChartPopupComponent, {
        height: '75%',
        width: '60%',
        disableClose: false,
        data: {
          dataKey: topopup,
          title: valueselected,

          piechartname: 'ReBuild',
        },
      });
    });
  }

  getrlanedata() {

    this.Service.getmigrationdata(this.orgId).subscribe((data) => {
      this.Rlane = data;


      this.Rlane.map((m) => {
        if (m.migration_Strategy == 'Rehost') {
          this.rehostcount = m.num;
        }
        if (m.migration_Strategy == 'Replatform') {
          this.replatformcount = m.num;
        }

        if (m.migration_Strategy == 'Replace') {
          this.replacecount = m.num;
        }

        if (m.migration_Strategy == 'Rearchitect') {
          this.rearchiturecount = m.num;
        }
        if (m.migration_Strategy == 'Retain') {
          this.retaincount = m.num;
        }
        if (m.migration_Strategy == 'ReBuild') {
          this.retirecount = m.num;
        }
      });
    });

    this.Rearchitecting();
    this.Repurchasingdata();

    this.Replatformdata();
    this.Rehostingdata();
    this.Retaindata();
    this.Retire();
  }

  appnamechanged(event, lobname) {
    let selectedappid = '';
    let selectedlobid = '';

    this.CAAppMaster.map((m) => {
      if (m[0].appName == event) {
        selectedappid = m[0].appId;
      }
    });
    this.loblist.map((m) => {
      if (lobname == m.lobName) {
        selectedlobid = m.lobName;
      }
    });
    sessionStorage.removeItem('apploblist');
    sessionStorage.removeItem('appidfrompopup');
    sessionStorage.removeItem('appnamefrompopup');

    sessionStorage.setItem('apploblist', selectedlobid);
    sessionStorage.setItem('appidfrompopup', selectedappid);
    sessionStorage.setItem('appnamefrompopup', event);
    this.router.navigate(['/appque']);
  }

  createtreechart() {
    let chartdata = [];
    // let lastcode = 109;
    // let middlecode = 65;
    let lastcode = 215;
    let middlecode = 163;
    this.moveGroupData.map((m, i) => {
      // console.log("i----",i)
      let colour = 'rgb(208,';

      if (i != 0) {
        middlecode = middlecode + 12;
        lastcode = lastcode + 15;
      }
      // colour = colour + middlecode + ',' + lastcode + ')';
      colour ="#D0A3D7";

      // console.log("color----", colour);
      let obj = { name: '', value: 0, color: '' };
      obj.name = m.moveGroupName;
      obj.value = parseInt(m.moveGroupAppCount);
      obj.color = colour;
      chartdata.push(obj);
      console.log(chartdata[i], "chartdataaaaa")
    })
    // console.log("chartdata===",chartdata)
    // if (chartdata.value > 0) {
    //   this.appSurvey = true;
    // }

    var chart = am4core.create("MoveGroupChart", am4charts.TreeMap);
    // chartdata[1].color = '#DCBBE1'
    // chartdata[2].color = '#E8D1EB'
    // chartdata[3].color = '#F4E9F5'
    // console.log("chartData",chartdata)
    // chart.navigationBar = new am4charts.NavigationBar();
    // chart.navigationBar.links.template.fill = am4core.color("#691E06");
    // chart.navigationBar.activeLink.fill = am4core.color("#8F250C");
    chart.logo.dispose()
    chart.data = chartdata;
    chart.dataFields.color = "color";
    chart.dataFields.value = "value";
    chart.dataFields.name = "name";
    chart.layoutAlgorithm = chart.squarify;
    console.log("chart.dataFields.color",chart.dataFields)

    var level1 = chart.seriesTemplates.create("0");
    var level1_bullet = level1.bullets.push(new am4charts.LabelBullet());
    level1_bullet.locationY = 0.5;
    level1_bullet.locationX = 0.5;
    level1_bullet.label.text = " {value} Applications ";
    // level1_bullet.label.fill = am4core.color("#000000");

    var level2 = chart.seriesTemplates.create("0");
    var level2_bullet = level2.bullets.push(new am4charts.LabelBullet());
    level2_bullet.locationY = 0.8;
    level2_bullet.locationX = 0.2;
    level2_bullet.label.text = "{name}  ";
    // level2_bullet.label.fill = am4core.color("#000000");

    let arraytodisplay = [];
    let reftodilog = this.dialogue;
    let Applications = [];
    Applications = this.groupAppData;
    let localMoveGroupMap = this.groupmap;
    level1.columns.template.events.on("hit", function (ev) {
      let name = ev.target._dataItem.dataContext['properties'].name;
      arraytodisplay = []

      let MoveGroupId = localMoveGroupMap.get(name);
      Applications.map(m => {
        if (m.move_Group_Id == MoveGroupId) {
          let obj = { appId: '', appName: '', lobName: '' }
          obj.appId = m.app_Id;
          obj.appName = m.app_Name;
          obj.lobName = m.lob_Name;
          arraytodisplay.push(obj);
        }
      });

      var dref = reftodilog.open(MoveGroupChartPopUpComponent, {
        height: '75%',
        width: '60%',
        disableClose: false,
        data: {
          dataKey: arraytodisplay,
          title: name,
          piechartname: 'Application by MoveGroup',
        },
      });

    });

  }

  ROIStackBar() {
    this.Service.ROIProgressBar(this.orgId).subscribe(data => {
      this.progressBarData = data;
      if (this.progressBarData.length != 0) {
        this.progressBarCount = false;
        this.progressBarData.map(m => {
          let obj = { name: 'Saving : ', value: '' }
          obj.value = m.roi_calculated;
          this.values.push(obj);
          let obj1 = { name: 'Investment : ', value: '' }
          obj1.value = m.cost_of_Migration;
          this.values.push(obj1);
          console.log(this.values, "values of roi")
          console.log(this.progressBarData, "ROI Progrss bar data")
          let wpercent = 0;
          let outerdiv = document.getElementById('dynamicdivReturn');
          let outerdivtext = document.getElementById('dynamicdivtextReturn');
          let outerdivvalue = document.getElementById('dynamicdivvalue');
          outerdiv.style.width = '250px';
          outerdiv.style.height = '32px';
          outerdivtext.style.width = '250px';
          outerdivvalue.style.width = '250px';
          this.values.map((m) => {
            wpercent = wpercent + parseInt(m.value);
          });

          this.values.map((m, i) => {
            let name = m.name.split(' ').join('');
            let value = '$' + (m.value * 3);
            var nametag = document.createElement('span');
            var innerdiv = document.createElement('div');
            var nametagtext = document.createElement('span');
            var innerdivtext = document.createElement('div');
            var nametagvalue = document.createElement('span');
            var innerdivvalue = document.createElement('div');
            let ppercent = (m.value / wpercent) * 100;
            innerdiv.setAttribute('id', name);
            innerdivtext.setAttribute('idtext', name);
            innerdivvalue.setAttribute('idvalue', value);
            nametag.innerText = name;
            innerdiv.style.paddingRight = ppercent / 2 + '%';
            innerdiv.style.paddingLeft = ppercent / 2 + '%';

            nametagtext.innerText = name;
            innerdivtext.style.paddingRight = ppercent + '%';
            // innerdivtext.style.paddingLeft = ppercent / 2 + '%';

            nametagvalue.innerText = value;
            innerdivvalue.style.paddingRight = ppercent + '%';
            // innerdivvalue.style.paddingLeft = ppercent  + '%';

            innerdiv.style.cursor = 'pointer';
            innerdivtext.innerText = name;
            innerdiv.innerText = name;
            innerdivvalue.innerText = value;
            if (i % 2 == 0) {
              innerdiv.style.backgroundColor = '#73A20A';
              innerdiv.style.color = 'transparent';
              innerdivtext.style.backgroundColor = 'transparent';
              innerdivtext.style.color = 'black';
              innerdivvalue.style.backgroundColor = 'transparent';
              innerdivvalue.style.color = 'black';
              innerdivvalue.style.backgroundColor = 'transparent';
            } else {
              innerdiv.style.backgroundColor = '#0C59E9';
              innerdiv.style.color = 'transparent';
              innerdivtext.style.backgroundColor = 'transparent';
              innerdivtext.style.color = 'black';
              innerdivvalue.style.backgroundColor = 'transparent';
              innerdivvalue.style.color = 'black';
              innerdivvalue.style.backgroundColor = 'transparent';
            }
            outerdiv.appendChild(innerdiv);
            outerdivtext.appendChild(innerdivtext);
            outerdivvalue.appendChild(innerdivvalue);
          });
        });
      }
    });
  }

  takeSurvey() {
    this.router.navigate(['/ROI']);
  }
  NotifyUser(email) {
    this.userList = [];
    this.Service.getUsersList(this.orgId, this.productId).subscribe(
      data => {
        this.userList = data;

        this.userList.map(m => {
          this.AppCountArray.map(f => {

            if (m['email_Id'] == email && f.delegatedToEmailId == email) {
              let obj = { delegatedToEmailId: '', password: '', delegatedByEmailId: '', delegatedBy: '', applications: [], };
              obj.delegatedToEmailId = email;
              obj.password = atob(m['password']);
              obj.delegatedByEmailId = f.delegatedByEmailID;
              obj.delegatedBy = f.delegatedBy;
              obj.applications = f.notactiveapplications;
              this.emailpwordcombo = [];
              this.emailpwordcombo.push(obj);
              console.log(this.emailpwordcombo, "sss");

            }
          })
        })


        this.Service.notifyDelegateUser(this.emailpwordcombo).subscribe(data => {
          this._snackBar.open("Email Notification sent Successfully ", 'X');
        }, (error) => {
          alert(error)
          this._snackBar.open(error, 'X');

        }, () => {
        }
        );
      });
  }

  delegateSurveyStatus() {
    this.Service.GetDelegateSurveyDetails(this.orgId).subscribe((data: any[]) => {
      this.SurveyDetails = data;
      // console.log(this.SurveyDetails, "survey details")
      let marr = [];

      this.SurveyDetails.map((m, i) => {
        let userobj = { userId: '', userName: '', delegatedBy: '', assignedByMailId: '', assignedToMailId: '', app: [] };
        let application = { appname: '', activestatus: '' };
        if (i == 0) {
          userobj = { userId: '', userName: '', delegatedBy: '', assignedByMailId: '', assignedToMailId: '', app: [] };
          application = { appname: '', activestatus: '' };
          application.appname = m.app_Name;
          application.activestatus = m.app_Suv_Status;
          userobj.userId = m.usr_Id;
          userobj.userName = m.assigned_To;
          userobj.delegatedBy = m.assigned_By;
          userobj.assignedByMailId = m.assigned_By_MailId;
          userobj.assignedToMailId = m.assigned_To_MailId;
          userobj.app.push(application);
          marr.push(userobj);
          // console.log(marr,"lob with applications ")
        } else {
          marr.map((f) => {
            userobj = { userId: '', userName: '', delegatedBy: '', assignedByMailId: '', assignedToMailId: '', app: [] };
            application = { appname: '', activestatus: '' };
            if (f.userId == m.usr_Id) {
              application.appname = m.app_Name;
              application.activestatus = m.app_Suv_Status;
              f.app.push(application);
            } else {
              userobj = { userId: '', userName: '', delegatedBy: '', assignedByMailId: '', assignedToMailId: '', app: [] };
              application = { appname: '', activestatus: '' };
              userobj.userId = m.usr_Id;
              userobj.userName = m.assigned_To
              userobj.delegatedBy = m.assigned_By;
              userobj.assignedByMailId = m.assigned_By_MailId;
              userobj.assignedToMailId = m.assigned_To_MailId;
              application.appname = m.app_Name;
              application.activestatus = m.app_Suv_Status;
              userobj.app.push(application);
            }
          });
          marr.push(userobj);

        }
        // console.log(marr,"lob with applications, else works ")
      });
      marr.filter((f) => {
        if (f.userId !== '') {
          this.userArray.push(f);
        }
      });
      // console.log(this.userArray, "model object of delegate user ");

      // let newarrtohtml = [];
      this.userArray.filter((f, i) => {
        if (i == 0) {
          this.delegateArray.push(f);
        }
        else if (f.userId !== this.userArray[i - 1].userId) {
          this.delegateArray.push(f);
        }
      });
      // console.log(this.delegateArray, "delegateArrayyyyy")
      // newarrtohtml = this.delegateArray;
      let res = [];
      this.delegateArray.map((m, i) => {
        if (i == 0) {
          res.push(m);
        }
        else {
          let pusar = [];
          for (let j = 0; j < res.length; j++) {
            let pushing = true;
            if (res[j].userId != m.userId) {
              pushing = true; pusar.push(pushing);
            } else {
              pushing = false; pusar.push(pushing);
            }
          }

          if (!pusar.includes(false)) {
            res.push(m);
          }
        }
      });
      this.delegateArray = res;
      // console.log(this.delegateArray, "delegateArrayyyyy")

      this.delegateArray.map((m) => {
        this.delegateSurveyObject = {
          userId: '',
          userName: '',
          delegatedBy: '',
          total: '',
          active: '',
          notactiveapplications: [],
          delegatedToEmailId: '',
          delegatedByEmailID: ''
        };
        this.delegateSurveyObject.total = m.app.length;
        this.delegateSurveyObject.userId = m.userId;
        this.delegateSurveyObject.delegatedBy = m.delegatedBy;
        this.delegateSurveyObject.userName = m.userName;
        this.delegateSurveyObject.delegatedToEmailId = m.assignedToMailId;
        this.delegateSurveyObject.delegatedByEmailID = m.assignedByMailId;

        let c = 0;
        m.app.map((h) => {
          if (h.activestatus == 1) {
            c = c + 1;
          } else {
            this.delegateSurveyObject.notactiveapplications.push(h);
          }
        });
        this.delegateSurveyObject.active = c + '';
        this.AppCountArray.push(this.delegateSurveyObject);

        // console.log(this.AppCountArray, "application count in delegate survey")
      });
    });

  }
}
