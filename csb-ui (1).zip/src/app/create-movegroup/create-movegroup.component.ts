import { Component, OnInit, Inject } from '@angular/core';
import { HTTPService } from '../service/httpService.service';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Validators, FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { movegroup } from '../model/movegroup';
import { version } from 'punycode';
import { movegroupmapping } from '../model/movegroupmapping';
import { MatSnackBar } from '@angular/material/snack-bar';
import * as pageText from 'src/app/create-movegroup/constants/create-movegroup.json';
@Component({
  selector: 'app-create-movegroup',
  templateUrl: './create-movegroup.component.html',
  styleUrls: ['./create-movegroup.component.css']
})
export class CreateMovegroupComponent implements OnInit {
  pageText=(pageText as any).default;
  [x: string]: any;
  reusechartvalue: any;
  search: string;
   chartvalue: any;
  CAAppMaster: any;
  orgId: any;
  RehostData:any;
  reuseRehostData:any;

  form: FormGroup;
  moveGroupForm:FormGroup;
  movegroup = new movegroup();
  applist=[];
  newgrpid=[];
  groupList:any;
  versionNum: number;
  latestgrpid:0;
  //moveGroupName: movegroup[];
  submitted=false;
  constructor(private Service: HTTPService, @Inject(MAT_DIALOG_DATA) public data: any,
  private formBuilder: FormBuilder,
  private _snackBar: MatSnackBar,
  public dailogRefCreate: MatDialogRef<CreateMovegroupComponent>) {
    
      
   
   }
  






  ngOnInit(): void {
    
    this.orgId=sessionStorage.getItem("orgId");
//Get the Rehost application data
    this.Service.getMoveGroupRehost(this.orgId).subscribe((data:any[]) => {
      this.RehostData = data;
      this.reuseRehostData = data;
      console.log(this.RehostData,'cappmasterrrrrrrrrrrrrr rehsttttttttttttttttttttr');
     
    });
  
}

moveGroupForm1 = this.formBuilder.group({
  grpName:[this.movegroup['Move_Group_Name'], Validators.required]
  
});


//create move group
createmovegroup(){
  
  this.submitted= true;
if(this.moveGroupForm1.invalid){

  
    this._snackBar.open('Please Enter Valid Group Name', 'X');
  }
  else{

  this.movegroup.moveGroupId;
  this.movegroup.moveGroupName=this.moveGroupForm1.value.grpName;//fetched from the form
  this.movegroup.migrationStartdt=new Date().toISOString();
  this.movegroup.migrationEnddt=new Date().toISOString();;
  this.movegroup.recInsDt=new Date().toISOString();
  this.movegroup.recUpdDt=new Date().toISOString();
  //console.log(movegroup,"movegroupdetaillllllssssssssssssssssssssssss")
  
//Http service to create move group
if(this.applist.length==0)
  {
  
    this._snackBar.open('Please Select atleast one application', 'X');
  }
  else{

  this.Service.createMoveGroup(this.movegroup,this.orgId).subscribe(data=>{
    
  
//Service to get details of Movegroup to fetch MovegroupId
   this.Service.getMoveGroup(this.orgId).subscribe((data) => {
    this.versionData = new movegroupmapping();
    this.uplodedData=data;
    console.log(this.uplodedData,"uploaded for group data");
    
    this.uplodedData.map(m=>{
            this.versionData.moveGroupID=m[0].moveGroupId;}); //assigning Move group Id
            let appIds=[];
            for(let i in this.applist)//Application list selected by user(check box)
            {
              let obj = {appMasterId:"",moveGroupID:"",recInsDT:"",recUpDT:""}
            // this.versionData.appMasterId =this.applist[i];
            // this.versionData.recInsDT=new Date().toISOString();
            // this.versionData.recUpDT=new Date().toISOString();
            obj.appMasterId=this.applist[i];
            obj.moveGroupID=this.versionData.moveGroupID;
            obj.recInsDT=new Date().toISOString();
            obj.recUpDT=new Date().toISOString();
            appIds.push(obj);
            }

            //service to create move group mapping
   this.Service.createMoveGroupMapping(
   appIds
   ).subscribe(data=>{
    this.dailogRefCreate.close();
   
    this._snackBar.open('Move Group Details saved Successfully', 'close');
  },
  (error) => {
    this._snackBar.open(
      'Could not save MoveGroup Details, Please try again',
      'close'
    );
  });
  



  });
  });
}
  }
}
  //Check box event
checkboxChanged(a,checked){
   
  if(checked){
    this.applist.push(a.app_Master_Id);
  }else{
        if(this.applist.includes(a.app_Master_Id)){
          
          this.applist = this.applist.filter(function(item) {
            return item !== a.app_Master_Id
        });
        }
      }

  console.log(this.applist,"appppidddddddddddddddddddddddddddddddddddddddddddd")
}

SearchFilter(){

  if(this.search==''){
    this.RehostData = this.reuseRehostData; 
}
else{
  this.RehostData = this.RehostData.filter(res=>{
    let appname = res.app_Name.toLocaleLowerCase().includes(this.search.toLocaleLowerCase());
       
    if(appname){
      return appname
    }
  });
}

}
}