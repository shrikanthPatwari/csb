import { Component, OnInit, inject } from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef, MatDialog} from "@angular/material/dialog";
import { FormGroup } from '@angular/forms';
import { Inject } from '@angular/core';
import { Router } from '@angular/router';
import { VersionMapPopupComponent } from '../version-map-popup/version-map-popup.component';
import { HTTPService } from '../service/httpService.service';



@Component({
  selector: 'app-file-upload-pop-up',
  templateUrl: './file-upload-pop-up.component.html',
  styleUrls: ['./file-upload-pop-up.component.css']
})

export class FileUploadPopUpComponent implements OnInit {
  form:FormGroup;
  description:string;
  mappedversionData: any;
  orgId: string;
  constructor(private dialogRef: MatDialogRef<FileUploadPopUpComponent>,@Inject(MAT_DIALOG_DATA) public data: any,private router: Router,
  private Service: HTTPService,private dialog: MatDialog) { }

  ngOnInit(): void {
    console.log("From popup component");
    console.log(this.data);
    // this.orgId=sessionStorage.getItem("orgId");
 
  }
  closeModal() {
    this.dialogRef.close();
  }
  actionFunction() {
    alert("You have logged out.");
    this.closeModal();
  }

  redirectToCSB(){
    this.dialogRef.close();
    this.router.navigate(['CsbDashboard']);
  }

  mapVersions(){
    this.router.navigate(['versionsUpdate']);
    this.dialogRef.close();
  }
}
