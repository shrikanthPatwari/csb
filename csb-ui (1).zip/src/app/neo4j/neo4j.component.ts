import { Component, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import NeoVis from 'neovis.js/dist/neovis.js';
import { SpinnerService } from '../service/spinner/spinner.service';
import { HTTPService } from '../service/httpService.service'; 
import * as pageText from 'src/app/neo4j/constants/neo4j.json';
@Component({
  selector: 'app-neo4j',
  templateUrl: './neo4j.component.html',
  styleUrls: ['./neo4j.component.css']
})
export class Neo4jComponent implements OnInit {
  pageText=(pageText as any).default;
  loblist:any;
  applicationChoosed=false;
  infrChoosed=false;
  processChoosed=false;
  orgId=sessionStorage.getItem("orgId");
  lobValue:any;
serverType=".*";
dataCriticalityApp=".*"
vizdata=[];




 

  orgName:string="";
  constructor(private router: Router,private spinner :SpinnerService,private Service:HTTPService) { }

  ngOnInit(): void {
  
    this.spinner.requestStarted();
    setTimeout(()=>{
      // if(this.vizdata.length == 4 )
      this.spinner.requestEnded();
    },8000)
    this.orgId=sessionStorage.getItem("orgId");
    this.orgName=sessionStorage.getItem("OrgName");
    
    this.deleteNodes();
    this.createNodes();
    this.draw();


    this.Service.getLOBList(this.orgId).subscribe(
      data=>{

        this.loblist=data;
        

    })
    


  }

  handleChange($event){
    this.draw();
  }
  handleChange1($event){
   let b = this.drawinfra();
  
   if(b){
     this.spinner.requestEnded()
   }
  }
  handleChange2($event){
    
    this.draw2(); 
  }

  draw2(){
    // this.spinner.requestStarted();
    // setTimeout(()=>{
    //   this.spinner.requestEnded();
    // },1000)
    
  this.infrChoosed=false;
  this.applicationChoosed=false;
  this.processChoosed=true;
  const config = {
    initial_cypher:`MATCH (n:CaAppMaster) MATCH (t2:CaProcessDatumVersion)  WHERE n.App_Master_Id= t2.App_Master_Id and t2.Org_Id=${this.orgId} MERGE (n)-[r:Application_BusinessOwner]->(t2) return n,t2,r`,
        container_id: "viz",
        // server_url: "neo4j://142.102.27.102:7687",
        // server_user: "test",
        // server_password: "test@1234",
        server_url: "__neo4jurl__",
        server_user: "neo4j",
        server_password: "test@1234",
       
        nodes : {
          shape : 'neo',
          size : 1,
          font : {
              size : 16,
              color : '#ffffff'
          },
          borderWidth : 2
      },

      labels: {
        "CaAppMaster": {
            "caption": "App_Name",
            "size": "pagerank",
            "community": "partition",
            color : '#81A9F8'
        },
        "CaProcessDatumVersion": {
          "caption": "BusinessOwner",          "size": "pagerank",


      }
    },
        relationships: {
       "belongs_to": {
          "thickness": "count",
          "caption": true,
          "color":"#000000"
      }

    },
        arrows: true,
      
    };
    
   
    const viz = new NeoVis(config);
   viz.render();
   
    
    

    
  }
  drawProcessByFilter(){
    this.infrChoosed=false;
    this.applicationChoosed=false;
    this.processChoosed=true;
    const config = {
      initial_cypher:`Match(l:CaLobMaster),(a:CaProcessDatumVersion),(m:CaAppMaster) where l.Lob_Id = m.LOB_Id and m.App_Master_Id = a.App_Master_Id and l.Lob_Id =${this.lobValue} and l.Org_Id=${this.orgId} merge (l)-[r:Lob_BusinessOwner]->(a) return l,a,r`,
          container_id: "viz",
          server_url: "__neo4jurl__",
        server_user: "neo4j",
        server_password: "test@1234",
         
          nodes : {
            shape : 'neo',
            size : 1,
            font : {
                size : 16,
                color : '#ffffff'
            },
            borderWidth : 2
        },
  
        labels: {
          "CaLobMaster": {
              "caption": "Lob_Name",
              "size": "pagerank",
              "community": "partition",
              color : '#81A9F8'
          },
          "CaProcessDatumVersion": {
            "caption": "BusinessOwner",
            "size": "pagerank",
            "community": "partition",
            color : '#81A9F8'
  
        }
      },
          relationships: {
          "Lob_Process": {
            "thickness": "count",
            "caption": true,
            "color":"#000000"
        }
  
      },
          arrows: true,
        
      };
  
      
      const viz = new NeoVis(config);
      console.log(viz);
      viz.render();
      return 1;
  }




  ProcessFilter(){
    if(this.lobValue){
      let c = this.drawProcessByFilter();
      if(c){
        this.spinner.requestEnded();
      }
    }
  }

  infraFilter(){
    if(this.lobValue && this.serverType){
      let c = this.drawInfraByFilter();
      if(c){
        this.spinner.requestEnded();
      }
    }

  }

drawinfra(){
  this.spinner.requestStarted();
    setTimeout(()=>{
      this.spinner.requestEnded();
    },5000)
    
  this.infrChoosed=true;
  this.applicationChoosed=false;
  this.processChoosed=false;
  const config = {
    initial_cypher:`MATCH (t3:infra_mapping) MATCH (t2:CaInfraDatum)  WHERE t2.infra_id= t3.Infra_Id MATCH (t1:CaAppMaster) WHERE t1.App_Master_Id = t3.App_Master_Id and t1.Org_Id=${this.orgId} MERGE (t1)<-[r:infra_new]->(t2) return t1,t2,r`,
        container_id: "viz",
        server_url: "__neo4jurl__",
        server_user: "neo4j",
        server_password: "test@1234",
       
        nodes : {
          shape : 'neo',
          size : 1,
          font : {
              size : 16,
              color : '#ffffff'
          },
          borderWidth : 2
      },

      labels: {
        "CaAppMaster": {
            "caption": "App_Name",
            "size": "pagerank",
            "community": "partition",
            color : '#81A9F8'
        },
        "CaInfraDatum": {
          "caption": "Host_Name",
          "size": "pagerank",


      }
    },
        relationships: {
        "belongs_to": {
          "thickness": "count",
          "caption": true,
          "color":"#000000"
      }

    },
        arrows: true,
      
    };
    this.spinner.requestStarted();
    let test;
    const viz = new NeoVis(config);
     test = viz.render();
    return 1;
    
    
    
}

drawInfraByFilter(){
  this.infrChoosed=true;
  this.applicationChoosed=false;
  this.processChoosed=false;
  const config = {
    initial_cypher:`MATCH (t3:infra_mapping) MATCH (t2:CaInfraDatum)  WHERE t2.infra_id= t3.Infra_Id MATCH (t1:CaAppMaster) WHERE t1.App_Master_Id = t3.App_Master_Id and t1.Org_Id=${this.orgId}  and t1.LOB_Id=${this.lobValue} and t2.Server_Type=~"${this.serverType}" MERGE (t1)<-[r:infra_new]->(t2) return t1,t2,r`,
        container_id: "viz",
        server_url: "__neo4jurl__",
        server_user: "neo4j",
        server_password: "test@1234",
       
        nodes : {
          shape : 'neo',
          size : 1,
          font : {
              size : 16,
              color : '#ffffff'
          },
          borderWidth : 2
      },

      labels: {
        "CaAppMaster": {
            "caption": "App_Name",
            "size": "pagerank",
            "community": "partition",
            color : '#81A9F8'
        },
        "CaInfraDatum": {
          "caption": "Host_Name",
          "size": "pagerank",


      }
    },
        relationships: {
        "belongs_to": {
          "thickness": "count",
          "caption": true,
          "color":"#000000"
      }

    },
        arrows: true,
      
    };

    
    const viz = new NeoVis(config);
    console.log(viz);
    viz.render();
    return 1;
}
loblistchanged(lob){

this.lobValue = lob.value;
}
serverTypeChanged(dropDownValue){
  this.serverType=dropDownValue.value;
}



drawApplicationByFilter(){
  this.infrChoosed=false;
  this.processChoosed=false;
    this.applicationChoosed=true;
   const config = {
      initial_cypher:`MATCH (t3:CaAppMaster) MATCH (t2:CaLobMaster)  WHERE t2.Lob_Id = t3.LOB_Id and t3.Org_Id=${this.orgId}  and t3.Data_Criticality=~"${this.dataCriticalityApp}" and t2.Lob_Id=${this.lobValue} MERGE (t3)-[r:Belong_To]->(t2) return t2,t3,r`,
          container_id: "viz",
          server_url: "__neo4jurl__",
          server_user: "neo4j",
          server_password: "test@1234",
         
          nodes : {
            shape : 'neo',
            size : 1,
        
    
            font : {
                size : 16,
                color : '#ffffff'
            },
            borderWidth : 2
        },
        labels: {
          "CaAppMaster": {
              "caption": "App_Name",
              "size": "pagerank",
              community: "community"
          },
          "CaLobMaster": {
            "caption": "Lob_Name",
            "size": "pagerank",
           
        }
      },
          relationships: {
          "belongs_to": {
            "thickness": "count",
            "caption": true,
            "color":"#000000"
        },
        interaction: {
          navigationButtons: true,
          
      },
  
      },
          arrows: true,
        
      };
      
      const viz = new NeoVis(config);
      
      console.log(viz);
      viz.render();

}

dataCriticality(dropDownValueApp){

  this.dataCriticalityApp=dropDownValueApp.value;
}

applicationFilter(){
  if(this.dataCriticalityApp && this.lobValue){

    this.drawApplicationByFilter();
  }
}

  draw() {
    this.infrChoosed=false;
    this.processChoosed=false;
    this.applicationChoosed=true;
   const config = {
      initial_cypher:`MATCH (t3:CaAppMaster) MATCH (t2:CaLobMaster)  WHERE t2.Lob_Id = t3.LOB_Id and t3.Org_Id=${this.orgId} MERGE (t3)-[r:Belong_To]->(t2) return t2,t3,r`,
          container_id: "viz",
          server_url: "__neo4jurl__",
        server_user: "neo4j",
        server_password: "test@1234",
         
          nodes : {
            shape : 'neo',
            size : 1,
        
    
            font : {
                size : 1,
                color : '#ffffff'
            },
            borderWidth : 2
        },
        labels: {
          "CaAppMaster": {
              "caption": "App_Name",
              "size": "pagerank",
              community: "community"
          },
          "CaLobMaster": {
            "caption": "Lob_Name",
            "size": "pagerank",
           
        }
      },
          relationships: {
          "belongs_to": {
            "thickness": "count",
            "caption": true,
            "color":"#000000"
        },
        interaction: {
          navigationButtons: true,
          
      },
  
      },
          arrows: true,
        
      };
      
      const viz = new NeoVis(config);
      
      console.log(viz);
      viz.render();
  }
  zoomIn() {
    const canvas = document.getElementById('viz');

  } 

  createNodes(){
    let intitalcypherArray=["CALL apoc.load.jdbc('__mysqlurl__','ca_lob_master') YIELD row Create(a:CaLobMaster) set a=row ",
    "CALL apoc.load.jdbc('__mysqlurl__','ca_app_master') YIELD row Create(a:CaAppMaster) set a=row ",
    "CALL apoc.load.jdbc('__mysqlurl__','ca_infra_data') YIELD row Create(a:CaInfraDatum) set a=row ",
    "CALL apoc.load.jdbc('__mysqlurl__','ca_infra_app_mapping') YIELD row Create(a:infra_mapping) set a=row ",
    "CALL apoc.load.jdbc('__mysqlurl__','ca_process_data') YIELD row Create(a:CaProcessDatumVersion) set a=row "]

    intitalcypherArray.map(m=>{
      const config = {
        container_id: "viz",
        server_url: "__neo4jurl__",
        server_user: "neo4j",
        server_password: "test@1234",
  
        interaction: {
          hover: true,
          keyboard: {
              enabled: true,
              bindToWindow: false
          }, 
          navigationButtons: true,
          tooltipDelay: 1000000,
          hideEdgesOnDrag: true,
          zoomView: true
      },
      zoomView:true,
        "labels": {
          "Lob_Name": {
            "caption":"App System",
            "font": {
              "size":36,
              "color":"#000000"
          },
          },
        },
        "LOB": {
          "thickness": "weight",
          "caption": true 
      },
        initial_cypher:m
        
    };
  const viz = new NeoVis(config);
  this.vizdata.push(viz);
  viz.render();
    })
    
  
  }


  deleteNodes(){
    let intitalcypherArray=["MATCH (n:CaAppMaster) DETACH DELETE n",
    "MATCH (n:CaInfraDatum) DETACH DELETE n",
    "MATCH (n:infra_mapping) DETACH DELETE n",
    "MATCH (n:CaLobMaster) DETACH DELETE n",
    "MATCH (n:CaProcessDatumVersion) DETACH DELETE n",
  ]
    intitalcypherArray.map(m=>{
      const config = {
        container_id: "viz",
        server_url: "__neo4jurl__",
        server_user: "neo4j",
        server_password: "test@1234",
        interaction: {
          hover: true,
          keyboard: {
              enabled: true,
              bindToWindow: false
          }, 
          navigationButtons: true,
          tooltipDelay: 1000000,
          hideEdgesOnDrag: true,
          zoomView: true
      },
      zoomView:true,
        "labels": {
          "Lob_Name": {
            "caption":"App System",
            "font": {
              "size":36,
              "color":"#000000"
          },
          },
        },
        "LOB": {
          "thickness": "weight",
          "caption": true 
      },
        initial_cypher:m
        
    };
  const viz = new NeoVis(config);
  viz.render();
    })
    
  
  }


  
}

