import { Component, Inject, OnInit, Optional } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { HTTPService } from '../service/httpService.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-createapplication',
  templateUrl: './createapplication.component.html',
  styleUrls: ['./createapplication.component.css'],
})
export class CreateapplicationComponent implements OnInit {
  infraid: any;
  submitted: boolean;
  firstformgroup: FormGroup;
  infraformgroup:FormGroup;
  processformgroup: FormGroup;
  processData: any;
  processList: any;

  constructor(
    private http: HTTPService,
    private _snackBar: MatSnackBar,
    public dialogRef: MatDialogRef<CreateapplicationComponent>,
    @Optional() @Inject(MAT_DIALOG_DATA) public data: any
  ) {}
  lobname: any;
  applist: any;
  loblist: any;
  orgName: any;
  lobId: any;
  viewtype:String;
  caAppMasterData:any;
  cainfraData:any;
  orgId:any;
  ngOnInit(): void {
    this.orgId=sessionStorage.getItem("orgId");
    this.viewtype = this.data.viewtype;
    this.caAppMasterData = this.data.caAppMasterData;
    this.cainfraData = this.data.cainfraData;
    this.processData =  this.data.processData;
    console.log(this.caAppMasterData,"caAppMasterData to pop up");
    console.log(this.cainfraData,"infraData to pop up");
    this.http.getProcessApps(this.orgId).subscribe((data) => {
      this.processList = data;
      console.log(this.processList,"processappsssssss")
    });
    
    this.firstformgroup = new FormGroup({
      appId: new FormControl('', [Validators.required]),
      appName: new FormControl('', [Validators.required]),
      lobId: new FormControl('', [Validators.required]),
      orgId: new FormControl(parseInt(sessionStorage.getItem('orgId')), [
        Validators.required,
      ]),
    });
    this.infraformgroup = new FormGroup({
      hostName: new FormControl('', [Validators.required]),
      ipAddress: new FormControl('', [Validators.required]),
      appMasterId: new FormControl('', [Validators.required]),
      orgId: new FormControl(parseInt(sessionStorage.getItem('orgId')), [Validators.required,]),
      infraId: new FormControl('', [Validators.required]),
    });

    this.processformgroup = new FormGroup({
      businessOwner: new FormControl('', [Validators.required]),
      businessManager: new FormControl('', [Validators.required]),
      appMasterId: new FormControl('' , [Validators.required]),
      orgId: new FormControl(parseInt(sessionStorage.getItem('orgId')), [Validators.required,]),
    });


     // this.http.getLOBList(this.orgId).subscribe((data) => {
      this.http.getLobs(this.orgId).subscribe((data) => {
      this.loblist = data;
    });
    this.cainfraData.map((m)=>{
      this.infraid=m.infraId;
    });
   // let infraid = this.cainfraData[this.cainfraData.length-1].infraId +1;
    this.infraformgroup.get('infraId').setValue(this.infraid);
    console.log(this.infraid,"infra id")
    
  }

  Appchanged(event){
    this.infraformgroup.get('appMasterId').setValue(event.value);
  }

  processChanged(event){
    this.processformgroup.get('appMasterId').setValue(event.value);
  }


  loblistchanged(event) {
    this.firstformgroup.get('lobId').setValue(event.value);
  }

  createDialog() {
    this.submitted= true;
    if (this.firstformgroup.valid) {
      this.dialogRef.close({ event: 'close', data: this.firstformgroup });
    } else {
      this._snackBar.open('All fields are mandatory','X');
    }
  }
  createInfra(){
    
    this.infraformgroup.get('')
    if (this.infraformgroup.valid) {
      this.dialogRef.close({ event: 'close', data: this.infraformgroup });
    }
    else {
      this._snackBar.open('All fields are mandatory','X');
    }
  }

  createProcess(){
    
    this.processformgroup.get('')
    if (this.processformgroup.valid) {
      this.dialogRef.close({ event: 'close', data: this.processformgroup });
    }
    else {
      alert('All fields are mandatory');
    }
  }
}
