import { Component, OnInit } from '@angular/core';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { HTTPService } from '../service/httpService.service';
import { user } from 'src/app/model/user';
import { single } from 'rxjs/operators';


@Component({
  selector: 'app-delegate-user',
  templateUrl: './delegate-user.component.html',
  styleUrls: ['./delegate-user.component.css']
})
export class DelegateUserComponent implements OnInit {
lobdname:any;
  options:any;
  selectedValue:any;
  submitted=false;
  marked = false;
  theCheckbox = false;
  user =new user();
  form: FormGroup;
  errorMsg:string;
  userList:user[];
  roleList:user[];
  orgId:any;
  emaillist =[];
  LobId:any;
  email_Id:any;
  emailpwordcombo:any;
  userListdata:any;
  uservalidation:any;
  applist: object;
  userId:any;
  userdashboard: any;
  lobdata: any;
  productId:any;
  get formControls() { return this.registerForm.controls; }
  constructor(private service:HTTPService,private formBuilder: FormBuilder,
    private router:Router,private Userservice: HTTPService,
    public dialogRef: MatDialogRef< DelegateUserComponent>,
    private _snackBar: MatSnackBar) {
    this.form=this.formBuilder.group({
      userList:['']
    })
   
   }

  ngOnInit(): void {
    this.orgId=sessionStorage.getItem("orgId");
    this.lobdname=sessionStorage.getItem("UserLobName");
    this.LobId=sessionStorage.getItem("UserLobId");
    console.log( sessionStorage.getItem("UserLobId") ,"lobidlobid")
    this.userId=sessionStorage.getItem("userId");
    this.Userservice.getuserdashboard(parseInt(this.userId)).subscribe((data) => {
      this.userdashboard=data;
      console.log(data,"dropdown list")
    })
     


    
    
    this.orgId=sessionStorage.getItem("orgId");
    this.LobDropdown();
    this.RoleDropdown();




    this.Userservice.getUsersList(this.orgId,this.productId).subscribe(
      data=>{

        this.userListdata=data;
        
        // console.log(this.userListdata);
      },
      error=>{
        this.errorMsg="Some error"
      })

      // this.service.uservalidation().subscribe((data) => {
      //   this.uservalidation = data;
      //   // console.log(this.uservalidation,"uservalidationuservalidation")
      // })
      this.applicationDropdown();
  }
  registerForm = this.formBuilder.group({
   
    firstname:['', Validators.required],
    lastname:['', Validators.required],
    email : ['', [Validators.required,Validators.pattern(/^[a-z]+[a-z0-9._]+@[a-z]+\.[a-z.]{2,5}$/)]],
    password : ['', Validators.required],
   
    UserRoleId:['user', ],
    application:['',Validators.required]
    
  });

  
  usersetup(){
   
    this.submitted= true;
    let n = (Math.random() * (1000));
    n = Math.floor(n);
    let autopassword=this.registerForm.get('firstname').value+'@'+n;
    
    this.registerForm.get('password').setValue(autopassword);
    
    
  if(this.registerForm.invalid){
    this._snackBar.open('All fields are Mandatory','X');
    return;
  }
  let pushtodb = true;
  // this.uservalidation.map(f=>
  //   {
  //     if(this.registerForm.get('email').value==f.migration_Strategy){
  //       this._snackBar.open('User Email Id is already Registered','X');
  //       pushtodb = false;
  //     return;
  //     }
  //   })

    if(pushtodb)
{
this.user.recInsDt=new Date().toISOString();
this.user.recUpdDt=new Date().toISOString();
this.user.recType=false;
this.user.firstName=this.registerForm.value.firstname;
this.user.lastName=this.registerForm.value.lastname;
this.user.emailAddress=this.registerForm.value.email;
// this.user.lobId=this.LobId;

this.user.orgId=sessionStorage.getItem("orgId");
this.productId = sessionStorage.getItem("productId");
this.user.password=this.registerForm.value.password;
this.user.roleId="3";
this.user.productId=this.productId;

// this.service.createUsers(this.user,this.user.orgId).subscribe(data=>{
  this.service.TbAddUsers(this.user).subscribe(data=>{
  console.log(data);
  this.dialogRef.close();
  
  this.emailnotify();
  console.log(this.registerForm.get('application').value,"test");
  
  this.createUserAppMapping(data['userId']);
})

}
  }

  createUserAppMapping(userid:any){
    let userObj = {user_id:userid,app_master_id:this.registerForm.get('application').value,org_id:this.orgId,Lob_Id:this.LobId};
    let finaluserappmapping=[];
  
    userObj.app_master_id.map(m=>{
      let singleuser = {usrId:0,appMasterId:0,orgId:0,LobId:0};
      singleuser.usrId = userObj.user_id;
      singleuser.appMasterId = m;
      singleuser.orgId = userObj.org_id;
      singleuser.LobId=userObj.Lob_Id;
      finaluserappmapping.push(singleuser);
    });
   
    this.service.PostDelegateUser(finaluserappmapping,this.LobId).subscribe(data=>{
      console.log(data);
      
    });
    
    this.service.PostUserAppMapping(finaluserappmapping,this.LobId).subscribe(data=>{
      console.log(data);
      
    });
  }
  

RoleDropdown(){
  
   this.Userservice.getRoles().subscribe(
    data=>{

      this.roleList=data;
      // console.log(this.roleList,"aaaaaaaaaaaaaaaaa");
      
      
    },
    error=>{
      this.errorMsg="Some error"
    } )
}


emailnotify(){

  let obj={
    emailid:this.registerForm.get('email').value, password:this.registerForm.get('password').value
  }
  this.emaillist.push(obj);

    this.Userservice.sendMail(this.emaillist).subscribe(data=>{
        
        this._snackBar.open("User Added and Email Notification sent Successfully ", 'X');
      },(error)=>{
        alert(error)
        this._snackBar.open(error, 'X');
      },()=>{
        this.registerForm.reset();
      }
      );

 

    












    }
    applicationDropdown(){
      
      this.Userservice.AppNameAppId(parseInt(this.LobId)).subscribe(
        (data)=>{
          this.applist=data;
          console.log(this.applist,"applist ");
          
        })
    }
    LobDropdown(){
      // console.log("inside userList");
       this.Userservice.getLobs(this.orgId).subscribe(
        data=>{
    
          this.userList=data;
          // console.log(this.userList);
          this.userList.map(f=>{
            
            // if(this.LobId==f.lobId)
            // {
            //   this.lobdname=f["lobName"]
              
              
            // }

          })
        },
        error=>{
          this.errorMsg="Some error"
        }
        
    
           )
         
    
    }

    
}

