import { Component, OnInit, Inject } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { HTTPService } from '../service/httpService.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Eolproductversion } from '../model/Eolproductversion';
import * as pageText from 'src/app/add-eol-version/constants/add-eol-version.json'

@Component({
  selector: 'app-add-eol-version',
  templateUrl: './add-eol-version.component.html',
  styleUrls: ['./add-eol-version.component.css']
})
export class AddEolVersionComponent implements OnInit {
  pageText=(pageText as any).default;
  submitted: boolean;
  productId: any;
  marked = false;
  Eolproductversion = new Eolproductversion();
  constructor(private formBuilder: FormBuilder, private _snackBar: MatSnackBar,
    private Service: HTTPService, @Inject(MAT_DIALOG_DATA) public data: any,
    public dailogRefCreate: MatDialogRef<AddEolVersionComponent>) { }

  ngOnInit(): void {
    this.productId = this.data.id;
    console.log(this.productId, "passed product id")
  }
  registerForm = this.formBuilder.group({
    versionNum: ['', Validators.required],
    releasedate: ['', [Validators.required]],
    EofSupportdate: [''],
    EofLifedate: [''],
    isActiveBit: [''],
  });
  createEolVersion() {

    this.submitted = true;
    if (this.registerForm.invalid) {
      this._snackBar.open('Please Enter All the details', 'X');
    }
    else {
      this.Eolproductversion.productID = this.productId;
      this.Eolproductversion.version = this.registerForm.value.versionNum;
      this.Eolproductversion.releasedt = this.registerForm.value.releasedate;
      this.Eolproductversion.supportdt = this.registerForm.value.EofSupportdate;
      this.Eolproductversion.eoldt = this.registerForm.value.EofLifedate;
      this.Eolproductversion.recInsdt = new Date().toISOString();
      this.Eolproductversion.recUpddt = new Date().toISOString();
      if (this.marked == true) {
        this.Eolproductversion.isActive = 1;
      }
      else {
        this.Eolproductversion.isActive = 0;
      }
      this.Service.createEolProductVersion(this.Eolproductversion).subscribe(data => {
        this.dailogRefCreate.close();

        this._snackBar.open('Product Details saved Successfully', 'close');
      },
        (error) => {
          this._snackBar.open(
            'Could not save Product Details, Please try again', 'close'
          );
        });


    }
  }
  toggleVisibility(e) {
    this.marked = e.target.checked;
  }

  saveAndAdd() {
    this.submitted = true;
    if (this.registerForm.invalid) {
      this._snackBar.open('Please Enter All the details', 'X');
    }
    else {
      this.Eolproductversion.productID = this.productId;
      this.Eolproductversion.version = this.registerForm.value.versionNum;
      this.Eolproductversion.releasedt = this.registerForm.value.releasedate;
      this.Eolproductversion.supportdt = this.registerForm.value.EofSupportdate;
      this.Eolproductversion.eoldt = this.registerForm.value.EofLifedate;
      this.Eolproductversion.recInsdt = new Date().toISOString();
      this.Eolproductversion.recUpddt = new Date().toISOString();
      if (this.marked == true) {
        this.Eolproductversion.isActive = 1;
      }
      else {
        this.Eolproductversion.isActive = 0;
      }
      this.Service.createEolProductVersion(this.Eolproductversion).subscribe(data => {

        this._snackBar.open('Product Details saved Successfully', 'close');
      },
        (error) => {
          this._snackBar.open(
            'Could not save Product Details, Please try again', 'close'
          );
        });
    }
    this.registerForm.reset()
  }
}


