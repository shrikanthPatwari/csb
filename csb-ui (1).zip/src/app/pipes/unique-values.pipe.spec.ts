import { UniqueValuesPipe } from './unique-values.pipe';

describe('UniqueValuesPipe', () => {
  it('create an instance', () => {
    const pipe = new UniqueValuesPipe();
    expect(pipe).toBeTruthy();
  });
});
