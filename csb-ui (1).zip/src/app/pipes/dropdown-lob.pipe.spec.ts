import { DropdownLOBPipe } from './dropdown-lob.pipe';

describe('DropdownLOBPipe', () => {
  it('create an instance', () => {
    const pipe = new DropdownLOBPipe();
    expect(pipe).toBeTruthy();
  });
});
