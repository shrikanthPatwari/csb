import { ValuePipe } from './value.pipe';

describe('ValuePipe', () => {
  it('create an instance', () => {
    const pipe = new ValuePipe();
    expect(pipe).toBeTruthy();
  });
});
