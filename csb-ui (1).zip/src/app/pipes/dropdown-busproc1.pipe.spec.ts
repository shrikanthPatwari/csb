import { DropdownBusproc1Pipe } from './dropdown-busproc1.pipe';

describe('DropdownBusproc1Pipe', () => {
  it('create an instance', () => {
    const pipe = new DropdownBusproc1Pipe();
    expect(pipe).toBeTruthy();
  });
});
