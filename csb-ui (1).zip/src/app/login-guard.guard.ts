import { Injectable,HostListener } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import {IdleService} from './service/idle-timeout/idle.service'
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoginGuardGuard implements CanActivate {
  userDisplayName: string;
  tokenExp: any;
  constructor(private router: Router, private _snackBar: MatSnackBar,private idleService:IdleService
  ) { }
  private tokenExpired(token: string) {
    const expiry = (JSON.parse(atob(token.split('.')[1]))).exp;
    return (Math.floor((new Date).getTime() / 1000)) >= expiry;
  }
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    this.tokenExp = sessionStorage.getItem('token')
    this.tokenExp = this.tokenExp.replace('Bearer', '');
    if (this.tokenExpired(this.tokenExp)) {
      this.router.navigate(['']);
      this._snackBar.open("Session Expired Please Login Again", "X");
      console.log("expired")
    } else {
      console.log("token")
    }
    if (this.userDisplayName = sessionStorage.getItem('username')) {
      return true;
    } else {
      this.router.navigate(['']);
      this._snackBar.open("Please login with Credentials", "X");
      return false;

    }
    // @HostListener('document:mousemove')
    // @HostListener('document:keypress')
    // onUserAction() {
    //   this.idleService.reset();
    // }

  }

}
