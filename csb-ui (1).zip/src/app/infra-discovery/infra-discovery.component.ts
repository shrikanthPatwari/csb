import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HTTPService } from '../service/httpService.service';
import * as am4core from '@amcharts/amcharts4/core';
import * as am4charts from '@amcharts/amcharts4/charts';
import { count } from 'rxjs/operators';
import { DashboardPopupComponent } from '../dialog-reports/dashboard-popup/dashboard-popup.component';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { DialogboxComponent } from '../dialogbox/dialogbox.component';
import { ChartPopupComponent } from '../chart-popup/chart-popup.component';
import { InfraPopupComponent } from '../infra-popup/infra-popup.component';
import * as pageText from 'src/app/infra-discovery/constants/infra-discovery.json'

@Component({
  selector: 'app-infra-discovery',
  templateUrl: './infra-discovery.component.html',
  styleUrls: ['./infra-discovery.component.css'],
})
export class InfraDiscoveryComponent implements OnInit {
  osdata: any;
  physicaldata: any;
  OSvsData: any;
  Oscount: any;
  Environmentcount: any;
  lobcount: any;
  infradatacount: any = 0;
  infraReport: string = 'Infra Discovery Report';
  caappmasterdata: any;
  updateddate: any;
  EnvironmentvsServerbyDATA: any;
  CAInfradata:any = [];
  caAppList: any;
  lobmap: any;
  CAInframapping: any;
  orgId: any;
  data: any;
  data1: any;
  device: any;
  device1: any;
  Environmentcounting: any;
  pageText = (pageText as any).default;
  constructor(
    private Service: HTTPService,
    private router: Router,
    private dialogue: MatDialog
  ) { }
  ngOnInit(): void {
    this.orgId = sessionStorage.getItem("orgId");
    this.data = [{
      name: "2",
      device_url: "/api/2.0/devices/1014/",
      device_id: 1014,
      type: "virtual",
      uuid: "4A2C4380-8EA7-0F02-179C-80CCBAD31E58"
    },
    {
      name: "22878cfa4f3b",
      device_url: "/api/2.0/devices/998/",
      device_id: 998,
      type: "virtual",
      uuid: "22878CFA4F3BF740ECA089D60B5B8474069D1B89C158E917F48A1337E6810351"
    },
    {
      name: "2b26a2c33bee",

      device_url: "/api/2.0/devices/1002/",
      device_id: 1002,
      type: "virtual",
      uuid: "2B26A2C33BEE385E556A355D8457700D2440D865A688DD7115F1D9EF0662D273"
    }
    ];

    this.data1 = [{
      available: "no",
      subnet: "undefined-0.0.0.0/0",
      last_updated: "2017-06-26T12:53:09.651Z",
      mac_id: 1168,
      subnet_id: 38,
      ip: "172.17.0.7",
      label: "bridge",
      port_name: "bridge",
      mac_address: "02:42:ac:11:00:07",
      device: "2b26a2c33bee",
      port_id: 1168,

      device_id: 1002,
    }

    ];
    console.log("this.before subscribe>>>>>>",this.CAInfradata)
    // setTimeout(()=>{
      this.Service.CAInfradata(this.orgId).subscribe((data:any) => {
        this.CAInfradata = data;
        // this.CAInfradata.forEach(product => JSON.stringify(product));
        console.log("this.CAInfradata>>>>>>",this.CAInfradata)
        this.piechartEnv()
        this.pieChartOs()
        this.createphysicalchart();
        this.creatOSVS();
        this.Environment();
      });
    // },2000);
    console.log("this.CAInfradata OnInit======>>>>>>",this.CAInfradata)
    //var currentUser = JSON.parse(sessionStorage.getItem('username'));
  }

  ngAfterViewInit() {
    this.createphysicalchart();
    this.creatOSVS();
    this.Environment();
    this.Service.datacentreview(this.orgId).subscribe((data) => {
      this.caappmasterdata = Object.keys(data).length;
      if (this.caappmasterdata == 0) {
        console.log('SUmana testing' + this.caappmasterdata);
        //this.openDialog();
      }
      // console.log(this.caappmasterdata, 'ssssssssssssssssseeeeeeeeeeeeee');
    });

    //OSData

    //OScount stackedbar graph
    this.Service.Oscount().subscribe((data) => {
      this.Oscount = data;
      // console.log(this.Oscount, 'check OS COUNT GRAPHHHHHH');
      // this.OSvsDatachart();
    }); //end

    //lobcount
    this.Service.getLobs(this.orgId).subscribe((data) => {
      let count = 0;
      this.lobcount = data;
      // console.log(this.lobcount, 'check lobcount lobcount checkcheck');
      this.lobcount.map((m) => {
        count = count + 1;
      });
      this.lobcount = count;
      // console.log(this.lobcount, 'check lobcount lobcount');
    }); //end

    //infraapplication count
    this.Service.infradatacount(this.orgId).subscribe((data) => {
      //this.infradatacount = data[0].num;
      let total = 0;
      Object.keys(data).map(m => {
        total = total + data[m].num;
      })
      this.infradatacount = total;
      this.updateddate = data[0].migration_Strategy;
      this.updateddate = this.updateddate.split(' ')[0];
      // console.log(this.infradatacount, 'check infradatacount');
      //     //infraapplication count
    }); //end

  } 
  piechartEnv() {
    // console.log("pieChartEnv",this.CAInfradata)
    this.Service.Environmentcount(this.orgId).subscribe((data) => {
      this.Environmentcount = data;
      this.Environmentcounting = Object.keys(data).length;
      const colorList = ["#65348F", "#217378", "#595A5C", "#CC8787", "#4670B4"]
      this.Environmentcount.forEach((e, i) => {
        this.Environmentcount[i]["color"] = colorList[i]
      })
      // console.log("this.Environmentcount", this.Environmentcount,)
      let chart = am4core.create("pieChartEnv", am4charts.PieChart);
      chart.logo.dispose();
      chart.data = this.Environmentcount;
      chart.innerRadius = 80;
      chart.radius = am4core.percent(80);
      // chart.radius = am4core.percent(100);
      let label = chart.seriesContainer.createChild(am4core.Label);
      label.horizontalCenter = "middle";
      label.verticalCenter = "middle";
      label.fontSize = 20;
      let pieSeries = chart.series.push(new am4charts.PieSeries());
      pieSeries.dataFields.value = "num";
      pieSeries.dataFields.category = "migration_Strategy";
      pieSeries.slices.template.propertyFields.fill = "color";
      pieSeries.slices.template.stroke = am4core.color("#ffff");
      pieSeries.slices.template.strokeWidth = 2;
      pieSeries.slices.template.strokeOpacity = 1;
      pieSeries.alignLabels = false;
      const reftodilog: any = this.dialogue;
      let displayelements = [];
      let valueselected = ''
      // console.log(" this.CAInfradata======", this.CAInfradata)
      const list = this.CAInfradata
      // console.log("befor click list", list);
      //  list.push(this.CAInfradata);
      const envData = this.Environmentcount;
      pieSeries.slices.template.events.on("hit", function (ev) {
        // console.log("list======", list)
        // console.log(" this.CAInfradata======", this.CAInfradata)
        valueselected = ev.target.dataItem.properties.category;
        // console.log("valueselected---",valueselected)
        let count = 0;
        const series: any = ev.target.dataItem.component;
        series.slices.each(function (item) {
          // console.log("envData======", envData)
          if (item.isActive && item != ev.target) {
            item.isActive = false;
          }
          if (count < 1) {
            envData.map((map, i) => {
              let name = map.migration_Strategy.split(' ').join('');
              let topopup = [];
              displayelements = [];
              topopup = [];
              list.map((m) => {
                if (m.environment.split(' ').join('') == name) {
                  displayelements.push(m);
                  var obj = {
                    Host_Name: '',
                    IP_Address: '',
                    Environment: '',
                    Data_Center: '',
                  };
                  obj.Host_Name = m.hostName;
                  obj.IP_Address = m.ipAddress;
                  obj.Environment = m.environment;
                  obj.Data_Center = m.dataCenter;
                  topopup.push(obj);
                }
              });
              let selectedName = name == "PreProd" ? "Pre Prod" : name
              if (valueselected == selectedName) {
                reftodilog.open(InfraPopupComponent, {
                  height: '75%',
                  width: '60%',
                  disableClose: false,
                  data: {
                    dataKey: topopup,
                    title: name,
                    datacenter: false,
                    physicalvsvirtual: true,
                    // Environment:true,
                    piechartname: 'Environment',
                  },
                });

              }

            })
            count = count + 1
          }
        })

      });
      chart.legend = new am4charts.Legend();
      chart.legend.position = "right"
      chart.legend.labels.template.maxWidth = 10;
      chart.legend.itemContainers.template.clickable = false;
      chart.legend.itemContainers.template.focusable = false;
      let marker: any = chart.legend.markers.template.children.getIndex(0);
      marker.cornerRadius(12, 12, 12, 12, 12);
      pieSeries.labels.template.disabled = true;
      // pieSeries.slices.template.tooltipText = "";

    })

  }
  pieChartOs() {
    this.Service.getOStochart(this.orgId).subscribe((data) => {
      this.osdata = data;
      const colorListOs = ["#CC8787", "#595A5C", "#217378"]
      this.osdata.forEach((l, i) => {
        this.osdata[i].count = parseInt(l.count);
        this.osdata[i]["color"] = colorListOs[i]
      })
      // this.Environmentcounting = Object.keys(data).length;
      console.log("this.osdata", this.osdata,)
      let chart = am4core.create("pieChartOsType", am4charts.PieChart);
      chart.logo.dispose();
      chart.data = this.osdata;
      chart.innerRadius = 80;
      chart.radius = am4core.percent(80);
      let label = chart.seriesContainer.createChild(am4core.Label);
      label.horizontalCenter = "middle";
      label.verticalCenter = "middle";
      // label.fontSize = 50;
      let pieSeries = chart.series.push(new am4charts.PieSeries());
      pieSeries.dataFields.value = "count";
      pieSeries.dataFields.category = "name";
      pieSeries.slices.template.propertyFields.fill = "color";
      pieSeries.slices.template.stroke = am4core.color("#ffff");
      pieSeries.slices.template.strokeWidth = 2;
      pieSeries.slices.template.strokeOpacity = 1;
      pieSeries.alignLabels = false;
      chart.legend = new am4charts.Legend();
      chart.legend.position = "right"
      chart.legend.itemContainers.template.clickable = false;
      chart.legend.itemContainers.template.focusable = false;
      pieSeries.labels.template.disabled = true;
      let marker: any = chart.legend.markers.template.children.getIndex(0);
      marker.cornerRadius(12, 12, 12, 12, 12);
      // pieSeries.slices.template.tooltipText = "";

      const reftodilog: any = this.dialogue;
      let displayelements = [];
      let valueselected = ''
      const osTypeData = this.osdata;
      const list = this.CAInfradata;
      pieSeries.slices.template.events.on("hit", function (ev) {
        const series: any = ev.target.dataItem.component;
        valueselected = ev.target.dataItem.properties.category;
        let count = 0;
        series.slices.each(function (item) {
          if (item.isActive && item != ev.target) {
            item.isActive = false;
          }
        })
        if (count < 1) {
          // console.log("Listttttt",list)
          osTypeData.map((ele) => {
            let name = ele.name.split(' ').join('');
            // console.log("nameeeee",name)
            let topopup = [];
            displayelements = [];
            topopup = [];
            list.map((f) => {
              if (f.osType == ele.name) {
                var obj = {
                  Host_Name: '',
                  IP_Address: '',
                  Environment: '',
                  Data_Center: '',
                };
                obj.Host_Name = f.hostName;
                obj.IP_Address = f.ipAddress;
                obj.Environment = f.environment;
                obj.Data_Center = f.dataCenter;
                topopup.push(obj);
              }
            });
            let selectedName = name == "MicrosoftWindowsServer2012Datacenter" ? "Microsoft Windows Server 2012 Datacenter" : name
            // console.log("===========",valueselected,"name--",name)
            if (valueselected == selectedName) {
              reftodilog.open(InfraPopupComponent, {
                height: '75%',
                width: '60%',
                disableClose: false,
                data: {
                  dataKey: topopup,
                  title: ele.name,
                  datacenter: false,
                  physicalvsvirtual: true,
                  piechartname: 'OS Type',
                },
              });
            }
          })
        }
      });
    })
  }

  Device() {
    this.Service.createdata(this.data).subscribe((data) => {
      console.log(data);
    })

    this.Service.createdata1(this.data1).subscribe((data1) => {
      console.log(data1);
    })
  }

  createphysicalchart() {
    //Physical
    this.Service.getPhysicaltochart(this.orgId).subscribe((data) => {
      this.physicaldata = data;
      // console.log(this.physicaldata, 'checkkkkPhysical');
      this.PhysicalvsVirtual();
      setTimeout(()=>{
        this.piechartEnv();
        this.pieChartOs();
      
      },1000)
      
    }); //end
  }

  creatOSVS() {
    //Physical
    this.Service.OSvsData(this.orgId).subscribe((data) => {
      this.OSvsData = data;
      // console.log(this.OSvsData, 'checkkkkOSvsData');
      this.OSvsDatachart();
    }); //end
  }

  Environment() {
    //4. EnvironmentvsServerbyDATA
    this.Service.EnvironmentvsServerbyDATA(this.orgId).subscribe((data) => {
      this.EnvironmentvsServerbyDATA = data;
      // console.log(this.EnvironmentvsServerbyDATA, 'EnvironmentvsServerbyDATA');
      this.EnvironmentvsServerDatachart();
    }); //end
  }

  PhysicalvsVirtual() {
    let chartdivphysical = am4core.create(
      'chartdivphysical',
      am4charts.PieChart
    );
    let resultphysical = { migration_Strategy: '', num: 0 };
    let physicaldata = [];
    // physicaldata.length = 5
    chartdivphysical.logo.dispose();
    chartdivphysical.radius = am4core.percent(100);
    chartdivphysical.responsive.enabled = true;
    // chartdivphysical.innerRadius = am4core.percent(40);
    this.physicaldata.forEach((m) => {
      resultphysical.migration_Strategy = m.migration_Strategy;
      resultphysical.num = m.num;
      physicaldata.push(resultphysical);
      resultphysical = { migration_Strategy: '', num: 0 };
    });
    console.log("physicaldata====>",physicaldata)
    chartdivphysical.data = physicaldata;
    let pieSeriesarch = chartdivphysical.series.push(new am4charts.PieSeries());
    pieSeriesarch.dataFields.value = 'num';
    pieSeriesarch.dataFields.category = 'migration_Strategy';
    chartdivphysical.legend = new am4charts.Legend();
    chartdivphysical.legend.maxWidth =500
    chartdivphysical.legend.maxHeight =500
    pieSeriesarch.legendSettings.valueText = '{value}';
    pieSeriesarch.ticks.template.disabled = true;
    pieSeriesarch.alignLabels = false;
    pieSeriesarch.labels.template.text = '{value}';
    pieSeriesarch.labels.template.fontWeight = "bold";
    pieSeriesarch.labels.template.radius = am4core.percent(-40);

    pieSeriesarch.colors.list = [
      am4core.color('#CC8787'),
      am4core.color('#595A5C'),
    ];
    pieSeriesarch.slices.template.cursorOverStyle = am4core.MouseCursorStyle.pointer;
    let reftodilog = this.dialogue;
    let valueselected = '';
    let displayelements = [];
    let list = this.CAInfradata;
    let topopup = [];
    console.log("CAInfradata",this.CAInfradata)
    pieSeriesarch.slices.template.events.on('hit', function (ev) {
      displayelements = [];
      valueselected = ev.target.dataItem.properties.category;
      topopup = [];
      list.map((m) => {
        if (m.physicalOrVirtual && m.physicalOrVirtual.toLowerCase() == valueselected.toLowerCase()) {
          var obj = {
            Host_Name: '',
            IP_Address: '',
            Environment: '',
            Data_Center: '',
          };
          obj.Host_Name = m.hostName;
          obj.IP_Address = m.ipAddress;
          obj.Environment = m.environment;
          obj.Data_Center = m.dataCenter;
          topopup.push(obj);
        }
      });
      var dref = reftodilog.open(InfraPopupComponent, {
        height: '75%',
        width: '60%',
        disableClose: false,
        data: {
          dataKey: topopup,
          title: valueselected,
          datacenter: false,
          physicalvsvirtual: true,
          piechartname: 'Physical VS Virtual',
        },
      });
    });
  }

  OSvsDatachart() {
    let chartdivarch = am4core.create('chartOSvsData', am4charts.PieChart);
    let result = { name: '', count: 0 };
    let osdata1 = [];
    this.OSvsData.forEach((m) => {
      result.name = m.name;
      result.count = m.count;
      osdata1.push(result);
      result = { name: '', count: 0 };
    });
    chartdivarch.logo.dispose();
    chartdivarch.radius = am4core.percent(100);
    chartdivarch.data = osdata1;
    // console.log( 'checkkkkOSvsData??????????????',osdata1);
    let pieSeriesarch = chartdivarch.series.push(new am4charts.PieSeries());
    pieSeriesarch.dataFields.value = 'count';
    pieSeriesarch.dataFields.category = 'name';
    chartdivarch.legend = new am4charts.Legend();
    pieSeriesarch.legendSettings.valueText = '{value}';
    pieSeriesarch.ticks.template.disabled = true;
    pieSeriesarch.alignLabels = false;
    pieSeriesarch.labels.template.text = '{value}';
    pieSeriesarch.labels.template.fontWeight = "bold";
    pieSeriesarch.labels.template.radius = am4core.percent(-40);
    pieSeriesarch.colors.list = [
      am4core.color('#595A5C'),
      am4core.color('#CC8787'),
      am4core.color('#579F7B'),
      am4core.color('#81A9F8'),
      am4core.color('#5188F6'),
      am4core.color('#3A79F8'),
    ];
    pieSeriesarch.slices.template.cursorOverStyle = am4core.MouseCursorStyle.pointer;

    let reftodilog = this.dialogue;
    let valueselected = '';
    let displayelements = [];
    let list = this.CAInfradata;
    let topopup = [];

    pieSeriesarch.slices.template.events.on('hit', function (ev) {
      displayelements = [];
      valueselected = ev.target.dataItem.properties.category;
      topopup = [];
      list.map((m) => {
        if (m.dataCenter == valueselected) {
          displayelements.push(m);
          var obj = {
            Host_Name: '',
            IP_Address: '',
            Environment: '',
            Server_Type: '',
          };
          obj.Host_Name = m.hostName;
          obj.IP_Address = m.ipAddress;
          obj.Environment = m.environment;
          obj.Server_Type = m.serverType;
          topopup.push(obj);
        }
      });
      var dref = reftodilog.open(InfraPopupComponent, {
        height: '75%',
        width: '60%',
        disableClose: false,
        data: {
          dataKey: topopup,
          title: valueselected,
          datacenter: true,
          physicalvsvirtual: false,
          piechartname: 'Servers by Data Center',
        },
      });
    });
  }

  EnvironmentvsServerDatachart() {
    let chartdivphysical = am4core.create(
      'chartdivEnvironmentvsServer',
      am4charts.PieChart
    );
    chartdivphysical.logo.dispose();
    chartdivphysical.radius = am4core.percent(100);
    let resultphysical = { migration_Strategy: '', num: 0 };
    let physicaldata = [];
    console.log("EnvironmentvsServerbyDATA",this.EnvironmentvsServerbyDATA)
    this.EnvironmentvsServerbyDATA.forEach((m) => {
      resultphysical.migration_Strategy = m.migration_Strategy;
      resultphysical.num = m.num;
      physicaldata.push(resultphysical);
      resultphysical = { migration_Strategy: '', num: 0 };
    });

    chartdivphysical.data = physicaldata;
    // console.log('checkkkkPhysical??????????????',physicaldata );
    let pieSeriesarch = chartdivphysical.series.push(new am4charts.PieSeries());
    pieSeriesarch.dataFields.value = 'num';
    pieSeriesarch.dataFields.category = 'migration_Strategy';
    chartdivphysical.legend = new am4charts.Legend();
    pieSeriesarch.legendSettings.valueText = '{value}';
    pieSeriesarch.ticks.template.disabled = true;
    pieSeriesarch.alignLabels = false;
    pieSeriesarch.labels.template.text = '{value}';
    pieSeriesarch.labels.template.fontWeight = "bold";
    pieSeriesarch.labels.template.radius = am4core.percent(-40);

    pieSeriesarch.colors.list = [
      am4core.color('#595A5C'),
      am4core.color('#CC8787'),
      am4core.color('#579F7B'),
      am4core.color('#DC743C'),
      am4core.color('#44B44F'),
      // am4core.color('#3A79F8'),
    ];
    pieSeriesarch.slices.template.cursorOverStyle = am4core.MouseCursorStyle.pointer;
    let reftodilog = this.dialogue;
    let valueselected = '';
    let displayelements = [];
    let list = this.CAInfradata;
    let topopup = [];
    let CAInframappingApp = this.CAInframapping

    pieSeriesarch.slices.template.events.on('hit', function (ev) {
      displayelements = [];
      valueselected = ev.target.dataItem.properties.category;
      topopup = [];
      list.map((m) => {
        // CAInframappingApp.map((f)=>{
        if (m.environment == valueselected && m.serverType == 'Database') {
          displayelements.push(m);
          var obj = {
            Host_Name: '',
            IP_Address: '',
            Environment: '',
            Data_Center: '',
          };
          obj.Host_Name = m.hostName;
          obj.IP_Address = m.ipAddress;
          obj.Environment = m.environment;
          obj.Data_Center = m.dataCenter;
          topopup.push(obj);
        }
      });
      // })
      var dref = reftodilog.open(InfraPopupComponent, {
        height: '75%',
        width: '60%',
        disableClose: false,
        data: {
          dataKey: topopup,
          title: valueselected,
          datacenter: false,
          physicalvsvirtual: true,
          // Environment:true,
          piechartname: 'Database by Environment',
        },
      });
    });
  }
  popup() {
    var dialogRef = this.dialogue.open(DashboardPopupComponent, {
      height: '50%',
      width: '40%',
      disableClose: true,
      data: 'test',
    });
    dialogRef.afterClosed().subscribe((result) => {
      let res = result;
    });
  }
  openDialog() {
    const dialogConfig = new MatDialogConfig();

    // The user can't close the dialog by clicking outside its body
    dialogConfig.disableClose = true;
    dialogConfig.id = 'modal-component';
    //dialogConfig.height = "350px";
    //dialogConfig.width = "600px";
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;

    this.dialogue.open(DialogboxComponent, {
      width: '40%',
      minHeight: 'calc(100vh - 90px)',
      height: 'auto',
      disableClose: true,
      autoFocus: true,
      id: 'modal-component',

      data: {
        dataKey: this.infraReport,
      },
    });
  }
}
