import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fhn-process-data',
  templateUrl: './fhn-process-data.component.html',
  styleUrls: ['./fhn-process-data.component.css']
})
export class FHNProcessDataComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
