import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { CreateMovegroupComponent } from '../create-movegroup/create-movegroup.component';
import { NgModule } from '@angular/core';
import { HTTPService } from '../service/httpService.service';
import { UpdateMovegroupComponent } from '../update-movegroup/update-movegroup.component';
import { movegroup } from '../model/movegroup';
// import _, { isEmpty } from 'lodash';
import { movegroupmapping } from '../model/movegroupmapping';
import * as _ from 'lodash';
import { reject } from 'q';
import * as pageText from 'src/app/move-group/constants/move-group.json';

@Component({
  selector: 'app-move-group',
  templateUrl: './move-group.component.html',
  styleUrls: ['./move-group.component.css']
})
export class MoveGroupComponent implements OnInit {
  pageText = (pageText as any).default;
  appsComplexity = [];
  moveGroupName = [];
  groupedapps: _.Dictionary<any[]>;
  CAAppMaster: any;
  orgId: any;
  moveGroupData: any;
  a: any;
  appname: any;
  grpid: number;
  groupAppData: any[];
  GroupId: number;
  MoveGroupId: number;
  moveroupdata: any;
  RehostData: any;
  mgrpid: any;
  name: any;
  grpname: any;
  userList: any;
  errorMsg: string;
  groupList: movegroup[];
  AutomatedMovegroup: any[];
  // groupedapps: { [x: string]: Pick<any, string | number | symbol>[]; };
  neededArray = [];
  movegroup = new movegroup();
  versionData = new movegroupmapping();
  uplodedData: any;
  ids = [];
  complexity: string;
  arr = [];
  moveGroupArrayWithId = [];
  // appArray=[];



  constructor(public dialog: MatDialog,
    private Service: HTTPService, public dialogRef: MatDialogRef<UpdateMovegroupComponent>
  ) { }

  ngOnInit(): void {


    this.orgId = sessionStorage.getItem("orgId");


    //Rehost applications Data
    this.Service.getMoveGroupRehost(this.orgId).subscribe((data: any[]) => {
      this.RehostData = data;
      console.log(this.RehostData, 'cappmasterrrrrrrrrrrrrrr');
    });


    this.automatedMovegroup().then(res => this.dependentApps()).then(res => this.loadGroupDetails());

    //Move group data 
    //  this.Service.getMoveGroup(this.orgId).subscribe(data => {
    //   console.log(data,'Movegroffffffffffffffffffffffffffffaaaaaaaaa');
    //   this.moveGroupData=data;
    // });
    //this.loadGroupDetails();
  }



  loadGroupDetails() {
    this.groupList = [];
    //move group Data
    this.Service.getMoveGroup(this.orgId).subscribe(data => {
      this.groupList = data;

      console.log(this.groupList, "Data to get after closed");
    },
      error => {
        this.errorMsg = "Some error"
      })
  }
  openPanel(MoveGroupId) {
    //Move group Mapping Data
    this.groupAppData = [];
    this.Service.getMoveGroupApps(MoveGroupId).subscribe((data) => {
      this.groupAppData = data;

      console.log(this.groupAppData, 'ApppDetailssssssssssssssssssssssss');
    });
  }

  createGroup() {
    let dialogref = this.dialog.open(CreateMovegroupComponent, {

      height: '600px',
      width: '500px',
    });
    dialogref.afterClosed().subscribe(data => {
      this.loadGroupDetails();
      //this.ngOnInit();
    })
  }

moveGeoupApps(MoveGroupId){

}
  //update Move group
  updateGroup(MoveGroupId) {
    console.log("MoveGroupId----",MoveGroupId)
    //Move group data 
    this.Service.getMoveGroup(this.orgId).subscribe(data => {
      console.log(data, 'Movegrofffaaaaaaaaa');
      this.moveGroupData = data;
    });
    //Extracting movegroup Id
    this.Service.getMoveGroupApps(MoveGroupId).subscribe((data) => {
      this.groupAppData = data;
      console.log(this.groupAppData, 'ApppDetails');
         this.mgrpid = MoveGroupId
    let topopup = [];
    let aa = [];
    let list = this.groupAppData;
    let data1 = this.moveGroupData

    let displayelements = [];
    list.map((m) => {
      //if (m[0].rlaneStrategyId == 1) {
      displayelements.push(m);
      var obj = { mgrpid: '', appname: '', appid: '', grpname: '' };
      // obj.lobname = locallob.get(m[0].lobId);
      obj.appname = m.app_Name;
      obj.appid = m.app_Master_Id;
      obj.mgrpid = MoveGroupId;
      data1.map((m) => {
        if (m[0].moveGroupId == this.mgrpid)
          this.grpname = m[0].moveGroupName
      });
      obj.grpname = this.grpname;

      topopup.push(obj);
      //}
    });
    let dialogref = this.dialog.open(UpdateMovegroupComponent, {

      height: '500px',
      width: '500px',

      data: {
        dataKey: topopup,//includes groupid,appname,appid,groupname
      },
    });
    dialogref.afterClosed().subscribe(data => {
      this.openPanel(MoveGroupId);
      this.loadGroupDetails();
      // this.ngOnInit();

    })
    });
 




  }

  automatedMovegroup() {

    return new Promise((resolve, reject) => {
      this.Service.getAutomatedMoveGroupApps(this.orgId).subscribe((data: any[]) => {
        this.AutomatedMovegroup = data;
        console.log(this.AutomatedMovegroup, 'Automatedgroupssssr');
        this.groupedapps = _.mapValues(_.groupBy(this.AutomatedMovegroup, 'appMasterId'),
          vlist => vlist.map(ver => _.omit(ver, 'appMasterId')));
        //console.log(this.groupedapps,"ggggggggggggggggg");

        let versions = Object.keys(this.groupedapps);

        let i = 0;
        for (let prop of versions) {
          this.neededArray.push(this.groupedapps[prop]);
          // this.neededArray[i]['dependentapps'] = this.groupedapps[prop];
          this.neededArray[i]['appMaster'] = prop;
          i++;

        }

        console.log(this.neededArray, "neededArrayyyyyyyy")



        this.neededArray.map(m => {
          this.appsComplexity = [];
          m.forEach(x => {
            this.appsComplexity.push(x.dependent_App_Complexity);
            //console.log(this.appsComplexity,"apps array");
          });
          m.forEach(x => {
            if (x.app_Complexity == "High") {
              this.complexity = "High"
              let name = "Move Group" + " " + m[0].rLane_Strategy + "-" + this.complexity;
              let obj = { dependentapps: [], name: "" }
              obj.dependentapps = x.appMasterDependentId;
              obj.name = name;

              this.arr.push(obj);
              this.moveGroupName.push(name);
            }
            else if (x.app_Complexity == "Medium") {

              if (this.appsComplexity.includes("High")) {
                this.complexity = "High"
                let name = "Move Group" + " " + m[0].rLane_Strategy + "-" + this.complexity;
                let obj = { dependentapps: [], name: "" }
                obj.dependentapps = x.appMasterDependentId;
                obj.name = name;
                this.arr.push(obj);
                this.moveGroupName.push(name);
              }
              else if (this.appsComplexity.includes("Medium")) {
                this.complexity = "Medium"
                let name = "Move Group" + " " + m[0].rLane_Strategy + "-" + this.complexity;

                let obj = { dependentapps: [], name: "" }
                obj.dependentapps = x.appMasterDependentId;
                obj.name = name;
                this.arr.push(obj);
                this.moveGroupName.push(name);
              } else {
                this.complexity = "Low"
                let name = "Move Group" + " " + m[0].rLane_Strategy + "-" + this.complexity;
                let obj = { dependentapps: [], name: "" }
                obj.dependentapps = x.appMasterDependentId;
                obj.name = name;
                this.arr.push(obj);
                this.moveGroupName.push(name);
              }

            }
            else {
              this.appsComplexity.push(x.dependent_App_Complexity);
              // console.log(this.appsComplexity,"apps array");
              if (this.appsComplexity.includes("High")) {
                this.complexity = "High"
                let name = "Move Group" + " " + m[0].rLane_Strategy + "-" + this.complexity;
                let obj = { dependentapps: [], name: "" }
                obj.dependentapps = x.appMasterDependentId;
                obj.name = name;
                this.arr.push(obj);
                this.moveGroupName.push(name);
              }
              else if (this.appsComplexity.includes("Medium")) {
                this.complexity = "Medium"
                let name = "Move Group" + " " + m[0].rLane_Strategy + "-" + this.complexity;

                let obj = { dependentapps: [], name: "" }
                obj.dependentapps = x.appMasterDependentId;
                obj.name = name;
                this.arr.push(obj);
                this.moveGroupName.push(name);
              } else {
                this.complexity = "Low"
                let name = "Move Group" + " " + m[0].rLane_Strategy + "-" + this.complexity;
                let obj = { dependentapps: [], name: "" }
                obj.dependentapps = x.appMasterDependentId;
                obj.name = name;
                this.arr.push(obj);
                this.moveGroupName.push(name);
              }
            }
          })
        });
        //console.log(this.neededArray,"complexityyyyyyyyyyyyyyyyyyyyy")
        //console.log(this.arr,"array")
        //console.log(this.moveGroupName,"movegroupnamearray")

        var newArray = new Set(this.moveGroupName);
        this.moveGroupName = [...newArray];
        //console.log(this.moveGroupName,"movegroupnamearray")

        this.moveGroupName.map(y => {
          this.movegroup.moveGroupId;
          this.movegroup.moveGroupName = y;
          this.movegroup.migrationStartdt = new Date().toISOString();
          this.movegroup.migrationEnddt = new Date().toISOString();
          this.movegroup.recInsDt = new Date().toISOString();
          this.movegroup.recUpdDt = new Date().toISOString();

          this.Service.createMoveGroup(this.movegroup, this.orgId).subscribe(data => {
          });
        })
      });

      setTimeout(() => {
        resolve("reslove");
      }, 2000);

    });

  }


  dependentApps() {
    let appNames = [];
    this.Service.getMoveGroup(this.orgId).subscribe((data) => {
      // this.versionData = new movegroupmapping();
      this.uplodedData = data;
      //console.log(this.uplodedData,"Uploaded dataaa")

      this.uplodedData.map(m => {
        let obj = { moveGroupName: '', moveGroupId: '' }
        obj.moveGroupName = m[0].moveGroupName;
        obj.moveGroupId = m[0].moveGroupId;
        this.moveGroupArrayWithId.push(obj);
      });

      this.arr.map(f => {
        this.moveGroupArrayWithId.map(h => {
          if (f.name == h.moveGroupName) {
            let obj = { moveGroupID: '', appMasterId: '', recInsDT: '', recUpDT: '' }
            // this.versionData.moveGroupID=h.moveGroupId;
            // this.versionData.appMasterId = f.dependentapps;
            // this.versionData.recInsDT=new Date().toISOString();
            //   this.versionData.recUpDT=new Date().toISOString();
            obj.moveGroupID = h.moveGroupId;
            obj.appMasterId = f.dependentapps;
            obj.recInsDT = new Date().toISOString();
            obj.recUpDT = new Date().toISOString();
            appNames.push(obj);
            // appNames.push(this.versionData);

          }
        })

      })
      this.Service.createMoveGroupMapping(appNames).subscribe(data => {
        // console.log(this.versionData,"versionData");
        console.log(appNames, "appNames");
      });
    });
    //this.loadGroupDetails();
  }
}



