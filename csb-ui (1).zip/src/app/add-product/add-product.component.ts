import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Eolproducts } from '../model/Eolproducts';
import { Eolproductversion } from '../model/Eolproductversion';
import { HTTPService } from '../service/httpService.service';
import { MatDialogRef } from '@angular/material/dialog';
import * as pageText from 'src/app/add-product/constants/add-product.json'

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {
  pageText=(pageText as any).default;
  productList: any;
  submitted: boolean;
  marked = false;
  Eolproducts = new Eolproducts();
  Eolproductversion = new Eolproductversion();
  constructor(private formBuilder: FormBuilder, private _snackBar: MatSnackBar,
    private Service: HTTPService, public dailogRefCreate: MatDialogRef<AddProductComponent>) { }

  ngOnInit(): void {
  }

  registerForm = this.formBuilder.group({
    appname: ['', Validators.required],
    aliasName: ['', Validators.required],
    versionNum: ['', Validators.required],
    releasedate: ['', [Validators.required]],
    EofSupportdate: ['',],
    EofLifedate: ['',],
    isActiveBit: ['',],
  });


  createEolProducts() {
    this.submitted = true;
    if (this.registerForm.invalid) {
      this._snackBar.open('Please Enter All the details', 'X');
    }
    else {

      this.Eolproducts.productName = this.registerForm.value.appname;
      this.Eolproducts.productAliasName = this.registerForm.value.aliasName;
      this.Eolproducts.recInsdt = new Date().toISOString();
      this.Eolproducts.recUpddt = new Date().toISOString();
      this.Service.createEol(this.Eolproducts).subscribe(data => {
        this.Service.getEolProductsList().subscribe(data => {
          this.productList = data;
          this.productList.map(m => {
            this.Eolproductversion.productID = m.productId;
          });
          this.Eolproductversion.version = this.registerForm.value.versionNum;
          this.Eolproductversion.releasedt = this.registerForm.value.releasedate;
          this.Eolproductversion.supportdt = this.registerForm.value.EofSupportdate;
          this.Eolproductversion.eoldt = this.registerForm.value.EofLifedate;
          this.Eolproductversion.recInsdt = new Date().toISOString();
          this.Eolproductversion.recUpddt = new Date().toISOString();
          if (this.marked == true) {
            this.Eolproductversion.isActive = 1;
          }
          else {
            this.Eolproductversion.isActive = 0;
          }
          this.Service.createEolProductVersion(this.Eolproductversion).subscribe(data => {
            this.dailogRefCreate.close();
            this._snackBar.open('Product Details saved Successfully', 'close');
          },
            (error) => {
              this._snackBar.open(
                'Could not save Product Details, Please try again', 'close'
              );
            });
        });
      });
    }
  }
  toggleVisibility(e) {
    this.marked = e.target.checked;
  }
}
