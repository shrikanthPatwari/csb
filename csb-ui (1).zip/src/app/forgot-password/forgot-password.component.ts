import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators,FormBuilder } from '@angular/forms';
import { HTTPService } from '../service/httpService.service';
import { Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {
  
  forgotPswrdForm:FormGroup;
  submitted = false;
  
  constructor(private formBuilder: FormBuilder,
    private httpService:HTTPService,private router:Router,
    private _snackBar: MatSnackBar) { }

  ngOnInit(): void {
    this.forgotPswrdForm = this.formBuilder.group({
      emailAddress: new FormControl('',[Validators.required,Validators.email]),
    })
  }
  forgotPswrd(){
    console.log("clicked",this.forgotPswrdForm.value)
    this.submitted = true;
    if (this.forgotPswrdForm.invalid) {
      return;
    }
    this.httpService.sendMailLoginForgot(this.forgotPswrdForm.value).subscribe(
      (res) => {
        this._snackBar.open("Check your mail we have sent an email with password recovery instructions to your registered email address.", 'X',{duration: 5000});
        this.router.navigate(['']);
      },
      (error:HttpErrorResponse) => {
        console.log(error.error.text)
        if(error.error.text=="<p>No such email present. Please enter a valid email address.</p>"){
          this._snackBar.open("No such email present. Please enter a valid email address.", 'X',{duration: 3000});
        }
        else{
        this.forgotPswrdForm.reset();
        this._snackBar.open("Check your mail we have sent an email with password recovery instructions to your registered email address.", 'X',{duration: 5000});
        this.router.navigate(['']);
        }
      }
    )

  }
  get f() {
    return this.forgotPswrdForm.controls;
  }
}
