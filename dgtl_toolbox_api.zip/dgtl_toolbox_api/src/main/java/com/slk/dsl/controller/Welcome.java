package com.slk.dsl.controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController
@CrossOrigin
public class Welcome {
	@RequestMapping("/helloworld")
	public String HelloWorld() {
		return  "Hello world";
		
	}
	@RequestMapping("/welcome")
	public String welcome() {
		return  "Welcome SLK";
	}
	
}
