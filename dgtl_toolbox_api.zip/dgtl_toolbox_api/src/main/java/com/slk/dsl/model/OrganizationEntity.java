package com.slk.dsl.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "tb_organization")
public class OrganizationEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Org_Id")
	private int orgId;

	@Column(name = "Org_Name")
	private String orgName;

	@Column(name = "Org_Email_Address")
	private String orgCntMail;

	@Column(name = "Org_Contact_Number")
	private String orgCntNum;

	@Column(name = "Org_Address")
	private String orgAdd;

	@Column(name = "Post_Code")
	private int orgPostCd;

	@Column(name = "Org_Cnt_Name")
	private String orgCntName;

	@Column(name = "Description")
	private String description;

	@Column(name = "Rec_Ins_Dt")
	private Date recInsDt;

	@Column(name = "Rec_Upd_Dt")
	private Date recUpdDt;
	
	@Column(name = "Is_Active")
	private Boolean isActive;


	public int getOrgId() {
		return orgId;
	}

	public void setOrgId(int orgId) {
		this.orgId = orgId;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public String getOrgCntMail() {
		return orgCntMail;
	}

	public void setOrgCntMail(String orgCntMail) {
		this.orgCntMail = orgCntMail;
	}

	public String getOrgCntNum() {
		return orgCntNum;
	}

	public void setOrgCntNum(String orgCntNum) {
		this.orgCntNum = orgCntNum;
	}

	public String getOrgAdd() {
		return orgAdd;
	}

	public void setOrgAdd(String orgAdd) {
		this.orgAdd = orgAdd;
	}

	public int getOrgPostCd() {
		return orgPostCd;
	}

	public void setOrgPostCd(int orgPostCd) {
		this.orgPostCd = orgPostCd;
	}

	public String getOrgCntName() {
		return orgCntName;
	}

	public void setOrgCntName(String orgCntName) {
		this.orgCntName = orgCntName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getRecInsDt() {
		return recInsDt;
	}

	public void setRecInsDt(Date recInsDt) {
		this.recInsDt = recInsDt;
	}

	public Date getRecUpdDt() {
		return recUpdDt;
	}

	public void setRecUpdDt(Date recUpdDt) {
		this.recUpdDt = recUpdDt;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	@PrePersist
	private void onCreate() {
		this.recInsDt = new Date();
	}

	@PreUpdate
	protected void onUpdate() {
		this.recUpdDt = new Date();
	}

}
