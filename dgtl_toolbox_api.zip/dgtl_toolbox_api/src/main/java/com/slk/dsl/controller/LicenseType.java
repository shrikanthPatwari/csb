package com.slk.dsl.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.slk.dsl.model.LicenseTypeEntity;
import com.slk.dsl.model.ProductFeaturesEntity;
import com.slk.dsl.repository.LicenseTypeRepo;
import com.slk.dsl.service.LicenseTypeService;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class LicenseType {
	
	@Autowired
	LicenseTypeService licenseTypeService;
	
	@Autowired
	LicenseTypeRepo licenseTypeRepo;
	
	@GetMapping("/LicenseType")  
	public List<LicenseTypeEntity> getLicenseType() {  
	     return licenseTypeService.getLicenseType();	      
	}
	
	@PostMapping("/AddLicenseType")
	public LicenseTypeEntity addLicenseType(@RequestBody LicenseTypeEntity licType) {
		return licenseTypeService.saveLicenseType(licType);
	}
	
	@DeleteMapping("/DeleteLicenseType/{id}")
	public String delete(@PathVariable int id) {
		Integer a = licenseTypeRepo.getId(id);
		try {
			if (a != null) {
				licenseTypeService.deleteLicenseType(id);
				return "License Type deleted successfully.";
			} else {
				return "License Type cannot be deleted. Please enter a valid id";
			}
		} catch (Exception e) {
			if (e instanceof java.sql.SQLIntegrityConstraintViolationException) {
				return e.getMessage();
			}
			return e.getMessage();
		}
	}
	
	@PutMapping("/UpdateLicenseType")
	public String update(@RequestBody LicenseTypeEntity licType) {
		licenseTypeService.updateLicenseType(licType);
		int licenseTypeId = licType.getLicenseTypeId();
		Optional<LicenseTypeEntity> check = licenseTypeRepo.findById(licenseTypeId);
		Boolean checkValue = check.isPresent();
		String result = "";
		if (checkValue == true) {
			result = "License Type Updated successfully.";
			return result;
		} else {
			result = "Please enter a valid License Type Id.";
			return result;
		}
	}

}
