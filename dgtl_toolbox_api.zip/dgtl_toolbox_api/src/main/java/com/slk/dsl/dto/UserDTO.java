package com.slk.dsl.dto;

import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.regex.Pattern;

import org.apache.commons.codec.binary.Base64;

import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

public class UserDTO {

	private int userId;

//	private String userName;

	private int orgId;

	private String emailAddress;

//	private String contactNumber;
//	
//	private String address;
	
//	private Date lastLogin;

	private String password;

	private Date recInsDt;
	
	private Date recUpdDt;
	
	private String firstName;
	
   private String lastName;
	
	private int roleId;
	
	private int productId;
	
	private String resetPasswordToken;
	
	private String organization;
	
	public String getOrganization() {
		return organization;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getResetPasswordToken() {
		return resetPasswordToken;
	}

	public void setResetPasswordToken(String resetPasswordToken) {
		this.resetPasswordToken = resetPasswordToken;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public int getRoleId() {
		return roleId;
	}

	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

//	public String getUserName() {
//		return userName;
//	}
//
//	public void setUserName(String userName) {
//		this.userName = userName;
//	}

	public int getOrgId() {
		return orgId;
	}

	public void setOrgId(int orgId) {
		this.orgId = orgId;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

//	public String getContactNumber() {
//		return contactNumber;
//	}
//
//	public void setContactNumber(String contactNumber) {
//		this.contactNumber = contactNumber;
//	}
//
//	public String getAddress() {
//		return address;
//	}
//
//	public void setAddress(String address) {
//		this.address = address;
//	}

//	public Date getLastLogin() {
//		return lastLogin;
//	}
//
//	public void setLastLogin(Date lastLogin) {
//		this.lastLogin = lastLogin;
//	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Date getRecInsDt() {
		return recInsDt;
	}

	public void setRecInsDt(Date recInsDt) {
		this.recInsDt = recInsDt;
	}

	public Date getRecUpdDt() {
		return recUpdDt;
	}

	public void setRecUpdDt(Date recUpdDt) {
		this.recUpdDt = recUpdDt;
	}
	@PrePersist
	private void onCreate() {
		this.recInsDt = new Date();
	}

	@PreUpdate
	protected void onUpdate() {
		this.recUpdDt = new Date();
	}
	
    public String getDecryptedField() {
        String decryptedField1 = decryptField(firstName);
        String decryptedField2 = decryptField(lastName);
        return decryptedField1 + decryptedField2;
    }

    private String decryptField(String encryptedField) {
        byte[] decodedBytes = Base64.decodeBase64(encryptedField);
        return new String(decodedBytes, StandardCharsets.UTF_8);
    }

    public boolean hasSpecialCharacters() {
        return Pattern.matches(".*[<>].*", getDecryptedField());
    }

}
