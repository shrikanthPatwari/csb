package com.slk.dsl.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

import org.springframework.stereotype.Service;

import static java.nio.charset.StandardCharsets.UTF_8;

@Service
public class KeypairManager {
	
	public static String signature="";
	public static String licenseID="";
	public static String user="";
	public static int product;
	
	//Generate public and private key
    public static KeyPair generateKeyPair() throws Exception {
    	//Generating asymmetric keypair
        KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA");
        generator.initialize(2048, new SecureRandom());
        KeyPair pair = generator.generateKeyPair();
        
        PrivateKey privateKey=pair.getPrivate();
        PublicKey publicKey=pair.getPublic();
        
        return new KeyPair(publicKey, privateKey);
    }
    
	//Saving public key as a file to given directory path
	public static void SavePublicKey(String path, KeyPair keyPair,String user, int product) throws IOException {
		
		PublicKey publicKey = keyPair.getPublic();
 
		// Store Public Key.
		X509EncodedKeySpec x509EncodedKeySpec = new X509EncodedKeySpec(publicKey.getEncoded());
		FileOutputStream fos = new FileOutputStream(path +"/"+user+"_"+product+"_Key.key");
		fos.write(x509EncodedKeySpec.getEncoded());
		fos.close();

	}
	
	//Reading public key from a file to given directory path
	public static PublicKey LoadPublicKey(String path, String algorithm,String user, int product)throws IOException, NoSuchAlgorithmException, InvalidKeySpecException {
		// Read Public Key.
		File filePublicKey = new File(path +"/"+user+"_"+product+"_Key.key");
		FileInputStream fis = new FileInputStream(path +"/"+user+"_"+product+"_Key.key");
		byte[] encodedPublicKey = new byte[(int) filePublicKey.length()];
		fis.read(encodedPublicKey);
		fis.close();

		// Generate Public key.
		KeyFactory keyFactory = KeyFactory.getInstance(algorithm);
		X509EncodedKeySpec publicKeySpec = new X509EncodedKeySpec(encodedPublicKey);
		PublicKey publicKey = keyFactory.generatePublic(publicKeySpec);

		return publicKey;
	}
	
	//signing the license ID with priavte key
    public static String sign(String licenseID, PrivateKey privateKey) throws Exception {
    	//RSA sign on the hash of the message
    	//Because RSA can't directly sign a message longer than 256 bytes.
    	//"SHA256withRSA" is used for hashing; padding the hash for signature generation; modular exponentiation using the private exponent and the modulus.
    	//Hashing is the process of converting a given key into another value.
        Signature privateSignature = Signature.getInstance("SHA256withRSA");
        privateSignature.initSign(privateKey);								
        privateSignature.update(licenseID.getBytes(UTF_8));

        byte[] signature = privateSignature.sign();

        return Base64.getEncoder().encodeToString(signature);
    }
    
    //Verify the signature using Public key
    public static boolean verify(String licenseID, String signature, PublicKey publicKey) throws Exception {
        //Se=Pad(Hash(M))(modN)
    	Signature publicSignature = Signature.getInstance("SHA256withRSA");
        publicSignature.initVerify(publicKey);
        publicSignature.update(licenseID.getBytes(UTF_8));

        byte[] signatureBytes = Base64.getDecoder().decode(signature);

        return publicSignature.verify(signatureBytes);
    }

    //Getting the signature that need to be added in the license file
    public static String getSignature(String id, String un, int pn) throws Exception {
    	
    	licenseID=id;
    	user=un;
    	product=pn;

        //First generate a public/private key pair
        KeyPair pair = generateKeyPair();
        //Save public in a given path
        //SavePublicKey(path,pair,user,product);

        //Sign the licenseID
        signature = sign(licenseID, pair.getPrivate());

        return signature;
    }

}
