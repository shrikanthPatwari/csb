package com.slk.dsl.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slk.dsl.model.ProductsEntity;
import com.slk.dsl.repository.ProductsRepo;

@Service
public class ProductsService {

	@Autowired
	ProductsRepo productsRepo;

	public ProductsEntity saveProducts(ProductsEntity pdt) {
		// TODO Auto-generated method stub
		ProductsEntity product = new ProductsEntity();
		product.setProductId(pdt.getProductId());
		product.setPrdName(pdt.getPrdName());
		product.setPrdDesc(pdt.getPrdDesc());
		product.setPrdVersion(pdt.getPrdVersion());
		product.setProductCode(pdt.getProductCode());
		product.setRecInsDt(pdt.getRecInsDt());
		product.setRecUpdDt(pdt.getRecUpdDt());
		return productsRepo.save(product);
	}

	public List<ProductsEntity> getProducts() {
		return productsRepo.findAll();
	}
	
	public String deleteProducts(int id) {	
		productsRepo.deleteProducts(id);
		  return "Products deleted successfully.";
	}
	
	public String updateProducts(ProductsEntity pdt) {
        String pdtName=pdt.getPrdName();
        String pdtDesc=pdt.getPrdDesc();
        String pdtCode=pdt.getProductCode();
        String pdtVersion=pdt.getPrdVersion();
        Date recUpdDt = new Date();
        int productId = pdt.getProductId();
        productsRepo.updateProducts(pdtName,pdtDesc,pdtCode,pdtVersion,recUpdDt,productId);
        return "Products Updated successfully.";
	}

}
