package com.slk.dsl.controller;

import java.io.IOException;
import java.math.BigInteger;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import org.json.JSONObject;
import org.json.XML;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.slk.dsl.JWTConfig.JwtTokenUtil;
import com.slk.dsl.dto.CheckLicenseDTO;
import com.slk.dsl.model.CheckLicenseResponse;
import com.slk.dsl.model.ConnectorEntity;
import com.slk.dsl.model.JwtRequest;
import com.slk.dsl.model.JwtResponse;
import com.slk.dsl.model.LicenseEntity;
import com.slk.dsl.model.UsersEntity;
import com.slk.dsl.repository.UsersRepo;
import com.slk.dsl.service.JwtUserDetailsService;
import com.slk.dsl.service.LicenseCryptography;
import com.slk.dsl.service.UsersService;

@RestController
@CrossOrigin
public class Login {

	@Autowired
	UsersRepo userRepository;

	@Autowired
	private UsersService userService;

	@Autowired
	private JwtUserDetailsService userDetailsService;

	@Autowired
	JwtTokenUtil tokenProvider;

	@RequestMapping(value = "/authenticate", method = RequestMethod.POST)
	public ResponseEntity<?> createAuthenticationToken(@RequestBody JwtRequest authenticationRequest) throws Exception {

		try {
//		String encryptedassword = userRepository.getPasswordforUser(authenticationRequest.getEmail());
//		String encryptedloginpassword = Base64.getEncoder().encodeToString(authenticationRequest.getPassword().getBytes());
			String encryptedassword = userRepository
					.getPasswordforUser(new String(Base64.getDecoder().decode(authenticationRequest.getEmail())));
			String encryptedloginpassword = authenticationRequest.getPassword();
			String email = new String(Base64.getDecoder().decode(authenticationRequest.getEmail()));
			UsersEntity user = userService.getByEmail(email);
			String error = null;
			if (encryptedassword == null || !encryptedassword.equals(encryptedloginpassword)
					|| !user.isAccountNonLocked()) {
				error = "Login failed, Invalid email or password, please try again";
				DisabledException e = new DisabledException("USER_DISABLED");
				if (user != null && user.getFailedAttempt() <= 2) {
					if (user.isAccountNonLocked()) {
						if (user.getFailedAttempt() < UsersService.MAX_FAILED_ATTEMPTS - 1) {
							error = "Login failed, Invalid email or password, please try again";
							userService.increaseFailedAttempts(user);
						} else {
							userService.lock(user);
							error = "Your account has been locked due to 3 failed attempts."
									+ " It will be unlocked after 15 minutes.";
						}
					} else if (!user.isAccountNonLocked()) {
						if (userService.unlockWhenTimeExpired(user)) {
							error = "Your account has been unlocked. Please try to login again.";
						} else {
							error = "Your account has been locked due to 3 failed attempts."
									+ " It will be unlocked after 15 minutes.";
						}
					}
				}
				return ResponseEntity.badRequest().body(error);

			}

			else {
				userRepository.updateSuccessAttempts(user.getEmailAddress());
				final UserDetails userDetails = userDetailsService
						.loadUserByUsername(new String(Base64.getDecoder().decode(authenticationRequest.getEmail())));

				final String token = tokenProvider.generateToken(userDetails);
				int orgId = userRepository
						.getOrgId(new String(Base64.getDecoder().decode(authenticationRequest.getEmail())));
				String orgName = userRepository
						.getOrgName(new String(Base64.getDecoder().decode(authenticationRequest.getEmail())));
				List<Object[]> userInfo = userRepository
						.getUserDetails(new String(Base64.getDecoder().decode(authenticationRequest.getEmail())));
				Map<String, Object> model = new HashMap<>();
				userInfo.stream().forEach(obj -> {

//            model.put("userName", obj[0].toString());
					model.put("firstName", obj[0].toString());
					model.put("lastName", obj[1].toString());
					model.put("roleId", (Integer) obj[2]);
					model.put("roleName", obj[3].toString());
					model.put("userId", (Integer) obj[4]);
					model.put("emailAddress", obj[5].toString());
					model.put("userName", obj[6].toString());
					model.put("productId", (Integer) obj[7]);
					model.put("maxDeployments", (BigInteger) obj[8]);
				});
				return ResponseEntity.ok(new JwtResponse(token, orgId, orgName, model));

			}
		} catch (DisabledException e) {
			throw new Exception("USER_DISABLED", e);
		} catch (BadCredentialsException e) {
			throw new Exception("INVALID_CREDENTIALS", e);
		}
	}
	
//	@RequestMapping(value = "/checkLicense", method = RequestMethod.POST)
//	public ResponseEntity<?> checkLicense(@RequestBody CheckLicenseDTO authenticationRequest) throws Exception {
//		try {
//				String message="";
//				List<Object[]> userLicInfo = userRepository
//						.userlicenseDetails(new String(Base64.getDecoder().decode(authenticationRequest.getEmail())));
//				int reqProductId =authenticationRequest.getProductId();
//				Map<String, Object> model = new HashMap<>();
//				userLicInfo.stream().forEach(obj -> {
//					model.put("licenseKey", obj[0].toString());
//					model.put("activationDate", obj[1].toString());
//					model.put("expirationDate", obj[2].toString());
//					model.put("productId", (Integer) obj[3]);
//				});
//					if(model.keySet().contains("licenseKey")) {		
//						Object key=model.get("licenseKey"); 
//						if(key.equals("0")) {
//							 message="License is not present or expired. Please renew your license";
//							 return new ResponseEntity<Object>(0, HttpStatus.OK);
//						}
//						else {
//							Object userProductId = model.get("productId");
//							if (userProductId.equals(reqProductId)) {
//								message = "License is present.";
////								final String secretKey = "iamhidden$secret";
////								String licenseKey = (String) key;
////								System.out.println(licenseKey);
////								String decryptedString = LicenseCryptography.decryptLicense(licenseKey, secretKey);
////								System.out.println(decryptedString);
////								JSONObject json = XML.toJSONObject(decryptedString);
////								String jsonString = json.toString(4);
////								System.out.println("jsonString:" + jsonString);
////								ObjectMapper objectMapper = new ObjectMapper();
////						        JsonNode root = objectMapper.readTree(jsonString);
////
////						        JsonNode connectorsNode = root.path("License").path("Connectors").path("Connector");
////						        if (connectorsNode.isArray()) {
////						            for (JsonNode connectorNode : connectorsNode) {
////						                String name = connectorNode.path("name").asText();
////						                String type = connectorNode.path("type").asText();
////						                int content = connectorNode.path("content").asInt();
////
////						                System.out.println("Name: " + name);
////						                System.out.println("Type: " + type);
////						                System.out.println("Content: " + content);
////						            }
////						        }
//						    
//								return new ResponseEntity<Object>(message, HttpStatus.OK);
//							} else {
//								message = "Cannot login since user is not registered with this application";
//								return new ResponseEntity<Object>(-1, HttpStatus.OK);
//							}
//						}
//					}
//
//				return new ResponseEntity<Object>(0, HttpStatus.OK);
//			
//		} catch (DisabledException e) {
//			throw new Exception("USER_DISABLED", e);
//		}
//	}
	
	@RequestMapping(value = "/checkLicense", method = RequestMethod.POST)
	public ResponseEntity<?> checkLicense(@RequestBody CheckLicenseDTO authenticationRequest) throws Exception {
		try {
			String message = "";
			long data = 0;
			List<String> connectorName = null;
			List<String> connectorType = null;
			List<Object[]> userLicInfo = userRepository
					.userlicenseDetails(new String(Base64.getDecoder().decode(authenticationRequest.getEmail())));
			int reqProductId = authenticationRequest.getProductId();
			Map<String, Object> model = new HashMap<>();
			userLicInfo.stream().forEach(obj -> {
				model.put("licenseKey", obj[0].toString());
				model.put("activationDate", obj[1].toString());
				model.put("expirationDate", obj[2].toString());
				model.put("productId", (Integer) obj[3]);
			});
			if (model.keySet().contains("licenseKey")) {
				Object key = model.get("licenseKey");
				final String secretKey = "iamhidden$secret";
				String decryptedString = LicenseCryptography.decryptLicense((String) key, secretKey);
				JSONObject json = XML.toJSONObject(decryptedString);
				String jsonString = json.toString(4);
				ObjectMapper objectMapper = new ObjectMapper();
				List<String> connectionNames = new ArrayList<>();
				List<String> connectionTypes = new ArrayList<>();
				Object expdate = model.get("expirationDate");
				long balanceDays = 0;
				if (!expdate.equals("0")) {
					Date cDate = new Date();
					DateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
					Date fDate = (Date) simpleDateFormat.parse((String) expdate);
					long diffMill = Math.abs(cDate.getTime() - fDate.getTime());
					balanceDays = TimeUnit.DAYS.convert(diffMill, TimeUnit.MILLISECONDS);
				}
				if (key.equals("0")) {
					message = "License is not present or expired. Please renew your license";
					data = -2;
				} else {
					Object userProductId = model.get("productId");
					if (userProductId.equals(reqProductId)) {
						try {
							JsonNode rootNode = objectMapper.readTree(jsonString);
							JsonNode connectorsNode = rootNode.path("License").path("Connectors").path("Connector");

							for (JsonNode connectorNode : connectorsNode) {
								String name = connectorNode.path("name").asText();
								String type = connectorNode.path("type").asText();
								connectionNames.add(name);
								connectionTypes.add(type);
							}
							connectorName = connectionNames;
							connectorType = connectionTypes;
							message = "License is present for " + (balanceDays + 1) + " days";
							data = balanceDays + 1;
						} catch (Exception e) {
							e.printStackTrace();
						}
					} else {
						message = "Cannot login since user is not registered with this application";
						data = -1;
					}
				}
			}
			return ResponseEntity.ok(new CheckLicenseResponse(data, message, connectorName, connectorType));
		} catch (DisabledException e) {
			throw new Exception("USER_DISABLED", e);
		}
	}

}
