package com.slk.dsl.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

@Entity
@Table(name = "tb_org_admin")
public class OrgAdminEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Org_Admin_Id")
	private int orgAdminId;

	@Column(name = "Org_Id")
	private int orgId;

	@Column(name = "User_Id")
	private int userId;

	@Column(name = "Rec_Ins_Dt")
	private Date recInsDt;

	@Column(name = "Rec_Upd_Dt")
	private Date recUpdDt;

	public int getOrgAdminId() {
		return orgAdminId;
	}

	public void setOrgAdminId(int orgAdminId) {
		this.orgAdminId = orgAdminId;
	}

	public int getOrgId() {
		return orgId;
	}

	public void setOrgId(int orgId) {
		this.orgId = orgId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public Date getRecInsDt() {
		return recInsDt;
	}

	public void setRecInsDt(Date recInsDt) {
		this.recInsDt = recInsDt;
	}

	public Date getRecUpdDt() {
		return recUpdDt;
	}

	public void setRecUpdDt(Date recUpdDt) {
		this.recUpdDt = recUpdDt;
	}
	
	@PrePersist
	private void onCreate() {
		this.recInsDt = new Date();
	}

	@PreUpdate
	protected void onUpdate() {
		this.recUpdDt = new Date();
	}
	

}
