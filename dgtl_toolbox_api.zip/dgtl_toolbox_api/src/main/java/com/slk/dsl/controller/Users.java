package com.slk.dsl.controller;

import java.util.ArrayList;
import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.slk.dsl.dto.EmailPasswordDTO;
import com.slk.dsl.dto.OrgNameDTO;
import com.slk.dsl.dto.OrganizationUserDTO;
import com.slk.dsl.dto.UserDTO;
import com.slk.dsl.dto.UserIdPasswordDTO;
import com.slk.dsl.model.OrganizationEntity;
import com.slk.dsl.model.UsersEntity;
import com.slk.dsl.repository.LicenseGeneratorRepo;
import com.slk.dsl.repository.OrganizationRepo;
import com.slk.dsl.repository.UserRepo;
import com.slk.dsl.repository.UsersRepo;
import com.slk.dsl.service.UsersService;
@Validated
@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class Users {
	@Autowired
	UsersService userService;
	@Autowired
	UserRepo userRepo;
	
	@Autowired
	UsersRepo usersrepo;
	
    private final Validator validator;

    public Users(Validator validator) {
        this.validator = validator;
    }
	
	@Autowired
	OrganizationRepo orgRepo;
	
	@Autowired
	LicenseGeneratorRepo licenseGeneratorrepo;

	@PostMapping("/AddUser")
	public ResponseEntity<?> saveUser(@RequestBody UserDTO user) throws Exception {
		UsersEntity emailAddress = userRepo.findByEmailAddress(new String(Base64.getDecoder().decode(user.getEmailAddress())));
		Set<ConstraintViolation<UserDTO>> violations = validator.validate(user);
		if (emailAddress == null) {
	        if (!violations.isEmpty()) {
	            StringBuilder errorMessage = new StringBuilder();
	            for (ConstraintViolation<UserDTO> violation : violations) {
	                errorMessage.append(violation.getMessage()).append("\n");
	            }
	            return ResponseEntity.badRequest().body(errorMessage.toString());
	        }
	        if (user.hasSpecialCharacters()) {
	            return ResponseEntity.badRequest().body("Invalid input: Special characters '<' or '>' are not allowed.");
	        }
			return ResponseEntity.ok(userService.saveUsers(user));
		} else {
			return new ResponseEntity<>("Email already exists", HttpStatus.BAD_REQUEST);
		}
	}
	
//	@PostMapping("/LoadUserByEmailAddress/{emailAddress}")
//	public UsersEntity loadUserByEmailAddress(@PathVariable String emailAddress) throws UsernameNotFoundException{
//		UsersEntity emlAdd = userRepo.findByEmailAddress(emailAddress);
//		if (emlAdd == null) {
//			throw new UsernameNotFoundException("User not found with email: " + emailAddress);
//		} else {
//			return emlAdd;
//		}
//	}
	
	@GetMapping("/getEmailAndPasswordJwt/{email}")
	public Object getEmailAndPasswordJwt(@PathVariable String email) {
		return userService.getEmailAndPasswordJwt(email);
	}


	@GetMapping("/GetUsers/{orgId}/{pdtId}")
	public List<OrganizationUserDTO> getUsers(@PathVariable int orgId,@PathVariable int pdtId) {
		return userService.getUsers(orgId, pdtId);
	}
	
	@GetMapping("/GetAllUsers/{orgId}")
	public List<OrganizationUserDTO> getAllUsers(@PathVariable int orgId) {
		return userService.getAllUsers(orgId);
	}
	
	@GetMapping("/GetEmailAndPassword/{userId}")
	public EmailPasswordDTO getEmailAndPassword(@PathVariable int userId) {
		return userService.getEmailAndPassword(userId);
	}
	
	@DeleteMapping("/DeleteUser/{id}")
    public String deleteUser(@PathVariable int id)  { 
		Integer a = userRepo.getId(id);
		try {
		if (a != null) {
		userService.deleteUser(id);
        return "User deleted";
		}
        else {
			return "User cannot be deleted. Please enter a valid id";
		}
		} catch (Exception e) {
			if (e instanceof java.sql.SQLIntegrityConstraintViolationException) {
				return e.getMessage();
			}
			return e.getMessage();
		}
    }
	
	 @PutMapping("/UpdateUser")
     public String updateUser(@RequestBody UserDTO user) {
		 try {
		 userService.updateUser(user); 
		 int userId = user.getUserId();
			Optional<UsersEntity> check = userRepo.findById(userId);
			Boolean checkValue = check.isPresent();
			String result = "";
			if (checkValue == true) {
				result = "User updated successfully.";
				return result;
			} else {
				result = "Please enter a valid User Id.";
				return result;
			}
	 } catch (Exception e) {
			if (e instanceof java.sql.SQLIntegrityConstraintViolationException) {
				return e.getMessage();
			}
			return e.getMessage();
		}
   }
	 
	 @PutMapping("/editUser")
     public String editUser(@RequestBody UserDTO user) {
		 int userId = user.getUserId();
		 String email = userRepo.getEmail(userId);
		 String password = userRepo.getPassword(userId);
		 try {
			 if(!user.getEmailAddress().equals(email) || !user.getPassword().equals(password)) {
				 String result = "Email Address or Password cannot be updated.";
				 return result;
			 }
			 else {
		 userService.updateUser(user); 
		
			Optional<UsersEntity> check = userRepo.findById(userId);
			Boolean checkValue = check.isPresent();
			String result = "";
			if (checkValue == true) {
				result = "User updated successfully.";
				return result;
			} else {
				result = "Please enter a valid User Id.";
				return result;
			}
			 }
	 } catch (Exception e) {
			if (e instanceof java.sql.SQLIntegrityConstraintViolationException) {
				return e.getMessage();
			}
			return e.getMessage();
		}
   }
	 
//	@GetMapping("/user/email")
//	public ArrayList<String> getAllUsersEmail() {
//		Optional<ArrayList<String>> check = Optional.ofNullable(usersrepo.getAllUsersEmail());
//		boolean checkValue = check.isPresent();
//		if (checkValue == true) {
//			return userService.getAllUsersEmail();
//		} else {
//			return null;
//		}
//	}

	
	@GetMapping("/user/email/{productId}")
	public ArrayList<String> getAllUsersEmail(@PathVariable int productId) {
		Optional<ArrayList<String>> check = Optional.ofNullable(usersrepo.getAllUsersEmail(productId));
		boolean checkValue = check.isPresent();
		if (checkValue == true) {
			return userService.getAllUsersEmail(productId);
		} else {
			return null;
		}
	}

//	@GetMapping("/users/roles/ROLE_CONSUMER")
//	public ArrayList<String> getConsumerUsersEmail() {
//		Optional<ArrayList<String>> check = Optional.ofNullable(usersrepo.getConsumerUsersEmail());
//		boolean checkValue = check.isPresent();
//		if (checkValue == true) {
//			return userService.getConsumerUsersEmail();
//		} else {
//			return null;
//		}
//	}
	@GetMapping("/users/roles/ROLE_CONSUMER/{productId}")
	public ArrayList<String> getConsumerUsersEmail(@PathVariable int productId) {
		Optional<ArrayList<String>> check = Optional.ofNullable(usersrepo.getConsumerUsersEmail(productId));
		boolean checkValue = check.isPresent();
		if (checkValue == true) {
			return userService.getConsumerUsersEmail(productId);
		} else {
			return null;
		}
	}
	
	@RequestMapping(value="/orgname" ,method=RequestMethod.POST)
	public List<OrgNameDTO> gettotalapp(@RequestBody String emailId) {  
		return userService.getorgname(emailId);		
	}
	
	@PostMapping("/RegisterUser")
	public ResponseEntity<?> saveRegisterUser(@RequestBody UserDTO user) throws Exception {
		UsersEntity emailAddress = userRepo.findByEmailAddress(new String(Base64.getDecoder().decode(user.getEmailAddress())));
		Set<ConstraintViolation<UserDTO>> violations = validator.validate(user);
		if (emailAddress == null) {
	        if (!violations.isEmpty()) {
	            StringBuilder errorMessage = new StringBuilder();
	            for (ConstraintViolation<UserDTO> violation : violations) {
	                errorMessage.append(violation.getMessage()).append("\n");
	            }
	            return ResponseEntity.badRequest().body(errorMessage.toString());
	        }
	        if (user.hasSpecialCharacters()) {
	            return ResponseEntity.badRequest().body("Invalid input: Special characters '<' or '>' are not allowed.");
	        }
			return ResponseEntity.ok(userService.saveRegisteredUsers(user));
		} else {
			return new ResponseEntity<>("Email already exists", HttpStatus.BAD_REQUEST);
		}
	}
	
//	@PostMapping("/RegisterFastAPIUser")
//	public ResponseEntity<?> saveRegisterFastAPIUser(@RequestBody UserDTO user) throws Exception {
//		UsersEntity emailAddress = userRepo.findByEmailAddress(new String(Base64.getDecoder().decode(user.getEmailAddress())));
//		Set<ConstraintViolation<UserDTO>> violations = validator.validate(user);
//		if (emailAddress == null) {
//	        if (!violations.isEmpty()) {
//	            StringBuilder errorMessage = new StringBuilder();
//	            for (ConstraintViolation<UserDTO> violation : violations) {
//	                errorMessage.append(violation.getMessage()).append("\n");
//	            }
//	            return ResponseEntity.badRequest().body(errorMessage.toString());
//	        }
//	        if (user.hasSpecialCharacters()) {
//	            return ResponseEntity.badRequest().body("Invalid input: Special characters '<' or '>' are not allowed.");
//	        }
//			return ResponseEntity.ok(userService.saveRegisteredFastAPIUsers(user));
//		} else {
//			return new ResponseEntity<>("Email already exists", HttpStatus.BAD_REQUEST);
//		}
//	}
	
	@PostMapping("/RegisterFastAPIUser")
	public ResponseEntity<?> saveRegisterFastAPIUser(@RequestBody UserDTO user) throws Exception {
		UsersEntity emailAddress = userRepo
				.findByEmailAddress(new String(Base64.getDecoder().decode(user.getEmailAddress())));
		Set<ConstraintViolation<UserDTO>> violations = validator.validate(user);
		String userOrgName = user.getOrganization();
		Integer orgIdfromDb = orgRepo.checkOrgName(userOrgName);
		if (orgIdfromDb == null) {
			OrganizationEntity org = new OrganizationEntity();
			org.setOrgName(userOrgName);
			org.setOrgAdd(" ");
			org.setOrgPostCd(0);
			org.setOrgCntName(" ");
			org.setOrgCntNum(" ");
			org.setOrgCntMail(" ");
			org.setDescription(" ");
			org.setRecInsDt(Calendar.getInstance().getTime());
			org.setRecUpdDt(Calendar.getInstance().getTime());
			org.setIsActive(true);
			orgRepo.save(org);
			orgIdfromDb = org.getOrgId();
		}
		Date expDate = usersrepo.getExpirationDate(orgIdfromDb, user.getProductId());
		Date cDate = new Date();
		int key = licenseGeneratorrepo.checkLicenseKeyforProdOrgtn(user.getProductId(), orgIdfromDb);
		if (emailAddress == null) {
			if (!violations.isEmpty()) {
				StringBuilder errorMessage = new StringBuilder();
				for (ConstraintViolation<UserDTO> violation : violations) {
					errorMessage.append(violation.getMessage()).append("\n");
				}
				return ResponseEntity.badRequest().body(errorMessage.toString());
			}
			if (user.hasSpecialCharacters()) {
				return ResponseEntity.badRequest()
						.body("Invalid input: Special characters '<' or '>' are not allowed.");
			}
			if (key == 0) {
				return ResponseEntity.ok(userService.saveRegisteredFastAPIUsers(user, orgIdfromDb));
			} else if ((expDate != null) && expDate.compareTo(cDate) >= 0) {
				return ResponseEntity.ok(userService.saveRegisteredFastAPIUsers(user, orgIdfromDb));
			} else {
				return new ResponseEntity<>("Cannot register since your organization license has been expired.",
						HttpStatus.BAD_REQUEST);
			}
		} else {
			return new ResponseEntity<>("Email already exists", HttpStatus.BAD_REQUEST);
		}
	}
	
	@PostMapping("/inviteNewUser")
	public ResponseEntity<?> inviteNewUser(@RequestBody UserDTO user) throws Exception {
		UsersEntity emailAddress = userRepo.findByEmailAddress(new String(Base64.getDecoder().decode(user.getEmailAddress())));
		Set<ConstraintViolation<UserDTO>> violations = validator.validate(user);
		if (emailAddress == null) {
	        if (!violations.isEmpty()) {
	            StringBuilder errorMessage = new StringBuilder();
	            for (ConstraintViolation<UserDTO> violation : violations) {
	                errorMessage.append(violation.getMessage()).append("\n");
	            }
	            return ResponseEntity.badRequest().body(errorMessage.toString());
	        }
	        if (user.hasSpecialCharacters()) {
	            return ResponseEntity.badRequest().body("Invalid input: Special characters '<' or '>' are not allowed.");
	        }
	        String defaultPassword = generateDefaultPassword();
			return ResponseEntity.ok(userService.saveNewUsers(user,Base64.getEncoder().encodeToString(defaultPassword.getBytes())));
		} else {
			return new ResponseEntity<>("Email already exists", HttpStatus.BAD_REQUEST);
		}
	}
	
	private String generateDefaultPassword() {
		String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
		StringBuilder password = new StringBuilder();
		for (int i = 0; i < 8; i++) {
		int index = (int) (Math.random() * chars.length());
		password.append(chars.charAt(index));
		}
		return password.toString();
		}
	
		@PutMapping("/ChangeUserPassword")
		public ResponseEntity<?> changeUserPassword(@RequestBody UserIdPasswordDTO user) {
			try {

				int userId = user.getUserId();
				String oldPassword = userRepo.getPassword(userId);
				Optional<UsersEntity> check = userRepo.findById(userId);
				Boolean checkValue = check.isPresent();
				String result = "";
				Set<ConstraintViolation<UserIdPasswordDTO>> violations = validator.validate(user);
				if (checkValue == true) {
					if (!violations.isEmpty()) {
						StringBuilder errorMessage = new StringBuilder();
						for (ConstraintViolation<UserIdPasswordDTO> violation : violations) {
							errorMessage.append(violation.getMessage()).append("\n");
						}
						return ResponseEntity.badRequest().body(errorMessage.toString());
					}
					if (!user.hasSpecialCharacters()) {
						return ResponseEntity.badRequest().body(
								"Password should be atleast 8 characters with lowercase uppercase alphabets numbers and alphanumeric characters.");
					} 
					else if(user.getPassword().equals(oldPassword) ){
						result = "Passwords are same. Please enter different password.";
						return ResponseEntity.badRequest().body(result);
					}
					else {
						userService.changeUserPassword(user);
						result = "Password changed successfully.";
						return ResponseEntity.ok(result);
					}
				} else {
					result = "Please enter a valid User Id.";
					return ResponseEntity.badRequest().body(result);
				}
			} catch (Exception e) {
				if (e instanceof java.sql.SQLIntegrityConstraintViolationException) {
					return ResponseEntity.badRequest().body(e.getMessage());
				}
				return ResponseEntity.badRequest().body(e.getMessage());
			}
		}
		
		@GetMapping("/getUserId/{emailId}/{orgId}")
		public int getUserId(@PathVariable String emailId,@PathVariable int orgId) {
			return userService.getUserId(emailId,orgId);
		}
		 
}
