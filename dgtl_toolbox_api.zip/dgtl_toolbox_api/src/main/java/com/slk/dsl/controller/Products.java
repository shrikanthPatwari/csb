package com.slk.dsl.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.slk.dsl.model.ProductsEntity;
import com.slk.dsl.repository.ProductsRepo;
import com.slk.dsl.service.ProductsService;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class Products {
	
	@Autowired
	ProductsRepo productsRepo;
	
	@Autowired
	private ProductsService productsService;
	
	@PostMapping("/AddProducts")
	public ProductsEntity addProducts(@RequestBody ProductsEntity pdt) {
		return productsService.saveProducts(pdt);		
	}
	
	@GetMapping("/GetProducts")
	public List<ProductsEntity> getProducts() {
		return productsService.getProducts();
	}
	
	@DeleteMapping("/DeleteProducts/{id}")
	public String delete(@PathVariable int id) {
		Integer a = productsRepo.getId(id);
		try {
			if (a != null) {
				productsService.deleteProducts(id);
				return "Products deleted successfully.";
			} else {
				return "Products cannot be deleted. Please enter a valid id";
			}
		} catch (Exception e) {
			if (e instanceof java.sql.SQLIntegrityConstraintViolationException) {
				return e.getMessage();
			}
			return e.getMessage();
		}
	}
	
	  @PutMapping("/UpdateProducts")
		public String update(@RequestBody ProductsEntity pdt) {
		  productsService.updateProducts(pdt);
		  int productId = pdt.getProductId();
			Optional<ProductsEntity> check = productsRepo.findById(productId);
			Boolean checkValue = check.isPresent();
			String result = "";
			if (checkValue == true) {
				result = "Products Updated successfully.";
				return result;
			} else {
				result = "Please enter a valid Product Id.";
				return result;
			}
	  }

}
