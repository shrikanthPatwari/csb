package com.slk.dsl.service;

import java.util.Base64;
import java.util.Calendar;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.apache.commons.lang3.RandomStringUtils;
import com.slk.dsl.dto.ChatbotUserOrgDTO;
import com.slk.dsl.dto.DetailsDTO;
import com.slk.dsl.dto.MemberDetails;
import com.slk.dsl.dto.UserAndOrgDetailsDTO;
import com.slk.dsl.model.OrganizationEntity;
import com.slk.dsl.model.UsersEntity;
import com.slk.dsl.repository.OrganizationRepo;
import com.slk.dsl.repository.UsersRepo;

@Service
public class ChatbotUserOrgService {

	@Autowired
	UsersRepo userDao;

	@Autowired
	OrganizationRepo orgRepo;

	public ChatbotUserOrgDTO checkEmail(ChatbotUserOrgDTO userDetails) {
		UsersEntity user = addUserOrg(userDetails.getEmail(),3);
//		UsersEntity email = userDao.findByEmailAddress(userDetails.getEmail());
//		String EmailId = userDetails.getEmail();
//		String[] Value = EmailId.split("[@]");
//		String OrgName = Value[1];
//		String[] name = OrgName.split("[.]");
//		String userOrgName = name[0];
//		Integer orgIdfromDb = orgRepo.checkOrgName(userOrgName);
//
//		if (email == null) {
//			if (orgIdfromDb == null) {
//				OrganizationEntity org = new OrganizationEntity();
//				org.setOrgName(userOrgName);
//				org.setOrgAdd(" ");
//				org.setOrgPostCd(0);
//				org.setOrgCntName(" ");
//				org.setOrgCntNum(" ");
//				org.setOrgCntMail(" ");
//				org.setDescription(" ");
//				org.setRecInsDt(Calendar.getInstance().getTime());
//				org.setRecUpdDt(Calendar.getInstance().getTime());
//				org.setIsActive(true);
//				orgRepo.save(org);
//				orgIdfromDb = org.getOrgId();
//			}
//			UsersEntity user = new UsersEntity();
//			user.setFirstName(" ");
//			user.setLastName(" ");
//			user.setEmailAddress(userDetails.getEmail());
//			user.setRecInsDt(Calendar.getInstance().getTime());
//			user.setRecUpdDt(Calendar.getInstance().getTime());
//			user.setRoleId(2);
//			user.setOrgId(orgIdfromDb);
//			user.setProductId(5);
//			String password = " ";
//			for (int i = 0; i < 8; i++) {
//	              password = RandomStringUtils.randomAlphanumeric(8);
//	          }
//			user.setPassword(Base64.getEncoder().encodeToString(password.getBytes()));
//			user.setAccountNonLocked(true);
//			user.setFailedAttempt(0);
//			userDao.save(user);
//			ChatbotUserOrgDTO temp = new ChatbotUserOrgDTO();
//			temp.setEmail(user.getEmailAddress());
//			temp.setUserId(user.getUserId());
//			temp.setFirstName(user.getFirstName());
//			temp.setOrgId(user.getOrgId());
//			temp.setOrgName(orgRepo.getOrgNameforUser(user.getOrgId()));
//			return temp;
//
//		} else {
//			List<Object[]> data = userDao.getUserEmailDetails(EmailId);
			List<Object[]> data = userDao.getUserEmailDetails(userDetails.getEmail());
			ChatbotUserOrgDTO temp = new ChatbotUserOrgDTO();
			data.stream().forEach(obj -> {
				temp.setUserId((Integer) obj[0]);
				temp.setFirstName(obj[1].toString());
				temp.setOrgId((Integer) obj[2]);
				temp.setOrgName(obj[3].toString());
				temp.setEmail(userDetails.getEmail());
			});
			return temp;
//		}
	}
	public int saveUserAndOrg(UserAndOrgDetailsDTO userdetails) {
		UsersEntity user = addUserOrg(userdetails.getUserEmail(),2);
		int orgId = user.getOrgId();
		 for (DetailsDTO project : userdetails.getDetails()) {
	            for (MemberDetails member : project.getMembers()) {
	                UsersEntity user1 = addUserOrg(member.getUniqueName(),3);

	            }
	        }
		 return orgId;
}
	
	public UsersEntity addUserOrg(String emailId,int roleId) {
		UsersEntity user = new UsersEntity();
		UsersEntity email = userDao.findByEmailAddress(emailId);
		String EmailId = emailId;
		String[] Value = EmailId.split("[@]");
		String OrgName = Value[1];
		String[] name = OrgName.split("[.]");
		String userOrgName = name[0];
		Integer orgIdfromDb = orgRepo.checkOrgName(userOrgName);
	
		if (email == null) {
			if (orgIdfromDb == null) {
				OrganizationEntity org = new OrganizationEntity();
				org.setOrgName(userOrgName);
				org.setOrgAdd(" ");
				org.setOrgPostCd(0);
				org.setOrgCntName(" ");
				org.setOrgCntNum(" ");
				org.setOrgCntMail(" ");
				org.setDescription(" ");
				org.setRecInsDt(Calendar.getInstance().getTime());
				org.setRecUpdDt(Calendar.getInstance().getTime());
				org.setIsActive(true);
				orgRepo.save(org);
				orgIdfromDb = org.getOrgId();
			}
//			if(emailId.endsWith(userOrgName)) {
			user.setFirstName(" ");
			user.setLastName(" ");
			user.setEmailAddress(emailId);
			user.setRecInsDt(Calendar.getInstance().getTime());
			user.setRecUpdDt(Calendar.getInstance().getTime());
			user.setRoleId(roleId);
			user.setOrgId(orgIdfromDb);
			user.setProductId(5);
			String password = " ";
			for (int i = 0; i < 8; i++) {
	              password = RandomStringUtils.randomAlphanumeric(8);
	          }
			user.setPassword(Base64.getEncoder().encodeToString(password.getBytes()));
			user.setAccountNonLocked(true);
			user.setFailedAttempt(0);
			userDao.save(user);	
//			}
			return user;
		
	}else {		
		List<Object[]> data = userDao.getUserEmailDetails(EmailId);


	}
		return email;

		
}
}
