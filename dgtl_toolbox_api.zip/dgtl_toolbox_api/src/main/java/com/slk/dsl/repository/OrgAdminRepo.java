package com.slk.dsl.repository;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.slk.dsl.model.OrgAdminEntity;

@Repository
public interface OrgAdminRepo extends JpaRepository<OrgAdminEntity, Integer>{
	
	String getOrgAdmin = "SELECT oa.Org_Admin_Id, oa.Org_Id, oo.Org_Name, oa.User_Id, uu.user_name, oa.Rec_Ins_Dt, oa.Rec_Upd_Dt FROM tb_org_admin oa Left join tb_organization oo ON oa.Org_Id = oo.Org_Id  Left join tb_users uu ON oa.user_id = uu.user_id";
	@Query(value = getOrgAdmin, nativeQuery = true)
	public List<Object[]> getOrgAdmin();
	
	String getId = "Select IFNULL(Org_Admin_Id, 0) from tb_org_admin where Org_Admin_Id =:id";
	@Query(value = getId, nativeQuery = true)
	public Integer getId(int id);
	
	String deleteOrgAdmin = "delete from tb_org_admin where Org_Admin_Id=:id";
	@Modifying
	@Transactional
	@Query(value = deleteOrgAdmin, nativeQuery = true)
	public void deleteOrgAdmin(int id);
	
	String updateOrgAdmin = "update tb_org_admin set  Org_Id=:orgId, User_Id =:userId, Rec_Upd_Dt =:recUpdDt  where Org_Admin_Id=:orgAdminId";
	@Transactional
	@Modifying
	@Query(value = updateOrgAdmin, nativeQuery = true)
	public void updateOrgAdmin(int orgId,int userId,Date recUpdDt,int orgAdminId);


}
