package com.slk.dsl.controller;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.json.JSONObject;
import org.json.XML;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.slk.dsl.dto.LicTypePdtLicenseDTO;
import com.slk.dsl.dto.LicenseKeyDTO;
import com.slk.dsl.dto.MaxDeployCountDTO;
import com.slk.dsl.dto.OrgNameDTO;
import com.slk.dsl.dto.UserDTO;
import com.slk.dsl.model.LicenseEntity;
import com.slk.dsl.model.LicenseValidationEntity;
import com.slk.dsl.model.OrganizationEntity;
import com.slk.dsl.model.UsersEntity;
import com.slk.dsl.repository.LicenseGeneratorRepo;
import com.slk.dsl.repository.OrganizationRepo;
import com.slk.dsl.service.LicenseCryptography;
import com.slk.dsl.service.LicenseService;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class License {
	
	public static String Message="";
	public static String HowToResolve="";
	
	@Autowired
	LicenseService licenseService;
	
	@Autowired
	LicenseGeneratorRepo licenseGeneratorrepo;
	
	@Autowired
	OrganizationRepo orgRepo;
	
	@GetMapping("/GetLicense")
	public List<LicTypePdtLicenseDTO> getLicense() {
		return licenseService.getLicense();
	}
	
//	@PostMapping("/GenerateLicense")
//	public ResponseEntity<?> generateLicense(@RequestBody LicenseEntity lic) {
//		LicenseEntity email = licenseGeneratorrepo.findByEmail(lic.getEmail());
//		if (email == null) {
//		return new ResponseEntity<LicenseEntity>(licenseService.generateLicense(lic),HttpStatus.OK);
//		}
//		else {
//			return new ResponseEntity<>("Email already exists",HttpStatus.OK);
//		}		
//	}
	
	@PostMapping("/GenerateLicense")
	public ResponseEntity<?> generateLicense(@RequestBody LicenseEntity lic) {
		Integer orgIdfromDb = orgRepo.checkOrgName(lic.getOrganization());
		if (orgIdfromDb == null) {
			return new ResponseEntity<LicenseEntity>(licenseService.generateLicense(lic), HttpStatus.OK);
		} else {
			int key = licenseGeneratorrepo.checkLicenseKeyforProdOrg(lic.getProductId(), orgIdfromDb);
			if (key == 0) {
				return new ResponseEntity<LicenseEntity>(licenseService.generateLicense(lic), HttpStatus.OK);
			} else {
				return new ResponseEntity<>("License already exists for selected organisation and product.",
						HttpStatus.BAD_REQUEST);
			}
		}
	}
	
//	@RequestMapping(value = "/ValidateLicense", method = RequestMethod.POST)
//	public ArrayList<String> validateLicense(@RequestBody LicenseValidationEntity licenseDetails) {
//			LicenseEntity email = licenseGeneratorrepo.findByEmail(licenseDetails.getEmail());
//			if (email != null) {
//				List<Object[]> data = licenseGeneratorrepo.getDetails(licenseDetails.getEmail());
//				Calendar calendar = Calendar.getInstance();
//				calendar.set(Calendar.HOUR_OF_DAY, 0);
//				calendar.set(Calendar.MINUTE, 0);
//				calendar.set(Calendar.SECOND, 0);
//				calendar.set(Calendar.MILLISECOND, 0);
//				Date today = calendar.getTime();
//
//				data.stream().forEach(obj -> {
//					String key = obj[0].toString();
//					Date activationDate = (Date) obj[1];
//					Date expirationDate = (Date) obj[2];
//
//					if (licenseDetails.getLicenseKey().equals(key)) {
//						if (today.before(activationDate)) {
//							Message = "Your License Period starts from " + activationDate;
//							HowToResolve = " Please activate your License after " + activationDate;
//						} else if (today.before(expirationDate) || today.equals(expirationDate)) {
//							Message = "License Validated successfully! ";
//							HowToResolve = "Access is granted.";
//						} else {
//							Message = "Your License has been expired! ";
//							HowToResolve =  "Please contact your distributor/vendor to renew the license.";
//							
//						}
//					} else {
//						Message = "Invalid License Key. ";
//						HowToResolve = "Please provide a valid License Key";
//					}
//				});
//				ArrayList<String> reply = new ArrayList<String>();
//				reply.add(Message);
//				reply.add(HowToResolve);
//				return reply;
//			} else {
//				Message = "Email id is not valid. ";
//				HowToResolve = "Please enter valid email id";
//				ArrayList<String> reply = new ArrayList<String>();
//				reply.add(Message);
//				reply.add(HowToResolve);
//				return reply;
//			}
//	}
	
	@GetMapping("/getMaxDeploymentCount/{productId}/{orgId}")
	public int getMaxDeploymentCount(@PathVariable int productId,@PathVariable int orgId) {
		Integer check = licenseGeneratorrepo.getMaxDeploymentCount(productId,orgId);
		if (check != null ) {
			return check;
		} else {
			return 0;
		}
	}
	
	@PostMapping("/checkMaxDeployCount")
	public ResponseEntity<?> checkMaxDeployCount(@RequestBody MaxDeployCountDTO lic) {
		Integer check = licenseGeneratorrepo.getMaxDeploymentCount(lic.getProductId(), lic.getOrgId());
		if (check != null) {
			if (lic.getCount() <= check) {
				return new ResponseEntity<>("Deployment count is less than the maximum count. Please proceed with the deployments.", HttpStatus.OK);
			} else {
				return new ResponseEntity<>(
						"Deployment count exceeds the maximum count. Please contact the adminstrator.", HttpStatus.BAD_REQUEST);
			}
		} else {
			return new ResponseEntity<>("Deployment count is null.", HttpStatus.NOT_FOUND);
		}
	}
	
	@GetMapping("/GetLicenseDetails/{productId}/{orgId}")
	public String getLicenseDetails(@PathVariable int productId, @PathVariable int orgId) {
		String key = licenseGeneratorrepo.getLicenseDetails(productId, orgId);
		System.out.println("Key:" + key);
		if (key != null) {
			final String secretKey = "iamhidden$secret";
			String decryptedString = LicenseCryptography.decryptLicense(key, secretKey);
			JSONObject json = XML.toJSONObject(decryptedString);
			String jsonString = json.toString(4);
			return jsonString;
		} else {
			return null;
		}
	}
	
	@PutMapping("/updateLicense")
	public String updateLicense(@RequestBody LicenseKeyDTO lic) {
		licenseService.updateLicense(lic);
		return "License Updated Successfully";
	}

	
}
