package com.slk.dsl.model;



import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "tb_users")
public class UsersEntity {
@Id @GeneratedValue(strategy=GenerationType.IDENTITY)
@Column(name = "User_Id")
private int userId;

//@Column(name = "User_Name")
//private String userName;

@Column(name = "Org_Id")
private int orgId;


@Column(name = "Email_Address")
private String emailAddress;


//@Column(name = "Contact_Number")
//private String contactNumber;
//
//@Column(name = "Address")
//private String address;

//@Column(name = "Last_Login")
//private Date lastLogin;

@Column(name = "Password")
private String password;

@Column(name = "Rec_Ins_Dt")
private Date recInsDt;

@Column(name = "Rec_Upd_Dt")
private Date recUpdDt;

@Column(name = "First_Name")
private String firstName;

@Column(name = "Last_Name")
private String lastName;

@Column(name = "Role_Id")
private int roleId;

@Column(name = "Product_Id")
private int productId;

@Column(name = "reset_password_token")
private String resetPasswordToken;

@Column(name = "Account_Non_Locked")
private boolean accountNonLocked;
 
@Column(name = "Failed_Attempt")
private int failedAttempt;
 
@Column(name = "Lock_Time")
private Date lockTime;

@Transient
@Column(name="days_left")
private long daysLeft;

public long getDaysLeft() {
	return daysLeft;
}

public void setDaysLeft(long balanceDays) {
	this.daysLeft = balanceDays;
}

public boolean isAccountNonLocked() {
	return accountNonLocked;
}

public void setAccountNonLocked(boolean accountNonLocked) {
	this.accountNonLocked = accountNonLocked;
}

public int getFailedAttempt() {
	return failedAttempt;
}

public void setFailedAttempt(int failedAttempt) {
	this.failedAttempt = failedAttempt;
}

public Date getLockTime() {
	return lockTime;
}

public void setLockTime(Date lockTime) {
	this.lockTime = lockTime;
}

public int getProductId() {
	return productId;
}

public void setProductId(int productId) {
	this.productId = productId;
}

public String getResetPasswordToken() {
	return resetPasswordToken;
}

public void setResetPasswordToken(String resetPasswordToken) {
	this.resetPasswordToken = resetPasswordToken;
}

public int getUserId() {
	return userId;
}

public void setUserId(int userId) {
	this.userId = userId;
}

//public String getUserName() {
//	return userName;
//}
//
//public void setUserName(String userName) {
//	this.userName = userName;
//}

public int getOrgId() {
	return orgId;
}

public void setOrgId(int orgId) {
	this.orgId = orgId;
}

public String getEmailAddress() {
	return emailAddress;
}

public void setEmailAddress(String emailAddress) {
	this.emailAddress = emailAddress;
}

//public String getContactNumber() {
//	return contactNumber;
//}
//
//public void setContactNumber(String contactNumber) {
//	this.contactNumber = contactNumber;
//}
//
//public String getAddress() {
//	return address;
//}
//
//public void setAddress(String address) {
//	this.address = address;
//}

//public Date getLastLogin() {
//	return lastLogin;
//}
//
//public void setLastLogin(Date lastLogin) {
//	this.lastLogin = lastLogin;
//}

public String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}

public Date getRecInsDt() {
	return recInsDt;
}

public void setRecInsDt(Date recInsDt) {
	this.recInsDt = recInsDt;
}

public Date getRecUpdDt() {
	return recUpdDt;
}

public void setRecUpdDt(Date recUpdDt) {
	this.recUpdDt = recUpdDt;
}

public String getFirstName() {
	return firstName;
}

public void setFirstName(String firstName) {
	this.firstName = firstName;
}

public String getLastName() {
	return lastName;
}

public void setLastName(String lastName) {
	this.lastName = lastName;
}

public int getRoleId() {
	return roleId;
}

public void setRoleId(int roleId) {
	this.roleId = roleId;
}

@PrePersist
private void onCreate() {
    this.recInsDt = new Date();
}

@PreUpdate
protected void onUpdate() {
    this.recUpdDt = new Date();
}

}

