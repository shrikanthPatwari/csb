package com.slk.dsl.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Transient;

public class CheckLicenseResponse implements Serializable{
	private  long data;
	private  String message;
	
	@Transient
	private List<String> connectorName;
	
	@Transient
	private List<String> connectorType;
	
	public CheckLicenseResponse(long data, String message,List<String> connectorName,List<String> connectorType) {
		super();
		this.data = data;
		this.message = message;
		this.connectorName = connectorName;
		this.connectorType = connectorType;
	}

	public long getData() {
		return data;
	}

	public void setData(long data) {
		this.data = data;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public List<String> getConnectorName() {
		return connectorName;
	}

	public void setConnectorName(List<String> connectorName) {
		this.connectorName = connectorName;
	}

	public List<String> getConnectorType() {
		return connectorType;
	}

	public void setConnectorType(List<String> connectorType) {
		this.connectorType = connectorType;
	}
	
	
	
	
}
