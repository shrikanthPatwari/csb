package com.slk.dsl.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.slk.dsl.dto.OrgUserOrgAdminDTO;
import com.slk.dsl.model.OrgAdminEntity;
import com.slk.dsl.repository.OrgAdminRepo;
import com.slk.dsl.service.OrgAdminService;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class OrgAdmin {
	
	@Autowired
	private OrgAdminService orgAdminService;
	
	@Autowired
	OrgAdminRepo orgAdminRepo; 
	
	@PostMapping("/AddOrgAdmin")
	public OrgAdminEntity addOrgAdmin(@RequestBody OrgAdminEntity orgAdmin) {
		return orgAdminService.saveOrgAdmin(orgAdmin);
	}
	
	@GetMapping("/OrgAdmin")  
	public List<OrgUserOrgAdminDTO> allOrgAdmin() {  
	     return orgAdminService.getOrgAdmin();	      
	}
	
	@DeleteMapping("/DeleteOrgAdmin/{id}")
	public String delete(@PathVariable int id) {
		Integer a = orgAdminRepo.getId(id);
		try {
			if (a != null) {
				orgAdminService.deleteOrgAdmin(id);
				return "Org Admin deleted successfully.";
			} else {
				return "Org Admin cannot be deleted. Please enter a valid id";
			}
		} catch (Exception e) {
			if (e instanceof java.sql.SQLIntegrityConstraintViolationException) {
				return e.getMessage();
			}
			return e.getMessage();
		}
	}
	
	  @PutMapping("/UpdateOrgAdmin")
		public String update(@RequestBody OrgAdminEntity orgAdmin) {
		  try {
		  orgAdminService.updateOrgAdmin(orgAdmin);	
		  int orgAdminId = orgAdmin.getOrgAdminId();
			Optional<OrgAdminEntity> check = orgAdminRepo.findById(orgAdminId);
			Boolean checkValue = check.isPresent();
			String result = "";
			if (checkValue == true) {
				result = "Org Admin Updated successfully.";
				return result;
			} else {
				result = "Please enter a valid Org Admin Id.";
				return result;
			}
		  }
		  catch (Exception e) {
				if (e instanceof java.sql.SQLIntegrityConstraintViolationException) {
					return e.getMessage();
				}
				return e.getMessage();
			}
	  }

}
