package com.slk.dsl.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.slk.dsl.model.LicenseEntity;
import com.slk.dsl.model.UsersEntity;

@Repository
public interface LicenseGeneratorRepo extends JpaRepository<LicenseEntity, Integer>{
	
//	LicenseEntity findByEmail(String email);
	
//	String licenseUsersCount = "SELECT count(Email_Address) FROM digital_toolbox.tb_users";
//	@Query(value = licenseUsersCount, nativeQuery = true)
//	public int getLicenseUsersCount();
	
	String licenseUsersCount = "SELECT count(Email_Address) FROM digital_toolbox.tb_users where Org_Id=:orgId and Product_Id =:productId ";
	@Query(value = licenseUsersCount, nativeQuery = true)
	public int getLicenseUsersCount(int orgId, int productId);
	
	String licenseDetails = "Select License_Key, Activation_Date, Expiration_Date from tb_license where Email =:email";
	@Query(value = licenseDetails, nativeQuery = true)
	public List<Object[]> getDetails(String email);
	
//	String getLicense = "SELECT tl.License_Id, tl.User_Name, tl.Email, tl.License_Type_Id, lt.License_Type, tl.Activation_Date, tl.Expiration_Date, lt.Rec_Ins_Dt, lt.Rec_Upd_Dt FROM tb_license tl LEFT JOIN tb_license_type lt ON tl.License_Type_Id=lt.License_Type_Id order by License_Id";
//	@Query(value = getLicense, nativeQuery = true)
//	public List<Object[]> getLicense();
	
	String getLicense =  "select tl.License_Id, tu.First_Name as User_Name, tu.Email_Address as Email, tl.License_Type_Id, lt.License_Type, tl.Activation_Date, tl.Expiration_Date, lt.Rec_Ins_Dt, lt.Rec_Upd_Dt , tog.Org_Name, tp.Product_Name from tb_users tu left join tb_license tl ON (tu.Org_Id = tl.Org_Id AND tu.Product_Id = tl.Product_Id ) LEFT JOIN tb_license_type lt ON tl.License_Type_Id=lt.License_Type_Id LEFT JOIN tb_organization tog ON tu.Org_Id = tog.Org_Id LEFT JOIN tb_products tp ON tu.Product_Id = tp.Product_Id where tl.Expiration_Date > now() order by User_Id desc";
	@Query(value = getLicense, nativeQuery = true)
	public List<Object[]> getLicense();
	
	String checkLicenseKeyforProdOrg = "Select count(License_Key) From tb_license where Product_Id=:productId and Org_Id=:orgId and NOW()<Expiration_Date";
	@Query(value = checkLicenseKeyforProdOrg, nativeQuery = true)
	public int checkLicenseKeyforProdOrg(int productId, int orgId);
	
	String checkLicenseKeyforProdOrgtn = "Select count(License_Key) From tb_license where Product_Id=:productId and Org_Id=:orgId";
	@Query(value = checkLicenseKeyforProdOrgtn, nativeQuery = true)
	public int checkLicenseKeyforProdOrgtn(int productId, int orgId);
	
	String getOrgName =  "Select Org_Name from tb_organization where Org_Id=:orgId";
	@Query(value = getOrgName, nativeQuery = true)
	public String getOrgName(int orgId);
	
	String getMaxDeploymentCount = "Select Max_Deployments From tb_license where Product_Id=:productId and Org_Id=:orgId and NOW()<Expiration_Date";
	@Query(value = getMaxDeploymentCount, nativeQuery = true)
	public Integer getMaxDeploymentCount(int productId, int orgId);
	
	String getRoleName =  "Select Role_Name From tb_roles where Role_Id=:roleId";
	@Query(value = getRoleName, nativeQuery = true)
	public String[] getRoleName(int roleId);
	
	String getLastLicenseId = "Select Max(License_Id)+1 from tb_license";
	@Query(value = getLastLicenseId, nativeQuery = true)
	public int getLastLicenseId();
	
	String getLicenseDetails = "Select License_Key From tb_license where Product_Id=:productId and Org_Id=:orgId and NOW()<Expiration_Date";
	@Query(value = getLicenseDetails, nativeQuery = true)
	public String getLicenseDetails(int productId, int orgId);
	
	
    String updateLicense = "update tb_license set License_Key =:licenseKey, Rec_Upd_Dt =:recUpdDt, Product_Id =:productId where License_Id=:licenseId";
    @Transactional
    @Modifying
    @Query(value = updateLicense, nativeQuery = true)
    public void updateLicense(int licenseId,String licenseKey,Date recUpdDt,int productId);
    
	String getByLicenseId = "Select License_Id, License_Key, License_Type_Id, Activation_Date, Expiration_Date, Rec_Ins_Dt, Rec_Upd_Dt, Product_Id, Org_Id, Max_Deployments from tb_license where License_Id=:licenseId";
	@Query(value = getByLicenseId, nativeQuery = true)
	public LicenseEntity getByLicenseId(int licenseId);
	
    String updateNewLicense = "update tb_license set License_Key =:licenseKey, Product_Id =:productId where License_Id=:licenseId";
    @Transactional
    @Modifying
    @Query(value = updateNewLicense, nativeQuery = true)
    public void updateNewLicense(int licenseId,int productId,String licenseKey);
    
	String getKeyByLicenseId = "Select License_Key from tb_license where License_Id=:licenseId";
	@Query(value = getKeyByLicenseId, nativeQuery = true)
	public String getKeyByLicenseId(int licenseId);

	String getConnectorId = "select Connector_Id FROM digital_toolbox.tb_connector";
	@Query(value = getConnectorId, nativeQuery = true)
	public int[] getConnectorId();
	
	String getConnectorName =  "select Connector_Name FROM digital_toolbox.tb_connector";
	@Query(value = getConnectorName, nativeQuery = true)
	public String[] getConnectorName();
	
	String getConnectorType =  "select Connector_Type FROM digital_toolbox.tb_connector";
	@Query(value = getConnectorType, nativeQuery = true)
	public String[] getConnectorType();
	
}
