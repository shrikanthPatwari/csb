package com.slk.dsl.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

@Entity
@Table(name = "tb_product_features")
public class ProductFeaturesEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Product_Features_Id")
	private int productFeaturesId;

	@Column(name = "Features")
	private String features;

	@Column(name = "Pdt_License_Type_Id")
	private int pdtLicenseTypeId;

	@Column(name = "Product_Id")
	private int productId;

	@Column(name = "Rec_Ins_Dt")
	private Date recInsDt;

	@Column(name = "Rec_Upd_Dt")
	private Date recUpdDt;

	public int getProductFeaturesId() {
		return productFeaturesId;
	}

	public void setProductFeaturesId(int productFeaturesId) {
		this.productFeaturesId = productFeaturesId;
	}

	public String getFeatures() {
		return features;
	}

	public void setFeatures(String features) {
		this.features = features;
	}

	public int getPdtLicenseTypeId() {
		return pdtLicenseTypeId;
	}

	public void setPdtLicenseTypeId(int pdtLicenseTypeId) {
		this.pdtLicenseTypeId = pdtLicenseTypeId;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public Date getRecInsDt() {
		return recInsDt;
	}

	public void setRecInsDt(Date recInsDt) {
		this.recInsDt = recInsDt;
	}

	public Date getRecUpdDt() {
		return recUpdDt;
	}

	public void setRecUpdDt(Date recUpdDt) {
		this.recUpdDt = recUpdDt;
	}
	
	@PrePersist
	private void onCreate() {
		this.recInsDt = new Date();
	}

	@PreUpdate
	protected void onUpdate() {
		this.recUpdDt = new Date();
	}
	

}
