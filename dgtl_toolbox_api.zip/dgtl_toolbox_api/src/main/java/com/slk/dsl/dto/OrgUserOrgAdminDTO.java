package com.slk.dsl.dto;

import java.util.Date;

import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

public class OrgUserOrgAdminDTO {
	
	private int orgAdminId;
	private int orgId;
	private String orgName;
	private int userId;
	private String userName;
	private Date recInsDt;
	private Date recUpdDt;
	
	public int getOrgAdminId() {
		return orgAdminId;
	}

	public void setOrgAdminId(int orgAdminId) {
		this.orgAdminId = orgAdminId;
	}

	public int getOrgId() {
		return orgId;
	}

	public void setOrgId(int orgId) {
		this.orgId = orgId;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public Date getRecInsDt() {
		return recInsDt;
	}

	public void setRecInsDt(Date recInsDt) {
		this.recInsDt = recInsDt;
	}

	public Date getRecUpdDt() {
		return recUpdDt;
	}

	public void setRecUpdDt(Date recUpdDt) {
		this.recUpdDt = recUpdDt;
	}

	@PrePersist
	private void onCreate() {
		this.recInsDt = new Date();
	}

	@PreUpdate
	protected void onUpdate() {
		this.recUpdDt = new Date();
	}

}
