package com.slk.dsl.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slk.dsl.model.ConnectorEntity;
import com.slk.dsl.repository.ConnectorRepo;

@Service
public class ConnectorService {
	
	@Autowired
	ConnectorRepo connectorRepo;
	
	public List<ConnectorEntity>  getConnectors(){
		 return connectorRepo.findAll();  
	}
	
	public ConnectorEntity saveConnector(ConnectorEntity contr) {
		// TODO Auto-generated method stub
		ConnectorEntity connector = new ConnectorEntity();			
		connector.setConnectorId(contr.getConnectorId());
		connector.setConnectorName(contr.getConnectorName());
		connector.setConnectorType(contr.getConnectorType());
		connector.setDescription(contr.getDescription());
		connector.setRecInsDt(contr.getRecInsDt());
		connector.setRecUpdDt(contr.getRecUpdDt());
		return connectorRepo.save(connector);
	}
	
	public String deleteConnector(int id) {	
		connectorRepo.deleteConnector(id);
		  return "Connector deleted successfully.";
	}
	
	public String updateConnector(ConnectorEntity contr) {
        String connectorName=contr.getConnectorName();
        String connectorType=contr.getConnectorType();
        String description=contr.getDescription();
        Date recUpdDt = new Date();
        int connectorId = contr.getConnectorId();
        connectorRepo.updateConnector(connectorName,connectorType,description,recUpdDt,connectorId);	
        return "Connector Updated successfully.";
	}

}
