package com.slk.dsl.repository;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.slk.dsl.model.UsersEntity;

@Repository
public interface UsersRepo extends JpaRepository<UsersEntity, Integer> { 
     
    public UsersEntity findByResetPasswordToken(String token);

	String getUsers = "select usr.User_Id, org.Org_Name, usr.Email_Address, usr.Org_Id ,  usr.Password , usr.Rec_Ins_Dt, usr.Rec_Upd_Dt, usr.First_Name, usr.Last_Name, usr.Role_Id, tr.Role_Name from tb_users usr Left join tb_organization org ON usr.Org_Id = org.Org_Id Left join tb_roles tr ON usr.Role_Id = tr.Role_Id where usr.Org_Id=:orgId and usr.Product_Id=:pdtId";

	@Query(value = getUsers, nativeQuery = true)
	public List<Object[]> getUsers(int orgId, int pdtId);
	
	String getAllUsers = "select usr.User_Id, org.Org_Name, usr.Email_Address, usr.Org_Id ,  usr.Password , usr.Rec_Ins_Dt, usr.Rec_Upd_Dt, usr.First_Name, usr.Last_Name, usr.Role_Id, tr.Role_Name from tb_users usr Left join tb_organization org ON usr.Org_Id = org.Org_Id Left join tb_roles tr ON usr.Role_Id = tr.Role_Id where usr.Org_Id=:orgId";

	@Query(value = getAllUsers, nativeQuery = true)
	public List<Object[]> getAllUsers(int orgId);
	
	 String deleteUser = "delete from tb_users where User_Id=:id";
	    @Modifying
	    @Transactional
	    @Query(value = deleteUser, nativeQuery = true)
	    public void deleteUser(int id);
	    
	    String updateUser = "update tb_users set Email_Address =:emailAddress, Rec_Upd_Dt =:recUpdDt, Org_Id =:orgId, First_Name =:firstName, Last_Name =:lastName, Role_Id =:roleId where User_Id=:userId";
	    @Transactional
	    @Modifying
	    @Query(value = updateUser, nativeQuery = true)
	    public void updateUser(int userId,String emailAddress,Date recUpdDt,int orgId, String firstName, String lastName, int roleId);

	    String password = "select Password from tb_users where Email_Address= :emailid";
		@Query(value = password, nativeQuery = true)
		public String getPasswordforUser(String emailid);
		
//	    String userAttempts = "select User_Attempts from tb_users where Email_Address= :emailid";
//		@Query(value = userAttempts, nativeQuery = true)
//		public int getUserAttempts(String emailid);
		
	    String userAttempts = "update tb_users set Failed_Attempt=:failAttempts  where (Email_Address=:email and User_Id<>0)";
	    @Modifying
	    @Transactional
	    @Query(value = userAttempts, nativeQuery = true)
	    public void updateFailedAttempts(int failAttempts, String email);
	    
	    String successAttempts = "UPDATE tb_users SET Failed_Attempt = 0, Account_Non_Locked = 1, Lock_Time = NULL WHERE (Email_Address=:email and User_Id<>0)";
	    @Modifying
	    @Transactional
	    @Query(value = successAttempts, nativeQuery = true)
	    public void updateSuccessAttempts(String email);
	    
		UsersEntity findByEmailAddress(String emailAddress);
		

		
	    String orgId = "select Org_Id from tb_users where Email_Address= :emailid";
		@Query(value = orgId, nativeQuery = true)
		public int getOrgId(String emailid);
		
	    String orgName = "select tob.Org_Name from tb_users tu left join tb_Organization tob on tu.Org_Id = tob.Org_Id  where tu.Email_Address= :emailid";
		@Query(value = orgName, nativeQuery = true)
		public String getOrgName(String emailid);
		
	    String userDetails = "Select tu.First_Name, tu.Last_Name, tu.Role_Id, tr.Role_Name, tu.User_Id, tu.Email_Address, CONCAT (tu.First_Name,' ',tu.Last_Name) AS UserName, tu.Product_Id , ifnull(Max_Deployments,0) as Max_Deployments from tb_users tu join tb_roles tr ON tu.Role_Id = tr.Role_Id left join tb_license tl ON tu.Org_Id = tl.Org_Id and tu.Product_Id= tl.Product_Id and NOW()<tl.Expiration_Date where tu.Email_Address=:emailid";
		@Query(value = userDetails, nativeQuery = true)
		public List<Object[]> getUserDetails(String emailid);
		
		String getAllUsersEmail = "Select Email_Address from tb_users";
		@Query(value = getAllUsersEmail, nativeQuery = true)
		public ArrayList<String> getAllUsersEmail();
		
		String getAllUsersEmails = "Select Email_Address from tb_users where Product_Id=:productId";
		@Query(value = getAllUsersEmails, nativeQuery = true)
		public ArrayList<String> getAllUsersEmail(int productId);
		
		String getConsumerUsersEmail = "Select tu.Email_Address  from tb_users tu JOIN tb_roles tr ON tu.Role_Id = tr.Role_Id AND tr.Role_Type = 'consumer'";
		@Query(value = getConsumerUsersEmail, nativeQuery = true)
		public ArrayList<String> getConsumerUsersEmail();
		
		String getConsumerUsersEmails = "Select tu.Email_Address  from tb_users tu JOIN tb_roles tr ON tu.Role_Id = tr.Role_Id AND tr.Role_Type = 'consumer' AND tu.Product_Id=:productId";
		@Query(value = getConsumerUsersEmails, nativeQuery = true)
		public ArrayList<String> getConsumerUsersEmail(int productId);
		
		String orgname = "Select tbo.Org_Name as org_name, tbo.Org_Id, tbu.Role_Id as user_role_id, tbu.First_Name, tbu.Last_Name, tbu.User_Id as usr_id From digital_toolbox.tb_organization tbo inner join digital_toolbox.tb_users tbu On tbu.Org_Id = tbo.Org_Id where tbu.Email_Address =:emailId";
		@Query(value = orgname, nativeQuery = true)
		public List<Object[]> getorgname(String emailId);
		
		String getEmailDetails = "Select usr.User_Id,usr.First_Name,usr.Org_Id,org.Org_Name from tb_users usr inner join tb_organization org where usr.Email_Address=:email and usr.Org_Id = org.Org_Id";
		@Query(value = getEmailDetails, nativeQuery = true)
		public List<Object[]> getUserEmailDetails(String email);
		
		
		String getEmailAndPassword = "select Email_Address,Password from tb_users where User_Id=:userId";
		@Query(value = getEmailAndPassword, nativeQuery = true)
		public List<Object[]> getEmailAndPassword(Integer userId);
		
		String getEmailAndPasswordJwt = "select Email_Address,Password from tb_users where Email_Address=:email";
		@Query(value = getEmailAndPasswordJwt, nativeQuery = true)
		public List<Object[]> getEmailAndPasswordJwt(String email);
		
		String getByEmail = "Select * from tb_users where Email_Address=:email";
		@Query(value = getByEmail, nativeQuery = true)
		public UsersEntity getByEmail(String email);
		
	    String userlicenseDetails = "Select ifnull(tl.License_Key,0) as License_Key,  ifnull(tl.Activation_Date,0) as Activation_Date,ifnull(tl.Expiration_Date,0) as Expiration_Date, tu.Product_Id from tb_users tu join tb_roles tr ON tu.Role_Id = tr.Role_Id left join tb_license tl ON tu.Org_Id = tl.Org_Id and tu.Product_Id= tl.Product_Id and tl.Expiration_Date >NOW() where tu.Email_Address=:emailid";
		@Query(value = userlicenseDetails, nativeQuery = true)
		public List<Object[]> userlicenseDetails(String emailid);
		
		String getExpirationDate = "select Expiration_Date from tb_license where Org_Id=:orgId and Product_Id=:productId and Expiration_Date >NOW()";
		@Query(value = getExpirationDate, nativeQuery = true)
		public Date getExpirationDate(int orgId, int productId);
		
	    String changeUserPassword = "update tb_users set Password =:password, Rec_Upd_Dt =:recUpdDt where User_Id=:userId";
	    @Transactional
	    @Modifying
	    @Query(value = changeUserPassword, nativeQuery = true)
	    public void changeUserPassword(int userId,String password,Date recUpdDt);
	    
	    String getUserId = "Select User_Id from tb_users where Email_Address=:emailId and Org_Id=:orgId";
		@Query(value = getUserId, nativeQuery = true)
		public int getUserId(String emailId,int orgId);
		
		
}


