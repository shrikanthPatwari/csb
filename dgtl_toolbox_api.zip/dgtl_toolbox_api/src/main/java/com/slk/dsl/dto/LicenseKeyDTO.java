package com.slk.dsl.dto;


public class LicenseKeyDTO  {
	private int licenseId;
//	private Object licenseKey; 
	private int productId;
	
	public int getLicenseId() {
		return licenseId;
	}
	public void setLicenseId(int licenseId) {
		this.licenseId = licenseId;
	}
//	public Object getLicenseKey() {
//		System.out.println("s:"+licenseKey);
//		String s=licenseKey.toString(); 
//		return s;
//	}
//	public void setLicenseKey(Object licenseKey) {
//		this.licenseKey = licenseKey;
//	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	

}
