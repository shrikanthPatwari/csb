package com.slk.dsl.dto;

import java.nio.charset.StandardCharsets;

import java.util.regex.Pattern;

import org.apache.commons.codec.binary.Base64;

public class UserIdPasswordDTO {
    private int userId;
    private String password;
    
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
    public String getDecryptedField() {
        String decryptedField1 = decryptField(password);
        return decryptedField1 ;
    }

    private String decryptField(String encryptedField) {
        byte[] decodedBytes = Base64.decodeBase64(encryptedField);
        return new String(decodedBytes, StandardCharsets.UTF_8);
    }
    
    public boolean hasSpecialCharacters() {
        return Pattern.matches("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z]).{8,}$", getDecryptedField());
    }
    
    

}
