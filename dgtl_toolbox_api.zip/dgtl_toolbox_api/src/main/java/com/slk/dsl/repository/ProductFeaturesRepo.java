package com.slk.dsl.repository;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.slk.dsl.model.ProductFeaturesEntity;

@Repository
public interface ProductFeaturesRepo extends JpaRepository<ProductFeaturesEntity, Integer>{
	
	String getProductFeatures = "SELECT lpf.Product_Features_Id, lpf.Product_Id, pdt.Product_Name, lpf.Pdt_License_Type_Id, lt.License_Type, lpf.Features, lpf.Rec_Ins_Dt, lpf.Rec_Upd_Dt FROM tb_product_features lpf Left join tb_products pdt ON lpf.Product_Id = pdt.Product_Id Left join tb_license_type lt ON lpf.Pdt_License_Type_Id = lt.License_Type_Id";
	@Query(value = getProductFeatures, nativeQuery = true)
	public List<Object[]> getProductFeatures();
	
	String getId = "Select IFNULL(Product_Features_Id, 0) from tb_product_features where Product_Features_Id =:id";
	@Query(value = getId, nativeQuery = true)
	public Integer getId(int id);
	
	String deleteProductFeatures = "delete from tb_product_features where Product_Features_Id=:id";
	@Modifying
	@Transactional
	@Query(value = deleteProductFeatures, nativeQuery = true)
	public void deleteProductFeatures(int id);
	
	String updateProductFeatures = "update tb_product_features set  Product_Id=:productId, Pdt_License_Type_Id =:pdtLicenseTypeId, Features =:features, Rec_Upd_Dt =:recUpdDt  where Product_Features_Id=:productFeaturesId";
	@Transactional
	@Modifying
	@Query(value = updateProductFeatures, nativeQuery = true)
	public void updateProductFeatures(int productId,int pdtLicenseTypeId,String features,Date recUpdDt,int productFeaturesId);

}
