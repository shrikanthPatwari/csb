package com.slk.dsl.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

@Entity
@Table(name="tb_license_type")
public class LicenseTypeEntity {
	
	@Id @GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="License_Type_Id")
	private int licenseTypeId;
	
	@Column(name="License_Type")
   private String licenseType;
	
	@Column(name="Description")
	private String description;
	
	@Column(name = "Rec_Ins_Dt")
	private Date recInsDt;

	@Column(name = "Rec_Upd_Dt")
	private Date recUpdDt;
	
	public int getLicenseTypeId() {
		return licenseTypeId;
	}

	public void setLicenseTypeId(int licenseTypeId) {
		this.licenseTypeId = licenseTypeId;
	}

	public String getLicenseType() {
		return licenseType;
	}

	public void setLicenseType(String licenseType) {
		this.licenseType = licenseType;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getRecInsDt() {
		return recInsDt;
	}

	public void setRecInsDt(Date recInsDt) {
		this.recInsDt = recInsDt;
	}

	public Date getRecUpdDt() {
		return recUpdDt;
	}

	public void setRecUpdDt(Date recUpdDt) {
		this.recUpdDt = recUpdDt;
	}

	@PrePersist
	private void onCreate() {
		this.recInsDt = new Date();
	}

	@PreUpdate
	protected void onUpdate() {
		this.recUpdDt = new Date();
	}

}
