package com.slk.dsl.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.slk.dsl.model.ConnectorEntity;
import com.slk.dsl.repository.ConnectorRepo;
import com.slk.dsl.service.ConnectorService;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class Connector {
	
	@Autowired
	ConnectorService connectorService;
	
	@Autowired
	ConnectorRepo connectorRepo;
	
	@GetMapping("/Connector")  
	public List<ConnectorEntity> getConnectors() {  
	     return connectorService.getConnectors();	      
	}
	
	@PostMapping("/AddConnector")
	public ConnectorEntity addConnector(@RequestBody ConnectorEntity connector) {
		return connectorService.saveConnector(connector);
	}
	
	@DeleteMapping("/DeleteConnector/{id}")
	public String delete(@PathVariable int id) {
		Integer a = connectorRepo.getId(id);
		try {
			if (a != null) {
				connectorService.deleteConnector(id);
				return "Connector deleted successfully.";
			} else {
				return "Connector cannot be deleted. Please enter a valid id";
			}
		} catch (Exception e) {
			if (e instanceof java.sql.SQLIntegrityConstraintViolationException) {
				return e.getMessage();
			}
			return e.getMessage();
		}
	}
	
	@PutMapping("/UpdateConnector")
	public String update(@RequestBody ConnectorEntity cntr) {
		connectorService.updateConnector(cntr);
		 int connectorId = cntr.getConnectorId();
		Optional<ConnectorEntity> check = connectorRepo.findById(connectorId);
		Boolean checkValue = check.isPresent();
		String result = "";
		if (checkValue == true) {
			result = "Connector Updated successfully.";
			return result;
		} else {
			result = "Please enter a valid Connector Id.";
			return result;
		}
	}

}
