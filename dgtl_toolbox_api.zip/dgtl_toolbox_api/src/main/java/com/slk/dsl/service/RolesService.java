package com.slk.dsl.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slk.dsl.model.RolesEntity;
import com.slk.dsl.repository.RolesRepo;

@Service
public class RolesService {
	
	@Autowired
	RolesRepo rolesRepo;
	
	public List<RolesEntity>  getRoles(){
		 return rolesRepo.findAll();  
	}
	
	public RolesEntity saveRoles(RolesEntity roles) {
		// TODO Auto-generated method stub
		RolesEntity role = new RolesEntity();			
		role.setRoleId(roles.getRoleId());
		role.setRoleName(roles.getRoleName());
		role.setRoleType(roles.getRoleType());
		role.setRoleDescription(roles.getRoleDescription());
		role.setRecInsDt(roles.getRecInsDt());
		role.setRecUpdDt(roles.getRecUpdDt());
		return rolesRepo.save(role);
	}
	
	public String deleteRoles(int id) {	
		rolesRepo.deleteRoles(id);
		  return "Role deleted successfully.";
	}
	
	public String updateRoles(RolesEntity roles) {
        String roleName=roles.getRoleName();
        String roleType=roles.getRoleType();
        String roleDescription=roles.getRoleDescription();
        Date recUpdDt = new Date();
        int roleId = roles.getRoleId();
        rolesRepo.updateRoles(roleName,roleType,roleDescription,recUpdDt,roleId);	
        return "Role Updated successfully.";
	}

}
