package com.slk.dsl.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.slk.dsl.dto.PdtLicTypePdFeaturesDTO;
import com.slk.dsl.model.ProductFeaturesEntity;
import com.slk.dsl.repository.ProductFeaturesRepo;
import com.slk.dsl.service.ProductFeaturesService;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class ProductFeatures {

	@Autowired
	private ProductFeaturesService productFeaturesService;
	
	@Autowired
	ProductFeaturesRepo productFeaturesRepo; 
	
	@PostMapping("/AddProductFeatures")
	public ProductFeaturesEntity addProductFeatures(@RequestBody ProductFeaturesEntity pdtFeatures) {
		return productFeaturesService.saveProductFeatures(pdtFeatures);
	}
	
	@GetMapping("/ProductFeatures")  
	public List<PdtLicTypePdFeaturesDTO> allProductFeatures() {  
	     return productFeaturesService.getProductFeatures();	      
	}
	
	@DeleteMapping("/DeleteProductFeatures/{id}")
	public String delete(@PathVariable int id) {
		Integer a = productFeaturesRepo.getId(id);
		try {
			if (a != null) {
				productFeaturesService.deleteProductFeatures(id);
				return "Product Features deleted successfully.";
			} else {
				return "Product Features cannot be deleted. Please enter a valid id";
			}
		} catch (Exception e) {
			if (e instanceof java.sql.SQLIntegrityConstraintViolationException) {
				return e.getMessage();
			}
			return e.getMessage();
		}
	}

	@PutMapping("/UpdateProdFeatures")
	public String update(@RequestBody ProductFeaturesEntity pdtFeatures) {
		try {
			productFeaturesService.updateProductFeatures(pdtFeatures);
			int productFeaturesId = pdtFeatures.getProductFeaturesId();
			Optional<ProductFeaturesEntity> check = productFeaturesRepo.findById(productFeaturesId);
			Boolean checkValue = check.isPresent();
			String result = "";
			if (checkValue == true) {
				result = "Product Features updated successfully.";
				return result;
			} else {
				result = "Please enter a valid Product Feature Id.";
				return result;
			}
		} catch (Exception e) {
			if (e instanceof java.sql.SQLIntegrityConstraintViolationException) {
				return e.getMessage();
			}
			return e.getMessage();
		}
	}
	
}
