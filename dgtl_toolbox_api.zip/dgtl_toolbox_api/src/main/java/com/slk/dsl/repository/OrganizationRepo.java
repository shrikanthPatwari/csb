
package com.slk.dsl.repository;

import java.util.Date;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.slk.dsl.model.OrganizationEntity;

@Repository
public interface OrganizationRepo extends JpaRepository<OrganizationEntity, Integer> {

	String deleteOrganization = "delete from tb_organization where Org_Id=:id";

	@Modifying
	@Transactional
	@Query(value = deleteOrganization, nativeQuery = true)
	public void deleteOrganization(int id);

	String getId = "Select IFNULL(Org_Id, 0) from tb_organization where Org_Id =:id";

	@Query(value = getId, nativeQuery = true)
	public Integer getId(int id);

	String updateOrganization = "update tb_organization set  Org_Name=:orgName,Org_Email_Address =:orgEmailAddress,Org_Contact_Number =:orgContactNumber, Org_Address =:orgAddress, Post_Code =:postCode, Org_Cnt_Name =:orgTypeName, Description =:description, Rec_Upd_Dt =:recUpdDt, Is_Active =:isActive  where Org_Id=:orgId";

	@Transactional
	@Modifying
	@Query(value = updateOrganization, nativeQuery = true)
	public void updateOrganization(String orgName, String orgEmailAddress, String orgContactNumber, String orgAddress,
			int postCode, String orgTypeName, String description, Date recUpdDt,Boolean isActive, int orgId);
	
	String checkOrgName = "SELECT Org_Id FROM tb_organization where Org_Name=:orgName";
	@Query(value = checkOrgName, nativeQuery = true)
	public Integer checkOrgName(String orgName);
	
	String orgName = "SELECT Org_Name FROM tb_organization where Org_Id= :orgId";
	@Query(value = orgName, nativeQuery = true)
	public String getOrgNameforUser(int orgId);

}
