package com.slk.dsl.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slk.dsl.dto.OrgUserOrgAdminDTO;
import com.slk.dsl.model.OrgAdminEntity;
import com.slk.dsl.repository.OrgAdminRepo;

@Service
public class OrgAdminService {
	
	@Autowired
	OrgAdminRepo orgAdminRepo; 
	
	public OrgAdminEntity saveOrgAdmin(OrgAdminEntity orgAd) {
		// TODO Auto-generated method stub
		OrgAdminEntity orgAdmin = new OrgAdminEntity();		
		orgAdmin.setOrgAdminId(orgAd.getOrgAdminId());
		orgAdmin.setOrgId(orgAd.getOrgId());
		orgAdmin.setUserId(orgAd.getUserId());
		orgAdmin.setRecInsDt(orgAd.getRecInsDt());
		orgAdmin.setRecUpdDt(orgAd.getRecUpdDt());
		return orgAdminRepo.save(orgAdmin);
	}
	
	public List<OrgUserOrgAdminDTO> getOrgAdmin() {  
		 List<Object[]> data= orgAdminRepo.getOrgAdmin();	
		 List<OrgUserOrgAdminDTO> result= new ArrayList<OrgUserOrgAdminDTO>();
		    data.stream().forEach(obj->{
		    	OrgUserOrgAdminDTO temp = new OrgUserOrgAdminDTO();
		        temp.setOrgAdminId((Integer)obj[0]);
		        temp.setOrgId((Integer)obj[1]);
		        temp.setOrgName(obj[2].toString());
		        temp.setUserId((Integer)obj[3]);
		        temp.setUserName(obj[4].toString());
		        temp.setRecInsDt((Date)obj[5]);
		        temp.setRecUpdDt((Date)obj[6]);
		        result.add(temp);
		    });
		    return result;
}
	
	public String deleteOrgAdmin(int id) {	
		orgAdminRepo.deleteOrgAdmin(id);
		  return "Org Admin deleted successfully.";
	}
	
	public String updateOrgAdmin(OrgAdminEntity orgAdmin) {
        int orgId=orgAdmin.getOrgId();
        int userId=orgAdmin.getUserId();
        Date recUpdDt = new Date();
        int orgAdminId = orgAdmin.getOrgAdminId();
        orgAdminRepo.updateOrgAdmin(orgId,userId,recUpdDt,orgAdminId);	
        return "Org Admin updated successfully.";
	}

}
