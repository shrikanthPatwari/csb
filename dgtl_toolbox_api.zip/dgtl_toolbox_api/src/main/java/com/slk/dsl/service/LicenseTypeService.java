package com.slk.dsl.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slk.dsl.model.LicenseTypeEntity;
import com.slk.dsl.repository.LicenseTypeRepo;

@Service
public class LicenseTypeService {

	@Autowired
	LicenseTypeRepo licenseTypeRepo;

	public List<LicenseTypeEntity> getLicenseType() {
		return licenseTypeRepo.findAll();
	}
	
	public LicenseTypeEntity saveLicenseType(LicenseTypeEntity licType) {
		// TODO Auto-generated method stub
		LicenseTypeEntity licenseType = new LicenseTypeEntity();			
		licenseType.setLicenseTypeId(licType.getLicenseTypeId());
		licenseType.setLicenseType(licType.getLicenseType());
		licenseType.setDescription(licType.getDescription());
		licenseType.setRecInsDt(licType.getRecInsDt());
		licenseType.setRecUpdDt(licType.getRecUpdDt());
		return licenseTypeRepo.save(licenseType);
	}
	
	public String deleteLicenseType(int id) {	
		licenseTypeRepo.deleteLicenseType(id);
		  return "License Type deleted successfully.";
	}
	
	public String updateLicenseType(LicenseTypeEntity licType) {
        String licenseType=licType.getLicenseType();
        String description=licType.getDescription();
        Date recUpdDt = new Date();
        int licenseTypeId = licType.getLicenseTypeId();
        licenseTypeRepo.updateLicenseType(licenseType,description,recUpdDt,licenseTypeId);	
        return "License Type Updated successfully.";
	}

}
