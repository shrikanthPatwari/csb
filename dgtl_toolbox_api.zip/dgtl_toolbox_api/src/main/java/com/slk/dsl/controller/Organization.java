package com.slk.dsl.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.slk.dsl.model.OrganizationEntity;
import com.slk.dsl.repository.OrganizationRepo;
import com.slk.dsl.service.OrganizationService;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class Organization {

	@Autowired
	private OrganizationService organizationService;

	@Autowired
	private OrganizationRepo organizationRepo;

	@PostMapping("/AddOrganization")
	public OrganizationEntity addOrganization(@RequestBody OrganizationEntity org) {
		return organizationService.saveOrganization(org);
	}

	@GetMapping("/GetOrganization")
	public List<OrganizationEntity> getOrganizations() {
		return organizationService.getOrganizations();

	}

	@DeleteMapping("/DeleteOrganization/{id}")
	public String delete(@PathVariable int id) {
		Integer a = organizationRepo.getId(id);
		try {
			if (a != null) {
				organizationService.deleteOrganization(id);
				return "Organization deleted";
			} else {
				return "Organization cannot be deleted. Please enter a valid id";
			}
		} catch (Exception e) {
			if (e instanceof java.sql.SQLIntegrityConstraintViolationException) {
				return e.getMessage();
			}
			return e.getMessage();
		}
	}

	@PutMapping("/UpdateOrganization")
	public String update(@RequestBody OrganizationEntity org) {
		organizationService.updateOrganization(org);
		int orgId = org.getOrgId();
		Optional<OrganizationEntity> check = organizationRepo.findById(orgId);
		Boolean checkValue = check.isPresent();
		String result = "";
		if (checkValue == true) {
			result = "Organization Updated successfully.";
			return result;
		} else {
			result = "Please enter a valid Organization Id.";
			return result;
		}
	}
	


}
