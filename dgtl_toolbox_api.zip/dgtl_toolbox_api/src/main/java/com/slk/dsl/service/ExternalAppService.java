package com.slk.dsl.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slk.dsl.model.ExternalAppEntity;
import com.slk.dsl.repository.ExternalAppRepo;

@Service
public class ExternalAppService {
	
	@Autowired
	ExternalAppRepo externalAppRepo;
	
	public List<ExternalAppEntity>  getExternalApps(){
		 return externalAppRepo.findAll();  
	}
	
	public ExternalAppEntity saveExternalApp(ExternalAppEntity extrnlApp) {
		// TODO Auto-generated method stub
		ExternalAppEntity externalApp = new ExternalAppEntity();			
		externalApp.setExternalAppId(extrnlApp.getExternalAppId());
		externalApp.setExternalAppName(extrnlApp.getExternalAppName());
		externalApp.setExternalAppType(extrnlApp.getExternalAppType());
		externalApp.setDescription(extrnlApp.getDescription());
		externalApp.setRecInsDt(extrnlApp.getRecInsDt());
		externalApp.setRecUpdDt(extrnlApp.getRecUpdDt());
		return externalAppRepo.save(externalApp);
	}
	
	public String deleteExternalApp(int id) {	
		externalAppRepo.deleteExternalApp(id);
		  return "External App deleted successfully.";
	}
	
	public String updateExternalApp(ExternalAppEntity extApp) {
        String externalAppName=extApp.getExternalAppName();
        String externalAppType=extApp.getExternalAppType();
        String description=extApp.getDescription();
        Date recUpdDt = new Date();
        int externalAppId = extApp.getExternalAppId();
        externalAppRepo.updateExternalApp(externalAppName,externalAppType,description,recUpdDt,externalAppId);	
        return "External App Updated successfully.";
	}

}
