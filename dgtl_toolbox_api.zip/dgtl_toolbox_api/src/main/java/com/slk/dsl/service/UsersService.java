package com.slk.dsl.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.concurrent.TimeUnit;

import org.json.JSONObject;
import org.json.XML;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.slk.dsl.dto.EmailPasswordDTO;
import com.slk.dsl.dto.OrgNameDTO;
import com.slk.dsl.dto.OrganizationUserDTO;
import com.slk.dsl.dto.UserDTO;
import com.slk.dsl.dto.UserIdPasswordDTO;
import com.slk.dsl.model.LicenseEntity;
import com.slk.dsl.model.OrganizationEntity;
import com.slk.dsl.model.UsersEntity;
import com.slk.dsl.repository.LicenseGeneratorRepo;
import com.slk.dsl.repository.OrganizationRepo;
import com.slk.dsl.repository.UsersRepo;

@Service
public class UsersService {
	
	public static final int MAX_FAILED_ATTEMPTS = 3;
    
    private static final long LOCK_TIME_DURATION = 15 * 60 * 1000; // 15 min

	@Autowired
	UsersRepo usersrepo;
	
	@Autowired
	OrganizationRepo orgRepo;
	
	@Autowired
	LicenseGeneratorRepo licenseGeneratorrepo;
	
    public void increaseFailedAttempts(UsersEntity user) {
        int newFailAttempts = user.getFailedAttempt() + 1;
        System.out.println("newFailAttempts"+newFailAttempts);
        System.out.println("user.getEmailAddress()"+user.getEmailAddress());
        usersrepo.updateFailedAttempts(newFailAttempts, user.getEmailAddress());
    }
     
    public void resetFailedAttempts(String email) {
    	usersrepo.updateFailedAttempts(0, email);
    }
     
    public void lock(UsersEntity user) {
        user.setAccountNonLocked(false);
        user.setLockTime(new Date());
         
        usersrepo.save(user);
    }
     
    public boolean unlockWhenTimeExpired(UsersEntity user) {
        long lockTimeInMillis = user.getLockTime().getTime();
        long currentTimeInMillis = System.currentTimeMillis();
         
        if (lockTimeInMillis + LOCK_TIME_DURATION < currentTimeInMillis) {
            user.setAccountNonLocked(true);
            user.setLockTime(null);
            user.setFailedAttempt(0);
             
            usersrepo.save(user);
             
            return true;
        }
         
        return false;
    }

	public UsersEntity saveUsers(UserDTO usr) {
		UsersEntity users = new UsersEntity();
		users.setUserId(usr.getUserId());
//		users.setUserName(usr.getUserName());
		users.setOrgId(usr.getOrgId());		
		users.setEmailAddress(new String(Base64.getDecoder().decode(usr.getEmailAddress())));
//		users.setPassword(Base64.getEncoder().encodeToString(usr.getPassword().getBytes()));
		users.setPassword(usr.getPassword());
		users.setRecInsDt(usr.getRecInsDt());
		users.setRecUpdDt(usr.getRecUpdDt());
		users.setFirstName(new String(Base64.getDecoder().decode(usr.getFirstName())));
		users.setLastName(new String(Base64.getDecoder().decode(usr.getLastName())));
		users.setRoleId(usr.getRoleId());
		users.setProductId(usr.getProductId());
		users.setFailedAttempt(0);
		users.setAccountNonLocked(true);
		users.setResetPasswordToken(usr.getResetPasswordToken());
		return usersrepo.save(users);
	}
	
	public UsersEntity saveNewUsers(UserDTO usr,String defaultPassword) {
		UsersEntity users = new UsersEntity();
		users.setUserId(usr.getUserId());
//		users.setUserName(usr.getUserName());
		users.setOrgId(usr.getOrgId());		
		users.setEmailAddress(new String(Base64.getDecoder().decode(usr.getEmailAddress())));
//		users.setPassword(Base64.getEncoder().encodeToString(usr.getPassword().getBytes()));
		users.setPassword(defaultPassword);
		users.setRecInsDt(usr.getRecInsDt());
		users.setRecUpdDt(usr.getRecUpdDt());
		users.setFirstName(new String(Base64.getDecoder().decode(usr.getFirstName())));
		users.setLastName(new String(Base64.getDecoder().decode(usr.getLastName())));
		users.setRoleId(usr.getRoleId());
		users.setProductId(usr.getProductId());
		users.setFailedAttempt(0);
		users.setAccountNonLocked(true);
		users.setResetPasswordToken(usr.getResetPasswordToken());
		return usersrepo.save(users);
	}
	

	public List<OrganizationUserDTO> getUsers(int orgId, int pdtId) {
		List<Object[]> data = usersrepo.getUsers(orgId,pdtId);
		List<OrganizationUserDTO> result = new ArrayList<OrganizationUserDTO>();
		data.stream().forEach(obj -> {
			OrganizationUserDTO temp = new OrganizationUserDTO();
			temp.setUserId((Integer) obj[0]);
//			temp.setUserName(obj[1].toString());
			temp.setOrgName(obj[1].toString());
			temp.setEmailAddress(obj[2].toString());
			temp.setOrgId((Integer) obj[3]);
			temp.setPassword(obj[4].toString());
			temp.setRecInsDt((Date) obj[5]);
			temp.setRecUpdDt((Date) obj[6]);
			temp.setFirstName(obj[7].toString());
			temp.setLastName(obj[8].toString());
			temp.setRoleId((Integer) obj[9]);
			temp.setRoleName(obj[10].toString());
			result.add(temp);
		});
		return result;
	}
	
	public List<OrganizationUserDTO> getAllUsers(int orgId) {
		List<Object[]> data = usersrepo.getAllUsers(orgId);
		List<OrganizationUserDTO> result = new ArrayList<OrganizationUserDTO>();
		data.stream().forEach(obj -> {
			OrganizationUserDTO temp = new OrganizationUserDTO();
			temp.setUserId((Integer) obj[0]);
			temp.setOrgName(obj[1].toString());
			temp.setEmailAddress(obj[2].toString());
			temp.setOrgId((Integer) obj[3]);
			temp.setPassword(obj[4].toString());
			temp.setRecInsDt((Date) obj[5]);
			temp.setRecUpdDt((Date) obj[6]);
			temp.setFirstName(obj[7].toString());
			temp.setLastName(obj[8].toString());
			temp.setRoleId((Integer) obj[9]);
			temp.setRoleName(obj[10].toString());
			result.add(temp);
		});
		return result;
	}

	public String deleteUser(int id) {
		usersrepo.deleteUser(id);
		return "User deleted";
	}

	public String updateUser(UserDTO user) {
		// TODO Auto-generated method stub
		int userId = user.getUserId();
//		String userName = user.getUserName();
		String emailAddress = user.getEmailAddress();
		Date recUpdDt = new Date();
		int orgId = user.getOrgId();
		String firstName = user.getFirstName();
		String lastName = user.getLastName();
		int roleId = user.getRoleId();
		usersrepo.updateUser(userId, emailAddress, recUpdDt, orgId, firstName, lastName, roleId);
		return "User updated successfully";
	}

	public ArrayList<String> getAllUsersEmail() {
		ArrayList<String> queryResult = usersrepo.getAllUsersEmail();
		return queryResult;
	}
	
	public ArrayList<String> getAllUsersEmail(int productId) {
		ArrayList<String> queryResult = usersrepo.getAllUsersEmail(productId);
		return queryResult;
	}

	public EmailPasswordDTO getEmailAndPassword(int userId) {
		List<Object[]> data = usersrepo.getEmailAndPassword(userId);
		EmailPasswordDTO temp = new EmailPasswordDTO();
		data.stream().forEach(obj -> {
			temp.setEmailid(obj[0].toString());
			temp.setPassword(obj[1].toString());
		});
		return temp;
	}

	public ArrayList<String> getConsumerUsersEmail() {
		ArrayList<String> queryResult = usersrepo.getConsumerUsersEmail();
		return queryResult;
	}
	
	public ArrayList<String> getConsumerUsersEmail(int productId) {
		ArrayList<String> queryResult = usersrepo.getConsumerUsersEmail(productId);
		return queryResult;
	}

	public List<OrgNameDTO> getorgname(String emailId) {
		List<Object[]> queryResult = usersrepo.getorgname(emailId);

		List<OrgNameDTO> temp = new ArrayList<OrgNameDTO>();
		queryResult.stream().forEach(object -> {
			OrgNameDTO obj = new OrgNameDTO();
			obj.setOrg_name(object[0].toString());
			obj.setOrg_Id((Integer) object[1]);
			obj.setUser_role_id((Integer) object[2]);
			obj.setFirst_Name(object[3].toString());
			obj.setLast_Name(object[4].toString());
			obj.setUser_id((Integer) object[5]);
			temp.add(obj);
		});
		return temp;
	}

	public void updateResetPasswordToken(String token, String emailAddress) throws UsernameNotFoundException {
//        Customer customer = customerRepo.findByEmail(email);
		UsersEntity users = usersrepo.findByEmailAddress(emailAddress);
		System.out.println("users: " + users);
		if (users != null) {
			users.setResetPasswordToken(token);
			usersrepo.save(users);
		} else {
			throw new UsernameNotFoundException("Could not find any user with the email " + emailAddress);
		}
	}

	public UsersEntity getByResetPasswordToken(String token) {
		System.out.println("yyyyyyy:" + usersrepo.findByResetPasswordToken(token));
		return usersrepo.findByResetPasswordToken(token);
	}

	public void updatePassword(UsersEntity user, String newPassword) {
//        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
//        String encodedPassword = passwordEncoder.encode(newPassword);       
		String encodedPassword = Base64.getEncoder().encodeToString(newPassword.getBytes());
		user.setPassword(encodedPassword);
		user.setResetPasswordToken(null);
		usersrepo.save(user);
	}

	public Object getEmailAndPasswordJwt(String email) {
		List<Object[]> data = usersrepo.getEmailAndPasswordJwt(email);
		Map<String, Object> model = new HashMap<>();
		data.stream().forEach(obj -> {
			model.put("email", obj[0].toString());
			model.put("password", obj[1].toString());
		});
		return model;
	}
	
	public UsersEntity getByEmail(String email) {
		UsersEntity queryResult = usersrepo.getByEmail( email);
		return queryResult;
	}

	public UsersEntity saveRegisteredUsers(UserDTO usr) {
		String userOrgName = usr.getOrganization();
		Integer orgIdfromDb = orgRepo.checkOrgName(userOrgName);
		if (orgIdfromDb == null) {
			OrganizationEntity org = new OrganizationEntity();
			org.setOrgName(userOrgName);
			org.setOrgAdd(" ");
			org.setOrgPostCd(0);
			org.setOrgCntName(" ");
			org.setOrgCntNum(" ");
			org.setOrgCntMail(" ");
			org.setDescription(" ");
			org.setRecInsDt(Calendar.getInstance().getTime());
			org.setRecUpdDt(Calendar.getInstance().getTime());
			org.setIsActive(true);
			orgRepo.save(org);
			orgIdfromDb = org.getOrgId();
		}
		UsersEntity users = new UsersEntity();
		users.setUserId(usr.getUserId());	
		users.setOrgId(orgIdfromDb);	
		users.setEmailAddress(new String(Base64.getDecoder().decode(usr.getEmailAddress())));
		users.setPassword(usr.getPassword());
		users.setRecInsDt(usr.getRecInsDt());
		users.setRecUpdDt(usr.getRecUpdDt());
		users.setFirstName(new String(Base64.getDecoder().decode(usr.getFirstName())));
		users.setLastName(new String(Base64.getDecoder().decode(usr.getLastName())));
		users.setRoleId(usr.getRoleId());
		users.setProductId(usr.getProductId());
		users.setFailedAttempt(0);
		users.setAccountNonLocked(true);
		users.setResetPasswordToken(usr.getResetPasswordToken());
		return usersrepo.save(users);
	}
	
	public UsersEntity saveRegisteredFastAPIUsers(UserDTO usr, Integer orgIdfromDb) throws ParseException {
		UsersEntity users = new UsersEntity();
		users.setUserId(usr.getUserId());
		users.setOrgId(orgIdfromDb);
		users.setEmailAddress(new String(Base64.getDecoder().decode(usr.getEmailAddress())));
		users.setPassword(usr.getPassword());
		users.setRecInsDt(usr.getRecInsDt());
		users.setRecUpdDt(usr.getRecUpdDt());
		users.setFirstName(new String(Base64.getDecoder().decode(usr.getFirstName())));
		users.setLastName(new String(Base64.getDecoder().decode(usr.getLastName())));
		users.setRoleId(usr.getRoleId());
		users.setProductId(usr.getProductId());
		users.setFailedAttempt(0);
		users.setAccountNonLocked(true);
		users.setResetPasswordToken(usr.getResetPasswordToken());
		int key = licenseGeneratorrepo.checkLicenseKeyforProdOrg(usr.getProductId(), orgIdfromDb);
		if (key == 0) {
		// TODO Auto-generated method stub
		LicenseEntity license = new LicenseEntity();
		int userscount = licenseGeneratorrepo.getLicenseUsersCount(orgIdfromDb, usr.getProductId());
		String orgName = licenseGeneratorrepo.getOrgName(orgIdfromDb);
		int product = usr.getProductId();
		int lastLicenseId = licenseGeneratorrepo.getLastLicenseId();

		String[] productFeature = null;
		String arr = Arrays.toString(productFeature).replace("[", "").replace("]", "");
		String[] array1 = arr.split(", ");
		int n = array1.length;
		Date today = new Date();
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MONTH, 1);
		java.util.Date dt = cal.getTime();

		Date endDate = dt;
		int LType = 1;
		int extAppId = 0;
		String partners = null;
		String partnerType = null;

		int[] connectorId = licenseGeneratorrepo.getConnectorId();
		String arr7 = Arrays.toString(connectorId).replace("[", "").replace("]", "");
		String[] array7 = arr7.split(", ");
		String[] connectorName = licenseGeneratorrepo.getConnectorName();
		String arr5 = Arrays.toString(connectorName).replace("[", "").replace("]", "");
		String[] array5 = arr5.split(", ");
		int n5 = array5.length;
		String[] connectorType = licenseGeneratorrepo.getConnectorType();
		String arr6 = Arrays.toString(connectorType).replace("[", "").replace("]", "");
		String[] array6 = arr6.split(", ");

		String[] roleName = licenseGeneratorrepo.getRoleName(usr.getRoleId());
		String arr1 = Arrays.toString(roleName).replace("[", "").replace("]", "");
		String[] array2 = arr1.split(", ");
		int n1 = array2.length;

		String encryptedString = "";

		try {
			String uniqueID = UUID.randomUUID().toString();

			// Content of the license file
			StringBuilder xmlBuilder = new StringBuilder("");
			xmlBuilder.append("<License>");
			xmlBuilder.append("\n  <Id>" + uniqueID + "</Id>");
			xmlBuilder.append("\n  <Type>" + LType + "</Type>");
			xmlBuilder.append("\n  <Organization>" + orgName + "</Organization>");
			xmlBuilder.append("\n  <Expiration>" + endDate + "</Expiration>");
			xmlBuilder.append("\n  <Products>");
			xmlBuilder.append("\n    <Product>" + product);
			xmlBuilder.append("\n      <ProductFeatures>");
			String k = null;
			for (int i = 0; i < n; i++) {
				k = array1[i];
				xmlBuilder.append("\n        <Feature>" + k + "</Feature>");
			}
			xmlBuilder.append("\n      </ProductFeatures>");
			xmlBuilder.append("\n      <ProductRoles>");
			String k1 = null;
			for (int i = 0; i < n1; i++) {
				k1 = array2[i];
				xmlBuilder.append("\n        <Role>" + k1 + "</Role>");
			}
			xmlBuilder.append("\n      </ProductRoles>");
			xmlBuilder.append("\n    </Product>");
			xmlBuilder.append("\n  </Products>");
			xmlBuilder.append("\n  <ExternalApp name ='" + partners + "' type = '" + partnerType + "'>" + extAppId
					+ "</ExternalApp>");
			xmlBuilder.append("\n  <Connectors>");
			String k3;
			String k4 = null;
			String k5 = null;
			for (int i = 0; i < n5; i++) {
				k3 = array7[i];
				k4 = array6[i];
				k5 = array5[i];
				xmlBuilder.append("\n    <Connector name = '" + k5 + "' type = '" + k4 + "'>" + k3 + "</Connector>");
			}
			xmlBuilder.append("\n  </Connectors>");
			xmlBuilder.append("\n  <Users>");
			xmlBuilder.append("\n    <NumberOfLicense>" + userscount + "</NumberOfLicense>");
			xmlBuilder.append("\n  </Users>");
			xmlBuilder.append("\n  <Customer>");
			xmlBuilder.append("\n    <Name>" + new String(Base64.getDecoder().decode(usr.getFirstName())) + "</Name>");
			xmlBuilder.append(
					"\n    <Email>" + new String(Base64.getDecoder().decode(usr.getEmailAddress())) + "</Email>");
			xmlBuilder.append("\n  </Customer>");
			xmlBuilder.append(
					"\n  <Signature>" + KeypairManager.getSignature(uniqueID, orgName, product) + "</Signature>");
			xmlBuilder.append("\n</License>");
			String xml = xmlBuilder.toString();
			System.out.println("XML:" + xml);
			// Encrypting the license file content
			final String secretKey = "iamhidden$secret";
			encryptedString = LicenseCryptography.encryptLicense(xml, secretKey);
			System.out.println("encryptedString:" + encryptedString);

		} catch (Exception e1) {
			e1.printStackTrace();
		}
		if (encryptedString != null) {
			license.setLicenseId(lastLicenseId);
			license.setLicenseKey(encryptedString);
			license.setLicenseTypeId(1);
			license.setProductId(usr.getProductId());
			license.setOrgId(orgIdfromDb);
			license.setActivationDate(today);
			license.setExpirationDate(dt);
			license.setMaxDeployments(10);
			license.setRecInsDt(today);
			license.setRecUpdDt(today);
			licenseGeneratorrepo.save(license);
		} else {
			return null;
		}
		}
		Date expDate = usersrepo.getExpirationDate(orgIdfromDb, usr.getProductId());
		long balanceDays = 0;
		Date cDate = new Date();
		DateFormat simpleDateFormat=new SimpleDateFormat("yyyy-MM-dd");
		Date fDate = (Date) simpleDateFormat.parse(expDate.toString());
		long diffMill = Math.abs(cDate.getTime() -  fDate.getTime());
		balanceDays = TimeUnit.DAYS.convert(diffMill, TimeUnit.MILLISECONDS);
		users.setDaysLeft(balanceDays);
		return usersrepo.save(users);
	}
	
	public String changeUserPassword(UserIdPasswordDTO user) {
		// TODO Auto-generated method stub
		int userId = user.getUserId();
//		String userName = user.getUserName();
		String password = user.getPassword();
		Date recUpdDt = new Date();
		usersrepo.changeUserPassword(userId, password, recUpdDt);
		return "Password changed successfully.";
	}
	
	public int getUserId(String emailId,int orgId) {
		int queryResult = usersrepo.getUserId(emailId,orgId);
		return queryResult;
	}
}
