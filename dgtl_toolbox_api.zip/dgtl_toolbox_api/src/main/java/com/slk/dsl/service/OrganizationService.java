package com.slk.dsl.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slk.dsl.model.OrganizationEntity;
import com.slk.dsl.repository.OrganizationRepo;

@Service
public class OrganizationService {
	@Autowired
	OrganizationRepo organizationRepo; 
	
	public OrganizationEntity saveOrganization(OrganizationEntity org) {
		// TODO Auto-generated method stub
		OrganizationEntity organization = new OrganizationEntity();	
		
		organization.setOrgId(org.getOrgId());
		organization.setOrgName(org.getOrgName());
		organization.setOrgCntMail(org.getOrgCntMail());
		organization.setOrgCntName(org.getOrgCntName());
		organization.setOrgAdd(org.getOrgAdd());
		organization.setOrgCntNum(org.getOrgCntNum());
		organization.setOrgPostCd(org.getOrgPostCd());
		organization.setDescription(org.getDescription());
		organization.setRecInsDt(org.getRecInsDt());
		organization.setRecUpdDt(org.getRecUpdDt());
		organization.setIsActive(org.getIsActive());
		return organizationRepo.save(organization);
	}
	
	public List<OrganizationEntity> getOrganizations() {  
	    return organizationRepo.findAll();     
	    
	   }
	
	public String deleteOrganization(int id) {	
		organizationRepo.deleteOrganization(id);
		  return "Organization deleted";
	}
	
	public String updateOrganization(OrganizationEntity org) {
        String orgName=org.getOrgName();
        String orgEmailAddress=org.getOrgCntMail();
        String orgContactNumber=org.getOrgCntNum();
        String orgAddress=org.getOrgAdd();
        int postCode=org.getOrgPostCd();
        String orgTypeName=org.getOrgCntName();
        String description=org.getDescription();
        Date recUpdDt = new Date();
        Boolean isActive = org.getIsActive();
        int orgId = org.getOrgId();
        organizationRepo.updateOrganization(orgName,orgEmailAddress,orgContactNumber,orgAddress,postCode,orgTypeName,description,recUpdDt,isActive,orgId);	
        return "Organization Updated successfully.";
	}
}
