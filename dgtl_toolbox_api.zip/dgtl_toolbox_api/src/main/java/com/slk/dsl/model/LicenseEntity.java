package com.slk.dsl.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="tb_license")
public class LicenseEntity{
	
	@Id @GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="License_Id")
	private int licenseId;
	
	@Column(name="License_Key")
   private String licenseKey;
	
	@Transient
	@Column(name="User_Name")
	private String userName;
	
	@Transient
	@Column(name="Email")
	private String email;
	
	@Column(name="License_Type_Id")
	private int licenseTypeId;
	
	@Column(name="Product_Id")
	private int productId;
	
	@Column(name="Org_Id")
	private int orgId;
	
	@Column(name="Max_Deployments")
	private int maxDeployments;
	
	@Transient
	private String organization;
	
	@Transient
	private String[] productFeature;
	

	@Transient
	private int[] connectorId;
	
	@Transient
	private String[] connectorName;
	
	@Transient
	private String[] connectorType;
	
	@Transient
	private int externalAppId;
	
	@Transient
	private String partners;
	
	@Transient
	private String partnerType;
	
	@Transient
	private String[] roleName;
	
	@Column(name="Activation_Date")
	private Date activationDate;
	
	
	@Column(name="Expiration_Date")
	private Date expirationDate;
	
	@Column(name = "Rec_Ins_Dt")
	private Date recInsDt;

	@Column(name = "Rec_Upd_Dt")
	private Date recUpdDt;
	
	
	public int getMaxDeployments() {
		return maxDeployments;
	}

	public void setMaxDeployments(int maxDeployments) {
		this.maxDeployments = maxDeployments;
	}

	public String getOrganization() {
		return organization;
	}
	
	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public int getOrgId() {
		return orgId;
	}

	public void setOrgId(int orgId) {
		this.orgId = orgId;
	}

	public int getLicenseId() {
		return licenseId;
	}

	public void setLicenseId(int licenseId) {
		this.licenseId = licenseId;
	}

	public String getLicenseKey() {
		return licenseKey;
	}

	public void setLicenseKey(String licenseKey) {
		this.licenseKey = licenseKey;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getLicenseTypeId() {
		return licenseTypeId;
	}

	public void setLicenseTypeId(int licenseTypeId) {
		this.licenseTypeId = licenseTypeId;
	}

	public Date getActivationDate() {
		return activationDate;
	}

	public void setActivationDate(Date activationDate) {
		this.activationDate = activationDate;
	}

	public Date getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}

	public Date getRecInsDt() {
		return recInsDt;
	}

	public void setRecInsDt(Date recInsDt) {
		this.recInsDt = recInsDt;
	}

	public Date getRecUpdDt() {
		return recUpdDt;
	}

	public void setRecUpdDt(Date recUpdDt) {
		this.recUpdDt = recUpdDt;
	}



	public String[] getProductFeature() {
		return productFeature;
	}


	public int[] getConnectorId() {
		return connectorId;
	}


	public String[] getConnectorName() {
		return connectorName;
	}


	public String[] getConnectorType() {
		return connectorType;
	}


	public int getExternalAppId() {
		return externalAppId;
	}



	public String getPartners() {
		return partners;
	}



	public String getPartnerType() {
		return partnerType;
	}


	public String[] getRoleName() {
		return roleName;
	}


	@PrePersist
	private void onCreate() {
		this.recInsDt = new Date();
	}

	@PreUpdate
	protected void onUpdate() {
		this.recUpdDt = new Date();
	}

}
