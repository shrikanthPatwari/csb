package com.slk.dsl.repository;

import java.util.Date;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.slk.dsl.model.ProductsEntity;

@Repository
public interface ProductsRepo extends JpaRepository<ProductsEntity, Integer>{
	
	String getId = "Select IFNULL(Product_Id, 0) from tb_products where Product_Id =:id";

	@Query(value = getId, nativeQuery = true)
	public Integer getId(int id);

	String deleteProducts = "delete from tb_products where Product_Id=:id";

	@Modifying
	@Transactional
	@Query(value = deleteProducts, nativeQuery = true)
	public void deleteProducts(int id);
	
	String updateProducts = "update tb_products set  Product_Name=:pdtName,Product_Description =:pdtDesc,Product_Code =:pdtCode, Product_Version =:pdtVersion, Rec_Upd_Dt =:recUpdDt where Product_Id=:productId";
	@Transactional
	@Modifying
	@Query(value = updateProducts, nativeQuery = true)
	public void updateProducts(String pdtName,String pdtDesc,String pdtCode,String pdtVersion,Date recUpdDt,int productId);

}
