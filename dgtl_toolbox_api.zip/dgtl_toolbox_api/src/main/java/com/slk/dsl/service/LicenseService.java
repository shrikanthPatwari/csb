package com.slk.dsl.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slk.dsl.dto.LicTypePdtLicenseDTO;
import com.slk.dsl.dto.LicenseKeyDTO;
import com.slk.dsl.dto.PdtLicTypePdFeaturesDTO;
import com.slk.dsl.dto.UserDTO;
import com.slk.dsl.model.LicenseEntity;
import com.slk.dsl.model.OrganizationEntity;
import com.slk.dsl.repository.LicenseGeneratorRepo;
import com.slk.dsl.repository.OrganizationRepo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.stream.IntStream;

import org.json.JSONObject;
import org.json.XML;

@Service
public class LicenseService {

	@Autowired
	LicenseGeneratorRepo licenseGeneratorrepo;
	
	@Autowired
	OrganizationRepo orgRepo;
	
	public List<LicTypePdtLicenseDTO> getLicense() {  
		 List<Object[]> data= licenseGeneratorrepo.getLicense();	
		 List<LicTypePdtLicenseDTO> result= new ArrayList<LicTypePdtLicenseDTO>();
		    data.stream().forEach(obj->{
		    	LicTypePdtLicenseDTO temp = new LicTypePdtLicenseDTO();
		        temp.setLicenseId((Integer)obj[0]);
		        temp.setUserName(obj[1].toString());
		        temp.setEmail(obj[2].toString());
		        temp.setLicenseTypeId((Integer)obj[3]);
		        temp.setLicenseType(obj[4].toString());
		        temp.setActivationDate((Date)obj[5]);
		        temp.setExpirationDate((Date)obj[6]);
		        temp.setRecInsDt((Date)obj[7]);
		        temp.setRecUpdDt((Date)obj[8]);
		        temp.setOrgName(obj[9].toString());
		        temp.setProductName(obj[10].toString());
		        result.add(temp);
		    });
		    return result;    
	    
	   }
	
	public LicenseEntity generateLicense(LicenseEntity lic) {
		String userOrgName = lic.getOrganization();
		Integer orgIdfromDb = orgRepo.checkOrgName(userOrgName);
		if (orgIdfromDb == null) {
			OrganizationEntity org = new OrganizationEntity();
			org.setOrgName(userOrgName);
			org.setOrgAdd(" ");
			org.setOrgPostCd(0);
			org.setOrgCntName(" ");
			org.setOrgCntNum(" ");
			org.setOrgCntMail(" ");
			org.setDescription(" ");
			org.setRecInsDt(Calendar.getInstance().getTime());
			org.setRecUpdDt(Calendar.getInstance().getTime());
			org.setIsActive(true);
			orgRepo.save(org);
			orgIdfromDb = org.getOrgId();
		}
		// TODO Auto-generated method stub
		LicenseEntity license = new LicenseEntity();
//		int userscount = licenseGeneratorrepo.getLicenseUsersCount();
		int userscount = licenseGeneratorrepo.getLicenseUsersCount(lic.getOrgId(), lic.getProductId());
//		String username = lic.getUserName();
//		String email = lic.getEmail();
		String orgName = licenseGeneratorrepo.getOrgName(orgIdfromDb);
		int product = lic.getProductId();

		String[] productFeature = lic.getProductFeature();
		String arr = Arrays.toString(productFeature).replace("[", "").replace("]", "");
		String[] array1 = arr.split(", ");
		int n = array1.length;

		Date endDate = lic.getExpirationDate();
		int LType = lic.getLicenseTypeId();
		int extAppId = lic.getExternalAppId();
		String partners = lic.getPartners();
		String partnerType = lic.getPartnerType();

		int[] connectorId = lic.getConnectorId();
		String arr7 = Arrays.toString(connectorId).replace("[", "").replace("]", "");
		String[] array7 = arr7.split(", ");
		String[] connectorName = lic.getConnectorName();
		String arr5 = Arrays.toString(connectorName).replace("[", "").replace("]", "");
		String[] array5 = arr5.split(", ");
		int n5 = array5.length;
		String[] connectorType = lic.getConnectorType();
		String arr6 = Arrays.toString(connectorType).replace("[", "").replace("]", "");
		String[] array6 = arr6.split(", ");

		String[] roleName = lic.getRoleName();
		String arr1 = Arrays.toString(roleName).replace("[", "").replace("]", "");
		String[] array2 = arr1.split(", ");
		int n1 = array2.length;

		String encryptedString = "";

		try {
			String uniqueID = UUID.randomUUID().toString();

			// Content of the license file
			StringBuilder xmlBuilder = new StringBuilder("");
			xmlBuilder.append("<License>");
			xmlBuilder.append("\n  <Id>" + uniqueID + "</Id>");
			xmlBuilder.append("\n  <Type>" + LType + "</Type>");
			xmlBuilder.append("\n  <Organization>" + orgName + "</Organization>");
			xmlBuilder.append("\n  <Expiration>" + endDate + "</Expiration>");
			xmlBuilder.append("\n  <Products>");
			xmlBuilder.append("\n    <Product>" + product);
			xmlBuilder.append("\n      <ProductFeatures>");
			String k = null;
			for (int i = 0; i < n; i++) {
				k = array1[i];
				xmlBuilder.append("\n        <Feature>" + k + "</Feature>");
			}
			xmlBuilder.append("\n      </ProductFeatures>");
			xmlBuilder.append("\n      <ProductRoles>");
			String k1 = null;
			for (int i = 0; i < n1; i++) {
				k1 = array2[i];
				xmlBuilder.append("\n        <Role>" + k1 + "</Role>");
			}
			xmlBuilder.append("\n      </ProductRoles>");
			xmlBuilder.append("\n    </Product>");
			xmlBuilder.append("\n  </Products>");
			xmlBuilder.append("\n  <ExternalApp name ='" + partners + "' type = '" + partnerType + "'>" + extAppId
					+ "</ExternalApp>");
			xmlBuilder.append("\n  <Connectors>");
			String k3;
			String k4 = null;
			String k5 = null;
			for (int i = 0; i < n5; i++) {
				k3 = array7[i];
				k4 = array6[i];
				k5 = array5[i];
				xmlBuilder.append("\n    <Connector name = '" + k5 + "' type = '" + k4 + "'>" + k3 + "</Connector>");
			}
			xmlBuilder.append("\n  </Connectors>");
			xmlBuilder.append("\n  <Users>");
			xmlBuilder.append("\n    <NumberOfLicense>" + userscount + "</NumberOfLicense>");
			xmlBuilder.append("\n  </Users>");
//			xmlBuilder.append("\n  <Customer>");
//			xmlBuilder.append("\n    <Name>" + username + "</Name>");
//			xmlBuilder.append("\n    <Email>" + email + "</Email>");
//			xmlBuilder.append("\n  </Customer>");
			xmlBuilder.append(
					"\n  <Signature>" + KeypairManager.getSignature(uniqueID, orgName, product) + "</Signature>");
			xmlBuilder.append("\n</License>");
			String xml = xmlBuilder.toString();
			System.out.println("xmlBuilder:" + xml);

			JSONObject json = XML.toJSONObject(xml);
			String jsonString = json.toString(4);
			System.out.println("jsonString:" + jsonString);

			// Encrypting the license file content
			final String secretKey = "iamhidden$secret";
			encryptedString = LicenseCryptography.encryptLicense(xml, secretKey);
			System.out.println("encryptedString:" + encryptedString);

		} catch (Exception e1) {
			e1.printStackTrace();
		}
if(encryptedString!=null) {
		license.setLicenseId(lic.getLicenseId());
		license.setLicenseKey(encryptedString);
		license.setUserName(lic.getUserName());
		license.setEmail(lic.getEmail());
		license.setLicenseTypeId(lic.getLicenseTypeId());
		license.setProductId(lic.getProductId());
		license.setOrgId(orgIdfromDb);
		license.setActivationDate(lic.getActivationDate());
		license.setExpirationDate(lic.getExpirationDate());
		license.setMaxDeployments(lic.getMaxDeployments());
		license.setRecInsDt(lic.getRecInsDt());
		license.setRecUpdDt(lic.getRecUpdDt());
		return licenseGeneratorrepo.save(license);
}
else {
	return null;
}

	}
	
	public String updateLicense(LicenseKeyDTO lic) {
		// TODO Auto-generated method stub
		int licenseId = lic.getLicenseId();
		LicenseEntity license = licenseGeneratorrepo.getByLicenseId(licenseId);
		String licenseKey= updateNewLicense(license,lic);
		System.out.println("licenseKey:"+licenseKey);
//		Object licenseKey = lic.getLicenseKey();
//		System.out.println("licenseKey:"+licenseKey);
//		JSONObject json = new JSONObject(licenseKey);
//		String xml = XML.toString(json);
//		System.out.println("xml:"+xml);
//		final String secretKey = "iamhidden$secret";
//		String encryptedString = LicenseCryptography.encryptLicense(xml, secretKey);
//		System.out.println("encryptedString:" + encryptedString);
		Date recUpdDt = new Date();
		int productId = lic.getProductId();
		licenseGeneratorrepo.updateLicense(licenseId, licenseKey, recUpdDt, productId);
		return "License updated successfully";
	}
	
	public String updateNewLicense(LicenseEntity license, LicenseKeyDTO lic) {
		int userscount = licenseGeneratorrepo.getLicenseUsersCount(license.getOrgId(), license.getProductId());
		String orgName = licenseGeneratorrepo.getOrgName(license.getOrgId());
		int product = lic.getProductId();
		int lastLicenseId = licenseGeneratorrepo.getLastLicenseId();

		String[] productFeature = null;
		String arr = Arrays.toString(productFeature).replace("[", "").replace("]", "");
		String[] array1 = arr.split(", ");
		int n = array1.length;

		Date endDate = license.getExpirationDate();
		int LType = license.getLicenseTypeId();
		int extAppId = 0;
		String partners = null;
		String partnerType = null;

		int[] connectorId = null;
		String arr7 = Arrays.toString(connectorId).replace("[", "").replace("]", "");
		String[] array7 = arr7.split(", ");
		String[] connectorName = null;
		String arr5 = Arrays.toString(connectorName).replace("[", "").replace("]", "");
		String[] array5 = arr5.split(", ");
		int n5 = array5.length;
		String[] connectorType = null;
		String arr6 = Arrays.toString(connectorType).replace("[", "").replace("]", "");
		String[] array6 = arr6.split(", ");

		String[] roleName = null;
		String arr1 = Arrays.toString(roleName).replace("[", "").replace("]", "");
		String[] array2 = arr1.split(", ");
		int n1 = array2.length;

		String encryptedString = "";

		try {
			String uniqueID = UUID.randomUUID().toString();

			// Content of the license file
			StringBuilder xmlBuilder = new StringBuilder("");
			xmlBuilder.append("<License>");
			xmlBuilder.append("\n  <Id>" + uniqueID + "</Id>");
			xmlBuilder.append("\n  <Type>" + LType + "</Type>");
			xmlBuilder.append("\n  <Organization>" + orgName + "</Organization>");
			xmlBuilder.append("\n  <Expiration>" + endDate + "</Expiration>");
			xmlBuilder.append("\n  <Products>");
			xmlBuilder.append("\n    <Product>" + product);
			xmlBuilder.append("\n      <ProductFeatures>");
			String k = null;
			for (int i = 0; i < n; i++) {
				k = array1[i];
				xmlBuilder.append("\n        <Feature>" + k + "</Feature>");
			}
			xmlBuilder.append("\n      </ProductFeatures>");
			xmlBuilder.append("\n      <ProductRoles>");
			String k1 = null;
			for (int i = 0; i < n1; i++) {
				k1 = array2[i];
				xmlBuilder.append("\n        <Role>" + k1 + "</Role>");
			}
			xmlBuilder.append("\n      </ProductRoles>");
			xmlBuilder.append("\n    </Product>");
			xmlBuilder.append("\n  </Products>");
			xmlBuilder.append("\n  <ExternalApp name ='" + partners + "' type = '" + partnerType + "'>" + extAppId
					+ "</ExternalApp>");
			xmlBuilder.append("\n  <Connectors>");
			String k3;
			String k4 = null;
			String k5 = null;
			for (int i = 0; i < n5; i++) {
				k3 = array7[i];
				k4 = array6[i];
				k5 = array5[i];
				xmlBuilder.append("\n    <Connector name = '" + k5 + "' type = '" + k4 + "'>" + k3 + "</Connector>");
			}
			xmlBuilder.append("\n  </Connectors>");
			xmlBuilder.append("\n  <Users>");
			xmlBuilder.append("\n    <NumberOfLicense>" + userscount + "</NumberOfLicense>");
			xmlBuilder.append("\n  </Users>");
//			xmlBuilder.append("\n  <Customer>");
//			xmlBuilder.append("\n    <Name>" + new String(Base64.getDecoder().decode(usr.getFirstName())) + "</Name>");
//			xmlBuilder.append(
//					"\n    <Email>" + new String(Base64.getDecoder().decode(usr.getEmailAddress())) + "</Email>");
//			xmlBuilder.append("\n  </Customer>");
			xmlBuilder.append(
					"\n  <Signature>" + KeypairManager.getSignature(uniqueID, orgName, product) + "</Signature>");
			xmlBuilder.append("\n</License>");
			String xml = xmlBuilder.toString();
			System.out.println("XML:" + xml);
			// Encrypting the license file content
			final String secretKey = "iamhidden$secret";
			encryptedString = LicenseCryptography.encryptLicense(xml, secretKey);
			System.out.println("encryptedString:" + encryptedString);

		} catch (Exception e1) {
			e1.printStackTrace();
		}
		if (encryptedString != null) {
			 licenseGeneratorrepo.updateNewLicense(lic.getLicenseId(), lic.getProductId(), encryptedString);
			 String licenseKey = licenseGeneratorrepo.getKeyByLicenseId(lic.getLicenseId());
			 System.out.println("licenses:"+licenseKey);
			 return licenseKey;
		} else {
			return null;
		}
	}
}
