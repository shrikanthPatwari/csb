package com.slk.dsl.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slk.dsl.dto.PdtLicTypePdFeaturesDTO;
import com.slk.dsl.model.ProductFeaturesEntity;
import com.slk.dsl.repository.ProductFeaturesRepo;

@Service
public class ProductFeaturesService {
	
	@Autowired
	ProductFeaturesRepo productFeaturesRepo; 
	
	public ProductFeaturesEntity saveProductFeatures(ProductFeaturesEntity pdtFeatures) {
		// TODO Auto-generated method stub
		ProductFeaturesEntity productFeatures = new ProductFeaturesEntity();		
		productFeatures.setProductFeaturesId(pdtFeatures.getProductFeaturesId());
		productFeatures.setProductId(pdtFeatures.getProductId());
		productFeatures.setPdtLicenseTypeId(pdtFeatures.getPdtLicenseTypeId());
		productFeatures.setFeatures(pdtFeatures.getFeatures());
		productFeatures.setRecInsDt(pdtFeatures.getRecInsDt());
		productFeatures.setRecUpdDt(pdtFeatures.getRecUpdDt());
		return productFeaturesRepo.save(productFeatures);
	}
	
	public List<PdtLicTypePdFeaturesDTO> getProductFeatures() {  
		 List<Object[]> data= productFeaturesRepo.getProductFeatures();	
		 List<PdtLicTypePdFeaturesDTO> result= new ArrayList<PdtLicTypePdFeaturesDTO>();
		    data.stream().forEach(obj->{
		    	PdtLicTypePdFeaturesDTO temp = new PdtLicTypePdFeaturesDTO();
		        temp.setProductFeaturesId((Integer)obj[0]);
		        temp.setProductId((Integer)obj[1]);
		        temp.setPrdName(obj[2].toString());
		        temp.setPdtLicenseTypeId((Integer)obj[3]);
		        temp.setLicenseTypeName(obj[4].toString());
		        temp.setFeatures(obj[5].toString());
		        temp.setRecInsDt((Date)obj[6]);
		        temp.setRecUpdDt((Date)obj[7]);
		        result.add(temp);
		    });
		    return result;
}
	
	public String deleteProductFeatures(int id) {	
		productFeaturesRepo.deleteProductFeatures(id);
		  return "Product Features deleted successfully.";
	}
	
	public String updateProductFeatures(ProductFeaturesEntity pdtFeatures) {
		int productId = pdtFeatures.getProductId();
		int pdtLicenseTypeId = pdtFeatures.getPdtLicenseTypeId();
		String features = pdtFeatures.getFeatures();
		Date recUpdDt = new Date();
		int productFeaturesId = pdtFeatures.getProductFeaturesId();
		productFeaturesRepo.updateProductFeatures(productId, pdtLicenseTypeId, features, recUpdDt, productFeaturesId);
		  return "Product Features Updated successfully.";
	}

}
