package com.slk.dsl.dto;

import java.util.Date;

import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

public class PdtLicTypePdFeaturesDTO {
	private int productFeaturesId;
	private int productId;
	private String prdName;
	private int pdtLicenseTypeId;
	private String LicenseTypeName;
	private String features;
	private Date recInsDt;
	private Date recUpdDt;

	public Date getRecInsDt() {
		return recInsDt;
	}

	public void setRecInsDt(Date recInsDt) {
		this.recInsDt = recInsDt;
	}

	public Date getRecUpdDt() {
		return recUpdDt;
	}

	public void setRecUpdDt(Date recUpdDt) {
		this.recUpdDt = recUpdDt;
	}

	public int getProductFeaturesId() {
		return productFeaturesId;
	}

	public void setProductFeaturesId(int productFeaturesId) {
		this.productFeaturesId = productFeaturesId;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getPrdName() {
		return prdName;
	}

	public void setPrdName(String prdName) {
		this.prdName = prdName;
	}

	public int getPdtLicenseTypeId() {
		return pdtLicenseTypeId;
	}

	public void setPdtLicenseTypeId(int pdtLicenseTypeId) {
		this.pdtLicenseTypeId = pdtLicenseTypeId;
	}

	public String getLicenseTypeName() {
		return LicenseTypeName;
	}

	public void setLicenseTypeName(String licenseTypeName) {
		LicenseTypeName = licenseTypeName;
	}

	public String getFeatures() {
		return features;
	}

	public void setFeatures(String features) {
		this.features = features;
	}

	@PrePersist
	private void onCreate() {
		this.recInsDt = new Date();
	}

	@PreUpdate
	protected void onUpdate() {
		this.recUpdDt = new Date();
	}
}
