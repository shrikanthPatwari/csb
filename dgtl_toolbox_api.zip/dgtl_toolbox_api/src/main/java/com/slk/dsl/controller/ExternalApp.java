package com.slk.dsl.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.slk.dsl.model.ExternalAppEntity;
import com.slk.dsl.repository.ExternalAppRepo;
import com.slk.dsl.service.ExternalAppService;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class ExternalApp {
	
	@Autowired
	ExternalAppService externalAppService;
	
	@Autowired
	ExternalAppRepo externalAppRepo;
	
	@GetMapping("/ExternalApp")  
	public List<ExternalAppEntity> getExternalApps() {  
	     return externalAppService.getExternalApps();	      
	}
	
	@PostMapping("/AddExternalApp")
	public ExternalAppEntity addExternalApp(@RequestBody ExternalAppEntity externalApp) {
		return externalAppService.saveExternalApp(externalApp);
	}
	
	@DeleteMapping("/DeleteExternalApp/{id}")
	public String delete(@PathVariable int id) {
		Integer a = externalAppRepo.getId(id);
		try {
			if (a != null) {
				externalAppService.deleteExternalApp(id);
				return "External App deleted successfully.";
			} else {
				return "External App cannot be deleted. Please enter a valid id";
			}
		} catch (Exception e) {
			if (e instanceof java.sql.SQLIntegrityConstraintViolationException) {
				return e.getMessage();
			}
			return e.getMessage();
		}
	}
	
	@PutMapping("/UpdateExternalApp")
	public String update(@RequestBody ExternalAppEntity extApp) {
		externalAppService.updateExternalApp(extApp);
		int externalAppId = extApp.getExternalAppId();
		Optional<ExternalAppEntity> check = externalAppRepo.findById(externalAppId);
		Boolean checkValue = check.isPresent();
		String result = "";
		if (checkValue == true) {
			result = "External App Updated successfully.";
			return result;
		} else {
			result = "Please enter a valid External App Id.";
			return result;
		}
	}
}
