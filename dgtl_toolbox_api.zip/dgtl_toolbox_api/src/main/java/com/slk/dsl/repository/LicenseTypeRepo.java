package com.slk.dsl.repository;

import java.util.Date;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.slk.dsl.model.LicenseTypeEntity;

@Repository
public interface LicenseTypeRepo extends JpaRepository<LicenseTypeEntity, Integer>{
	
	String getId = "Select IFNULL(License_Type_Id, 0) from tb_license_type where License_Type_Id =:id";

	@Query(value = getId, nativeQuery = true)
	public Integer getId(int id);
	
	String deleteLicenseType = "delete from tb_license_type where License_Type_Id=:id";

	@Modifying
	@Transactional
	@Query(value = deleteLicenseType, nativeQuery = true)
	public void deleteLicenseType(int id);
	
	String updateLicenseType = "update tb_license_type set  License_Type=:licenseType, Description =:description, Rec_Upd_Dt =:recUpdDt where License_Type_Id=:licenseTypeId";
	
	@Transactional
	@Modifying
	@Query(value = updateLicenseType, nativeQuery = true)
	public void updateLicenseType(String licenseType, String description, Date recUpdDt, int licenseTypeId);
	


}
