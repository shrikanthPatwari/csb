package com.slk.dsl.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.slk.dsl.model.UsersEntity;

public interface UserRepo extends JpaRepository<UsersEntity, Integer>{

	UsersEntity findByEmailAddress(String emailAddress);
	
	String getId = "Select IFNULL(User_Id, 0) from tb_users where User_Id =:id";
	@Query(value = getId, nativeQuery = true)
	public Integer getId(int id);

	
	String getEmail = "Select Email_Address from tb_users where User_Id =:id";
	@Query(value = getEmail, nativeQuery = true)
	public String getEmail(int id);
	
	String getPassword = "Select Password from tb_users where User_Id =:id";
	@Query(value = getPassword, nativeQuery = true)
	public String getPassword(int id);
}
