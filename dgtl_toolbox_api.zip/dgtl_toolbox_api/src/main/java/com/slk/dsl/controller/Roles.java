package com.slk.dsl.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.slk.dsl.model.RolesEntity;
import com.slk.dsl.repository.RolesRepo;
import com.slk.dsl.service.RolesService;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class Roles {
	
	@Autowired
	RolesService rolesService;
	
	@Autowired
	RolesRepo rolesRepo;
	
	@GetMapping("/Roles")  
	public List<RolesEntity> getRoles() {  
	     return rolesService.getRoles();	      
	}
	
	@PostMapping("/AddRoles")
	public RolesEntity addRoles(@RequestBody RolesEntity roles) {
		return rolesService.saveRoles(roles);
	}
	
	@DeleteMapping("/DeleteRoles/{id}")
	public String delete(@PathVariable int id) {
		Integer a = rolesRepo.getId(id);
		try {
			if (a != null) {
				rolesService.deleteRoles(id);
				return "Role deleted successfully.";
			} else {
				return "Role cannot be deleted. Please enter a valid id";
			}
		} catch (Exception e) {
			if (e instanceof java.sql.SQLIntegrityConstraintViolationException) {
				return e.getMessage();
			}
			return e.getMessage();
		}
	}
	
	@PutMapping("/UpdateRoles")
	public String update(@RequestBody RolesEntity role) {
		rolesService.updateRoles(role);
		int roleId = role.getRoleId();
		Optional<RolesEntity> check = rolesRepo.findById(roleId);
		Boolean checkValue = check.isPresent();
		String result = "";
		if (checkValue == true) {
			result = "Role Updated successfully.";
			return result;
		} else {
			result = "Please enter a valid Role Id.";
			return result;
		}
	}

}
