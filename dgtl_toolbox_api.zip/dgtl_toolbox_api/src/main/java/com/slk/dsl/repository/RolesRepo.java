package com.slk.dsl.repository;

import java.util.Date;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.slk.dsl.model.RolesEntity;

@Repository
public interface RolesRepo extends JpaRepository<RolesEntity, Integer>{
	
	String getId = "Select IFNULL(Role_Id, 0) from tb_roles where Role_Id =:id";
	@Query(value = getId, nativeQuery = true)
	public Integer getId(int id);
	
	String deleteRoles = "delete from tb_roles where Role_Id=:id and Role_Id not in (Select distinct Role_Id from tb_users)";
	@Modifying
	@Transactional
	@Query(value = deleteRoles, nativeQuery = true)
	public void deleteRoles(int id);
	
	String updateRoles = "update tb_roles set  Role_Name=:roleName, Role_Type=:roleType, Role_Description =:roleDescription, Rec_Upd_Dt =:recUpdDt where Role_Id=:roleId";	
	@Transactional
	@Modifying
	@Query(value = updateRoles, nativeQuery = true)
	public void updateRoles(String roleName,String roleType, String roleDescription, Date recUpdDt, int roleId);

}
