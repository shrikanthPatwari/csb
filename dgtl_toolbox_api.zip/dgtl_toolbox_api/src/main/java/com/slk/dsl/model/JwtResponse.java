package com.slk.dsl.model;


import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class JwtResponse implements Serializable {

	private static final long serialVersionUID = -8091879091924046844L;
	private final String jwttoken;
	private  int orgId;
	private  String orgName;
	private  Map<String, Object> model;

	public JwtResponse(String jwttoken,int orgId, String orgName, Map<String, Object> model ) {
		this.jwttoken = jwttoken;
		this.orgId = orgId;
		this.orgName = orgName;
		this.model = model;
	}

	public String getToken() {
		return this.jwttoken;
	}

	public int getOrgId() {
		return orgId;
	}
	
	public String getOrgName() {
		return orgName;
	}

	public Map<String, Object>  getUserInfo() {
		return model;
	}	
	
}
