import matplotlib.pyplot as plt
import io
import base64
def get_class(score):
    if score < 0.4: #less than 40% is considered "low"
        return "Low"
    elif score >= 0.7: #scores greater and equal to 70% is considered "high"
        return "High"
    else: ##between [39-69] range
        return "Medium"

##plot the circular barplot
def plot_circular_bar(data):
    categories = list(data.keys())
    values = list(data.values())
    colors = []
    for value in values:
        if get_class(value) == "High":
            colors.append("green")
        elif get_class(value) == "Medium":
            colors.append("yellow")
        else:
            colors.append("red")
    fig = plt.figure(figsize=(3.5,3.5))
    ax = fig.add_subplot(111, projection='polar')
    ax.set_theta_direction(-1)
    ax.set_theta_zero_location("N") ##to make clockwise coordinates
    theta = [i * (2 * 3.141592 / len(categories)) for i in range(len(categories))]
    bars = ax.bar(x=theta, height=values, width=0.3, bottom=0.0, color=colors)
    ax.set_xticks(theta)
    ax.set_xticklabels(categories, fontsize=12)
    ax.tick_params(axis='y', which='both', left=False, right=False, labelleft=False)
    for i, bar in enumerate(bars):
        angle = theta[i]
        bar.set_facecolor(colors[i])
        ax.text(x=angle, y=0.2, s=str(round(values[i],2)), ha='center', va='center', fontsize=9)
        ax.text(x=angle, y=max(values) + 0.015, s=categories[i], ha='center', va='center', fontsize=10, rotation = 90*(i%2))

    high_patch = plt.Rectangle((0, 0), 1, 1, fc='green')
    med_patch = plt.Rectangle((0, 0), 1, 1, fc='yellow')
    low_patch = plt.Rectangle((0, 0), 1, 1, fc='red')
    ax.legend([high_patch, med_patch, low_patch], ['High', 'Medium', 'Low'], loc=(.75, 0.75), frameon=False, fontsize=8)
    plt.axis('off')
    
    # save the plot to a memory buffer as a PNG image
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    

    # return blob  string from buffer
    return base64.urlsafe_b64encode(buffer.getvalue()).decode()