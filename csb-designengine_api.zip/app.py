from api_calls import *
from flask import Flask, jsonify, request
from flask_restful import Resource, Api

app = Flask(__name__)
@app.route('/appid', methods=['POST'])
def app_id():
   return rlane_from_appid(request.get_json(force=True)["app_id"],db_change=True)

@app.route('/orgid', methods=['POST'])
def org_id():
   return rlanes_from_orgid(request.get_json(force=True)["Org_Id"],db_change=True)

@app.route('/update_rule_model',methods=['POST'])
def update_model():
   import create
   return 'updated rule model'

if __name__ == '__main__':
   app.run(debug=True)
    