from pickle import load,dump
##read the pickle file
def read_pickle(pickle_path):
    with open(pickle_path,'rb') as in_file:
        data=load(in_file)
    return data
    
## write the pickle given data
def write_pickle(pickle_path,data):
    with open(pickle_path,'wb') as out_file:
        dump(data,out_file)
    print(f'pickle file saved: "{pickle_path}"')
