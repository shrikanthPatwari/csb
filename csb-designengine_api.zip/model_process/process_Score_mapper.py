from file_operations.pickle_operations import read_pickle
class Process_Score_mapper:
    def __init__(self,score_dict,loaded_Model=None):
        self.score_dict=score_dict
        if loaded_Model==None:
            from os import path,getcwd
            self.structure_path=path.join(getcwd(),'pickle_files/score_mapper.pkl')
            self.read_score_mapper()
        else:
            self.structure=loaded_Model

    def read_score_mapper(self):
        self.structure=read_pickle(self.structure_path) 

    def get_equation_condition(self,condition):
        for _ in self.score_dict:
            condition=condition.replace(_,str(self.score_dict[_]))
        return condition
    
    def apply_condition(self,condition):
        flags=[]
        True_count=0
        for _ in condition.split(','):
            if eval(f"{_}"):
                True_count+=1
                flags.append(True)
            else:
                flags.append(False)
            
        return flags,True_count

    def __enter__(self):
        self.rlanes_count={'True':{},'False':{}}
        self.out=[]

        for rlane in self.structure:
            flags,pos_count=self.apply_condition(self.get_equation_condition(self.structure[rlane]))
            if len(flags)==pos_count:
                self.rlanes_count['True'][rlane]=len(flags)
            else:
                self.rlanes_count['False'][rlane]=pos_count/len(flags)

        if len(self.rlanes_count['True'])==1:
            self.out=list(self.rlanes_count['True'].keys())
        else:
            if len(self.rlanes_count['True'])==0:
                flag='False'
            else:
                flag='True'
            mx_true_count=max(self.rlanes_count[flag].values())
            for _ in self.rlanes_count[flag]:
                if self.rlanes_count[flag][_]==mx_true_count:
                    self.out.append(_)
        
        if len(self.out)==0:
            print('no conditions passed')
        elif len(self.out)>1:
            print('there is a conflict between multiple rlanes')
        return self
               
    def __exit__(self,ty,val,tb):
        del self