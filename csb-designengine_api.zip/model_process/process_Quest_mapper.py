from file_operations.pickle_operations import read_pickle
class Process_Quest_mapper:
    def __init__(self,entry,loaded_Model=None):
        self.entry=entry
        if loaded_Model==None:
            from os import path,getcwd
            self.structure_path=path.join(getcwd(),'pickle_files/quest_mapper.pkl')
            self.read_quest_mapper()
        else:
            self.structure=loaded_Model
    
    def read_quest_mapper(self):
        self.structure=read_pickle(self.structure_path)
    
    def __enter__(self):
        self.sub_score={}
        self.score={}
        self.score_flags={}
        for ques in self.structure:
            dep_ques=self.structure[ques]['Dep_Question']
            if ques in self.entry:
                selected_option=self.entry[ques]
                options_avail=self.structure[ques]['Options']
                if selected_option not in options_avail  or selected_option=='SKIP':##skipped questions
                    count_inc=0
                    score_inc=0
                    update_score=False
                else:
                    if dep_ques!=None:
                        if dep_ques in self.entry:
                            selected_dep_option=self.entry[dep_ques]
                            if selected_dep_option not in options_avail[selected_option] or selected_dep_option=='SKIP':##skipped questions
                                count_inc=0
                                score_inc=0
                                update_score=False
                            else:
                                score_inc=options_avail[selected_option][selected_dep_option]
                                update_score=True
                                count_inc=1
                        else:
                            count_inc=0
                            score_inc=0
                            update_score=False 
                    else:
                        count_inc=1
                        update_score=True
                        score_inc=options_avail[selected_option]
            else:
                count_inc=0
                score_inc=0
                update_score=False
            score_tuple=(score_inc/self.structure[ques]['max'],count_inc)
            self.sub_score[self.structure[ques]['SubScore Category']]=self.sub_score.setdefault(self.structure[ques]['SubScore Category'],0)+score_inc
            self.score[self.structure[ques]['Score Category']]=tuple(map(lambda i, j: i + j, self.score.setdefault(self.structure[ques]['Score Category'],(0,0)) , score_tuple))
        for _ in self.score:
            if self.score[_][1]==0:
                self.score_flags[_]=0
            else:    
                val=self.score[_][0]/self.score[_][1]
                self.score_flags[_]=val
        return self
    
    def __exit__(self,ty,val,tb):
        del self