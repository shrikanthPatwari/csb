import pandas as pd
import mysql.connector
from db_connect import Db_connect
from process import Process_entry

# update the database given rlane, appid and database cursor
def update_db(rlane,image_blob,appid,conn,flag):
    if flag:
        mycursor = conn.cursor()
        comment = f"Current application is {rlane}"
        get_rlane_id = "SELECT RLane_Strategy_Id FROM ca_rlane_strategy_lookup where RLane_Strategy='" + rlane+ "';"
        rlaneId = pd.read_sql(get_rlane_id, conn)["RLane_Strategy_Id"][0]

        ##queries to run
        comment_query = f"UPDATE `ca_app_master` SET `Comments` = '{comment}' WHERE (`App_Id` = {str(appid)});"
        blob_query=f"UPDATE `ca_app_master` SET `image_blob` = '{image_blob}' WHERE (`App_Id` = {str(appid)});"
        r_id_query = "UPDATE `ca_app_master` SET `RLane_Strategy_Id` ='" + str(rlaneId) + "' WHERE (`App_Id` = '" + str(appid) + "');"
        
        ##queries execution
        try:
            mycursor.execute(comment_query)
            mycursor.execute(blob_query)
            mycursor.execute(r_id_query)
        except mysql.connector.Error as err:
            print(f"Error executing query: {err}")
        
        ##committing all changes
        conn.commit()
        print('database updated')
    
def rlane_from_appid(appid,db_change=True):
    application_query =f"""SELECT 
            `ca_app_master`.`App_Id` AS `app_id`,
            `ca_app_master`.`App_Name` AS `App_Name`,
            `ca_app_master`.`Rec_Ins_dt` AS `Record_Date`,
            `ca_app_survey_response`.`comments` AS `comments`,
            `ca_survey_questioner`.`question_description` AS `questiones`
        FROM
            ((`ca_app_master`
            JOIN `ca_app_survey_response` 
            ON 
            ((`ca_app_master`.`App_Id` = `ca_app_survey_response`.`app_Id`)))
            JOIN `ca_survey_questioner` 
            ON 
            ((`ca_survey_questioner`.`questioner_Id` = `ca_app_survey_response`.`questioner_Id`))
        )
        WHERE `ca_app_master`.`App_Id`={appid} and 
            (`ca_survey_questioner`.`Org_App_QuestionType` = 2) and (`ca_app_master`.`RLane_Strategy_Id`>=0);
        """
    with Db_connect() as db:
        application = pd.read_sql_query(application_query, db.conn)
        if application.empty:
            return f" For the appid '{appid}', there is no survey taken"

        application = application.pivot_table(columns='questiones', 
                                            index=['App_Name','app_id'], values='comments',
                                            aggfunc=lambda x: ' '.join(x))
        application = application.reset_index() #reseting index of question column from 0 
        process_obj=Process_entry()                      
        application[['rlane_labels', 'image_blob']]=application.apply(lambda x:process_obj.process_entry(x,image_key='App_Name',drop_keys=['App_Name','app_id']),axis=1)
        update_db(application.rlane_labels.loc[0],application.image_blob.loc[0],appid,db.conn,flag=db_change)
        return application.rlane_labels.loc[0]
                
def rlanes_from_orgid(Org_Id,db_change=True): 
    org_query =f"""  
            SELECT 
                `ca_app_master`.`App_Id` AS `app_id`,
                `ca_app_master`.`App_Name` AS `App_Name`,
                `ca_app_master`.`Org_Id` AS `Org_Id`,
                `ca_app_survey_response`.`comments` AS `comments`,
                `ca_survey_questioner`.`question_description` AS `questiones`
            FROM
                ((`ca_app_master`
                JOIN `ca_app_survey_response` ON ((`ca_app_master`.`App_Id` = `ca_app_survey_response`.`app_Id`)))
                JOIN `ca_survey_questioner` ON ((`ca_survey_questioner`.`questioner_Id` = `ca_app_survey_response`.`questioner_Id`))
            )
            WHERE `ca_app_master`.`Org_Id`={Org_Id} and 
                (`ca_survey_questioner`.`Org_App_QuestionType` = 2) and (`ca_app_master`.`RLane_Strategy_Id`>=0);
    """
    with Db_connect() as db:
        application = pd.read_sql_query(org_query, db.conn)
        if application.empty:
            return f" For the orgid {Org_Id}, there is no survey taken"
        application = application.pivot_table(columns='questiones', 
                                            index=['App_Name','app_id'], 
                                            values='comments',
                                            aggfunc=lambda x: ' '.join(x))
        application = application.reset_index()
        application.fillna('SKIP',inplace=True)
        process_obj=Process_entry()
        application[['rlane_labels', 'image_blob']]=application.apply(lambda x:process_obj.process_entry(x,image_key='App_Name',drop_keys=['App_Name','app_id']),axis=1)
        
        for i in application.index:
            update_db(application.rlane_labels.loc[i],application.image_blob.loc[0],application.app_id.loc[i],db.conn,flag=db_change)
        return application[['app_id','rlane_labels']].set_index('app_id').to_dict()