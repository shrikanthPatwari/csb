import mysql.connector
from json import load
import warnings
import os
warnings.filterwarnings("ignore")

class Db_connect:
    def __init__(self):
        self.conn=None
        self.config_path=os.path.join(os.getcwd(),'data_file/db_conf.json')
        self.db_config={}

    def read_config(self):
        with open(self.config_path,'r') as in_file:
            self.db_config=load(in_file)
        return self

    def __enter__(self):
        self.read_config()
        try:
            self.conn = mysql.connector.connect(**self.db_config)
            print("Connection to DataBase established")
        except mysql.connector.Error as error:
            print(f"Error connecting to MySQL database: {error}")
        return self
    
    def __exit__(self,ty,val,tb):
        print("Disconnected from DataBase")
        del self

    