from model_process import *
from os import path,getcwd
from file_operations.pickle_operations import read_pickle
from plot_graph import plot_circular_bar
from pandas import Series
class Process_entry:
    def __init__(self):
        quest_map_path=path.join(getcwd(),'pickle_files/quest_mapper.pkl')
        score_map_path=path.join(getcwd(),'pickle_files/score_mapper.pkl')
        self.quest_mapper=self.structure=read_pickle(quest_map_path) 
        self.score_mapper=self.structure=read_pickle(score_map_path) 

    def process_entry(self,entry,image_key=None,drop_keys=[]):
        if image_key in entry:
            image_name=entry[image_key]
        else:
            image_name='unnamed_image'
        for _ in drop_keys:
            entry.drop(_)
        with Process_Quest_mapper(entry,loaded_Model=self.quest_mapper) as proc_ques:
            subscores=proc_ques.sub_score
            blob=plot_circular_bar(proc_ques.score_flags)
        with Process_Score_mapper(subscores,loaded_Model=self.score_mapper) as proc_score:
            return Series([proc_score.out[0],blob], index=['rlane_labels', 'image_blob'])