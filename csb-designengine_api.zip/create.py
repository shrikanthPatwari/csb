import os
q_mapper_out_path=os.path.join(os.getcwd(),'pickle_files/quest_mapper.pkl')
score_2_cat_out_path=os.path.join(os.getcwd(),'pickle_files/score_mapper.pkl')
query_json_path=os.path.join(os.getcwd(),'data_file/queries.json')
from json import load
from model_creation import *
from db_connect import Db_connect
with open(query_json_path,'r') as query_file:
    with Db_connect() as db:
        queries=load(query_file)
        with Create_Quest_mapper({queries["ind_query"]:False,queries["ind_dep_query"]:True},db.conn,q_mapper_out_path) as q_map:
            pass
        with Create_Score_mapper(queries['rlane_logic_query'],db.conn,score_2_cat_out_path) as score_map:
            pass