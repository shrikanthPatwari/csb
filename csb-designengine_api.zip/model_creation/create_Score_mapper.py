from pandas import read_sql_query
from file_operations.pickle_operations import write_pickle
class Create_Score_mapper:
    '''
    input:

        queries-- list of queries which contain rlane logic
        out_path-- path of the output pickle file

    output of call function:
        returns whole structure of score to rlanes in dictionary format
    '''
    def __init__(self,query:str,db_conn,out_path:str):
        self.query=query
        self.out_path=out_path
        self.db_conn=db_conn
    
    def get_data(self):
        df=read_sql_query(read_sql_query(self.query, self.db_conn).rlane_query[0], self.db_conn)
        df=df.apply(lambda x: ','.join(x.dropna())).str.strip(',') ## combined conditions
        return df
    
    def __enter__(self):
        self.structure=self.get_data().to_dict()
        return self
    
    def __exit__(self,ty,val,tb):
        write_pickle(self.out_path,self.structure)
        del self