from pandas import read_sql_query
import re
from file_operations.pickle_operations import write_pickle
from db_connect import Db_connect   

class Create_Quest_mapper:
    '''
    input:

        query_map-- query to fetch data from db, along with flag whether
                     to search for dependent question or not
        out_path-- path of the output pickle file

    output of call function:
        returns whole structure of questions in dictionary format
    '''
    def __init__(self,query_map,db_conn,out_path):
        self.query_map=query_map
        self.out_path=out_path
        self.db_conn=db_conn

    ##fetching data from database using query
    ##queries are designed such that last two cols are opts and score
    ##and all rem cols can be used for grouping 
    def get_data(self,query): 
        df=read_sql_query(query, self.db_conn)
        #stripping extra spaces from extremes
        df=df.applymap(lambda x: x.strip() if isinstance(x, str) else x) 
        group_by_cols=list(df.columns[:-2]) #skipping last two columns(opts and score)
        grouped_df=df.groupby(group_by_cols).agg(list) 
        return grouped_df.to_dict(orient='index')
    
    def map_options_with_score(self,val_dict):
        min_=None
        max_=None
        out={}
        for _ in range(len(val_dict['opts'])):
            if min_==None:
                min_=val_dict['score'][_]
            else:
                min_=min(min_,val_dict['score'][_])
            if max_==None:
                max_=val_dict['score'][_]
            else:
                max_=max(max_,val_dict['score'][_])
            out[val_dict['opts'][_]]=val_dict['score'][_]
            
        return out,min_,max_

    ##abbrev the score categories 
    ##reason: categories are present in abbrev format in rlane logic table
    def get_score_cat(self,score_cat_string):
        reg='\((.*)\)'
        if re.search(reg,score_cat_string):
            return re.search(reg,score_cat_string).groups()[0]
        return ''.join([_[0] for _ in score_cat_string.split()])
    
    def data_process(self,data,query_flag):
        out={}
        for key,value in data.items():
            if not query_flag:
                (score_cat,sub_score_cat,ques)=key
            else:
                (score_cat,sub_score_cat,ques,dep_ques,option)=key
            if ques not in out:
                out[ques]={'Options':{},'SubScore Category':None,'Score Category':None,'Dep_Question':None} #default
    
            if out[ques]['Dep_Question']==None and query_flag:
                out[ques]['Dep_Question']=dep_ques
            if out[ques]['SubScore Category']==None:
                out[ques]['SubScore Category']=self.get_score_cat(sub_score_cat)
            if out[ques]['Score Category']==None:
                out[ques]['Score Category']=score_cat
            if query_flag:
                out[ques]['Options'][option],out[ques]['min'],out[ques]['max']=self.map_options_with_score(value)
            else:
                out[ques]['Options'],out[ques]['min'],out[ques]['max']=self.map_options_with_score(value)
        return out
    
    def __enter__(self):
        self.structure={}
        for query,query_flag in self.query_map.items():
            data=self.get_data(query)
            self.structure={**self.data_process(data,query_flag),**self.structure}
        
        return self
    
    def __exit__(self,ty,val,tb):
        write_pickle(self.out_path,self.structure)
        del self
    
